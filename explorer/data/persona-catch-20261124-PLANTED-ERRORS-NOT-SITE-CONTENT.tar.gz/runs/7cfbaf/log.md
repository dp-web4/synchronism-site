# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 1: Casual Science Enthusiast

### Summary
- **Pages visited**: 6 (index, why-synchronism, first-encounter, galaxy-plotter, key-claims [top only], wide-binaries [bounced after 2 paragraphs]); skipped critical-density
- **Understanding achieved**: partial
- **Would return?**: maybe (only for the Gaia DR4 follow-up on 2 Dec, if someone posts a plain summary)
- **Overall impression**: The opening paragraph is the most honest science pitch I've ever read, then the site buries me under a page of corrections, symbols and revision notes about a theory it just told me is dead.

### Journey
**Landing page.** The headline, "What if one equation described reality from quantum to cosmic?", is a great hook. The crowd vs marching band picture clicked right away: one number from 0 to 1 for how much a system's parts act together. Then, in the same paragraph, I'm told "We proposed this. We tested it. It did not hold." That's surprising and honestly kind of refreshing. But that one "paragraph" goes on to cover AI agents, "dp", a superconductor disclaimer, MOND, retrodiction and a second density parameter. By the end I'd read the word "coherence" explained three times and still wasn't sure why a superconductor matters to me. The next paragraph adds the Bell test, "a family of versions", and Gaia DR4. Gaia DR4 is the one bit that made me curious (a real date, next week!), but then I'm told it "cannot confirm anything new", so... why care?

I did find the "New here? That is everything you need from this page. Press Start here now" line, and I was grateful for it. I did press it. I scrolled a bit past it first and hit `C(ρ) = tanh(γ · ln(ρ/ρcrit + 1))`. The read-aloud version ("a squashing function of a compressing function") was cute, but the next lines on γ said things like "near 0.77ρcrit/γ for large γ; at γ = 2 the curve is already at 0.88 there" and I backed out fast. Further down are things like "ΔBIC +2,843", "Excluded at its own cap" and a giant Bell-test row citing PRL papers. I only got a sense of a scoreboard full of red. I counted at least five "New here? stop here" signposts on one page, which tells me the page knows it's too long.

**Why Synchronism? (step 1).** This was the best page. "What happened, in three lines" is exactly what I wanted: proposal, tested, lost, and here's the attempt. The "why does matching an existing theory count as losing?" explanation finally made it click for me. If your formula just turns into MOND, you haven't discovered anything. Good. I opened the optional fold. "The Problem" and "The Approach" were readable. The superconductor stuff came back (fourth time now) and I still don't get why it keeps being mentioned. The melting point (53% error) and superconductor (607 K vs 93 K) failures were concrete and easy to understand. I liked those.

**First Encounter (step 2).** It promises "No prerequisites needed" and "~10 minutes". Section A on density was fine, though the MRH ("Markov Relevancy Horizon") name is intimidating for what is just "only nearby stuff matters". Section B's dimmer-switch explanation of tanh and ln was the clearest the site got for me ("10×, 100×, 1000× become evenly spaced steps"). Section C lost me. γ, N_corr, "+0.55 predicted, −0.55 measured", and γ explained "in three lines" because "the page meets it three times". I understood the gist: the knob was guessed, the guess was wrong, and when they tuned the knob they got MOND. Section E's a₀ ≈ cH₀/2π "coincidence" box went over my head. Section F (measurement = crossing a horizon) sounded like the exciting part, then said it predicts the same as normal quantum mechanics, plus something about the "quantum Zeno effect". Section G recapped failures. It really was about 10 minutes, but I left knowing more about what failed than about what the idea *was*.

**Galaxy Curve Plotter (step 3).** The top three bullets are great: dots = measured, gray = visible matter only, the gap = the dark matter puzzle, green = MOND fits, violet = this theory and doesn't. That's a real "aha" and the best teaching moment on the site. The page then says "That is the whole lesson", and it should have ended there. Below it are what feel like 20+ paragraphs about "division vs quadrature wiring", "units-hybrid 0.029·Vflat²", Ωm floors, amber stand-ins, revision notes and script filenames. The "Plain verdict for casual readers" sits in the middle of a wall of text. I couldn't operate the tool (text mirror), but the five galaxy buttons and a "How heavy are the stars?" slider sound friendly. The "twin pair" suggestion (NGC 2403 vs UGC 128) sounds like a fun thing to try, but its explanation went technical immediately.

I didn't press Next (What Synchronism Is Not); it's not in the mirror.

**Key Claims.** I went there because the landing page said "Consciousness given an equation", which is the most clickbait-y thing on the site. The "In plain words: the three claims, one sentence each" box is excellent. Then: "The rest of this page is written for readers with some physics." Fair, so I left.

**Wide Binaries.** I tried this because of the Gaia DR4 date. The first line is a badge reading "Untested — Self-Eliminating-or-Tie — density branch identically null in the ratio but not in absolute dynamics (excluded at the archive knee by the vertical Oort/K_z gradient…". I bounced instantly. The "Why Wide Binaries?" paragraph underneath was actually readable (two stars far apart, gravity very weak, a clean test), but the badge had already scared me off.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index, hero paragraph | One ~400-word paragraph mixes the hook, an AI-authorship disclosure, a superconductor caveat, MOND, retrodiction and a cluster parameter. The best sentence ("We proposed this. We tested it. It did not hold as stated.") is buried in it. | high | Cut the hero to about 4 sentences: the idea, the crowd/band picture, "it lost, and here's how", and a Start button. Move everything else below. |
| index, everywhere | The superconductor/"not quantum coherence" disclaimer appears 3+ times on the landing page, and again on steps 1 and 2. A casual reader never thought it was quantum coherence until told so repeatedly. | medium | Say it once, briefly, in the glossary or a footnote. Don't repeat it in beginner-facing text. |
| index | The Gaia DR4 date (2 Dec 2026) is the most "newsworthy" hook, but its paragraph ends with "cannot confirm anything new", which deflates it. | low | Frame it as "watch MOND get tested next week" and link to a plain explainer. |
| index | At least five separate "New here? stop here / press Start" signposts | medium | One clear Start button high up is better than repeated warnings. The repetition signals the page is too long. |
| index, equation block | The read-aloud explanation is good, but it sits next to "0.77ρcrit/γ", "1.17 decades", "concave everywhere with no inflection" | medium | Keep the plain-English line. Move the γ/ρcrit details into the physicist fold. |
| first-encounter, Section C | γ is explained "in three lines, since the page meets it three times". Includes N_corr, ±0.55 correlations and 10⁻¹² | medium | For beginners: "the knob was guessed, the guess was wrong, and tuning it just gave MOND." Fold the rest. |
| first-encounter, Section E | The a₀ ≈ cH₀/2π "coincidence" assumes you know what H₀ and an acceleration scale are | low | Skip this for beginners, or explain it in one plain sentence. |
| first-encounter overall | I left knowing far more about what failed than about what the idea *was*. The positive picture (why someone thought this was promising) is thin. | medium | Add one paragraph on why the idea seemed exciting before the failures. |
| galaxy-plotter | "That is the whole lesson" comes early, followed by a huge wall (wirings, units-hybrid knees, Ωm floors, revision notes, script paths) on a page that's Beginner Path step 3 | high | Put the chart and the three-bullet explainer at the top. Collapse everything else into one "For physicists" fold. |
| galaxy-plotter | Lines are named in several ways (violet solid, light-violet dashed, amber dotted, green, gray), and two are hidden | low | A tiny legend at the chart: "green = MOND (fits), violet = this theory (doesn't)". |
| wide-binaries | The first thing on the page is a dense jargon badge ("Self-Eliminating-or-Tie — density branch identically null in the ratio…") | high (for anyone arriving from the DR4 hook) | Lead with the plain "Why Wide Binaries?" paragraph. Shorten the badge to "Untested" plus a link. |
| all pages | Revision notes ("corrected 2026-11-19 from a coefficient slip…") are mixed into the reading text | medium | Move the history to a changelog. Beginners read it as noise or as sloppiness. |
| key-claims | The plain-words summary is great, but "Consciousness given an equation" on the landing page oversells, because the claim turns out to be a placeholder | low | Soften the teaser wording to match. |

### Tools Tested
- Galaxy Curve Plotter: couldn't operate it (text mirror), so I can't say whether it works. Intuitive at the top: the three-bullet "what to look at" is the single clearest explanation of the dark matter puzzle on the site. Confusing everywhere else because of the surrounding text volume. The galaxy buttons and the star-weight slider sound inviting, and the "twin pair" suggestion would be fun if it were explained simply.
- Coherence Explorer / γ Calculator: linked from First Encounter ("Best hands-on intro on the site") but not in the mirror, so not tested.

### Unanswered Questions
1. In one sentence, what did the people behind this think was promising *before* testing? Why did one dial for everything seem plausible?
2. Why do superconductors keep coming up? Is that important, or just a defensive footnote?
3. If the theory is "dead as tested physics", what does "the ontology is the invitation" mean for someone like me?
4. What exactly happens on 2 December with Gaia DR4, and where would I see the result in plain language?
5. "AI agents arguing with each other", ~3,300 sessions: is the real story here the AI research process rather than the physics?
6. Is MOND right, then? The plotter says green fits galaxies but then fails a Solar System test, so I'm left unsure what the current best answer is.

### Verdict
The core story ("a big idea, tested in public, turned out to be an old theory in disguise, and here's how you can tell") is really interesting, and the Why Synchronism three-liner and the top of the Galaxy Plotter tell it well. Almost everything around those bits reads like a lab notebook full of corrections aimed at physicists, and it drowns the beginner path. I'd tell a friend "the first page and the galaxy chart are worth five minutes". I wouldn't expect them to get past the landing page without skipping hard.

"""Was each planted snippet inside the first 2000 chars of its line (Read-tool truncation) and within 2000 lines?"""
import json
ROOT = "/tmp/pcatch"
for m in json.load(open(f"{ROOT}/MANIFEST.json")):
    lines = open(f"{ROOT}/planted/{m['file']}").read().split("\n")
    for n, l in enumerate(lines, 1):
        k = l.find(m["planted_text"])
        if k >= 0:
            print(f"{m['id']} line {n:4d}/{len(lines)} linelen {len(l):6d} offset {k:6d} end {k + len(m['planted_text']):6d} "
                  f"{'VISIBLE' if k + len(m['planted_text']) <= 2000 and n <= 2000 else 'TRUNCATED?'}")
for f in ("index.txt", "galaxy-plotter.txt", "key-claims.txt", "wide-binaries.txt"):
    L = open(f"{ROOT}/planted/{f}").read().split("\n")
    print(f, "lines", len(L), "lines>2000 chars:", sum(len(x) > 2000 for x in L), "max", max(map(len, L)))

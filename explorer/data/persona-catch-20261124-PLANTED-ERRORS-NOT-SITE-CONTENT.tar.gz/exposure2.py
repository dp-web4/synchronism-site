import json, re
exec(open("/tmp/pcatch/exposure.py").read().split("scores = {")[0])
KEYS = {"P01": ["0.14%", "0.14 %"], "P02": ["≈ 7.1", "≈7.1", "t = 7.1", "t ≈ 7.1"], "P03": ["1.24", "24%", "24 %"], "P04": ["326 light", "326 ly"],
        "P05": ["4.9σ", "4.9 σ"], "P06": ["4 executed"], "P07": ["0.001"], "P08": ["14,585", "14585"],
        "P09": ["Science 350", "(Science"], "P10": ["ApJ 270", "270, 365"], "P11": ["Williams"], "P12": ["Misra"],
        "P13": ["transition fixes"], "P14": ["one selected each", "1 selected Synchronism"], "P15": ["All three fit"],
        "P16": ["modest support"], "P17": ["excluded at about 6σ", "excluded at about 6 σ"], "P18": ["~6σ", "~6 σ", "≈6σ"],
        "P19": ["ruled out as well"], "P20": ["excluded at about 3σ", "excluded at about 3 σ"]}
norm = lambda s: re.sub(r"\s+", " ", s.replace(" ", " ").replace(" ", " "))
scores = {r["run"]: {o["id"]: o["verdict"] for o in json.load(open(f"{ROOT}/scores/{r['run']}.json"))} for r in med}
order = sorted(med, key=lambda x: (x["rep"], x["persona"]))
R = {r["run"]: norm(reports(r["run"])) for r in order}
print("report chars per run:", {r["run"]: len(R[r["run"]]) for r in order})
T = dict(E=0, EC=0, U=0, UC=0); byp = {p: 0 for p in (1, 2, 3, 4)}; bycls = {}
for m in man:
    row = ""
    for r in order:
        e = any(norm(k) in R[r["run"]] for k in KEYS[m["id"]])
        v = scores[r["run"]][m["id"]]
        row += ("E" if e else "-") + {"CAUGHT": "C", "NOTICED": "n"}.get(v, ".") + " "
        T["E" if e else "U"] += 1; T[("E" if e else "U") + "C"] += v == "CAUGHT"
        byp[r["persona"]] += e
        b = bycls.setdefault(m["class"], [0, 0, 0]); b[0] += 1; b[1] += e; b[2] += (e and v == "CAUGHT")
    print(m["id"], f"{m['class']:<10}", row)
print(T, "exposure by persona (of 40):", byp)
print("by class [trials, exposed, exposed&caught]:", bycls)

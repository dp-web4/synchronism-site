# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 4: Leading-Edge Researcher

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe. I'd come back for the Gaia DR4 reading key after 2 December and for the hidden-companion analysis of Chae's 36 systems. The framework itself gives me no reason to return.
- **Overall impression**: The site does not contain new physics, and it says so accurately. Its useful output is a set of no-go results for density-keyed substitutes for MOND. Several citation errors and internal inconsistencies remain, including one sentence on Key Claims that reports a win for Synchronism the site elsewhere says never happened.

### Journey
I started on the landing page and went straight past the beginner material to the "Where each piece stands" table and the refutation ledger. The verdicts there hold up on my own checks. The identity tanh(γ ln(1+x)) = [(1+x)^2γ − 1]/[(1+x)^2γ + 1] is correct. At γ = ½ it reduces to x/(x+2) = μ_simple(x/2), so the acceleration-keyed version is MOND's simple interpolating function under a rescaled a₀. In the cosmology sector the same cancellation gives ρ_DE = 2ρcrit, which is Λ. I also confirmed that C(ρ) is concave in ρ for every γ (the sign of C'' goes as (2γ−1) − (2γ+1)u, which is negative because u ≥ 1). The large-g tails of the Hill-type Ca and the tanh-log form match only at 2γ = 0.618, as stated. These numbers reproduce: a₀ = cH₀/2π = 1.04×10⁻¹⁰ m/s² (1.13 at H₀ = 73), the inverted H₀ = 77.6, Freeman Σ₀ ≈ 119 M☉/pc², the MOND-tracking knee 6.3×10⁻³ M☉/pc³ at 200 km/s, the Milky Way external field ≈ 1.8 a₀, the no-EFE simple-ν boost of 3.70 at y = 0.1, and Chae's Γ → γ conversion. The cosmology/galaxy knee gap of 6.6–10.4 dex and the Lorentz-violation gap of 15–27 orders are internally consistent.

Novelty hunt. I checked each surviving item for something that differs from MOND + ΛCDM and has not already been excluded:
- **a₀(z) = cH(z)/2π**: the site correctly says this does not discriminate. Milgrom raised it himself, and the site cites a ΛCDM simulation result predicting similar evolution (I have not verified that citation). The RC100 run is inconclusive, and the 1σ-versus-95% error-bar ambiguity is handled honestly.
- **Density-keyed G**: this is the most interesting material on the site. Oort/K_z gradient, lunar laser ranging Ġ/G, and BBN G_BBN/G₀ together give three SPARC-independent ways to exclude a law of the form G_eff = G/C(ρ_smoothed). The BBN argument is clean: lab G and local dynamics share one density, while BBN probes C = 1. As a generic constraint on any MOND substitute keyed on ambient density, this is citable work. It is not new physics.
- **Wide binaries / DR4**: no outcome can favour this framework. A boost lands on compander γ values that Cassini already excludes. A null leaves only a density-keyed window indistinguishable from Newton. The density boost is absorbed into close-binary mass calibrations (γ_g ≡ 1). I agree with all three points. The pre-data reading key is good practice, but it sorts out MOND's question, not this framework's.
- **Quantum and consciousness claims**: as the site says, these have no rate parameter and no calibration. The interference argument against a literal scan is correct, and it dismisses the CRT picture before any scan period needs to be chosen.

Verdict on "0 unique confirmed predictions": accurate, and if anything generous. The framework has never put forward a prediction that is both distinct from MOND/ΛCDM and not already excluded. The two discriminating tests (TEST-09 and TEST-10) both selected MOND.

On A2ACW: the site's own calibration result (specificity 0 of 6 on canonical discoveries, Youden's J = 0 under the literal rule) shows it does not work as a discovery instrument, and the site says so. As an error-correction loop it clearly does something, since the revision notes record dozens of real fixes. But many of those fixes are credited to simulated-visitor personas, which share a training distribution with the agents being corrected. At least one citation has already been withdrawn as a "recall error". The external-reader catch (the 635× A discrepancy) shows what out-of-distribution review adds. The method is sound for refuting its own claims and unsound for generating physics.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| key-claims, "What's not on this page", BTFR paragraph | Says the two discriminating tests were "both run: **1 selected Synchronism over MOND** (2 discriminated, one selected each)". The landing page says both "selected the MOND class". This sentence reports a win the site says never happened. | high | Change to "both selected MOND". |
| index, Bell row | Hensen et al. 2015 is cited as *Science* 350, 682. It is *Nature* 526, 682 (2015). | medium | Fix the citation. |
| wide-binaries, lunar laser ranging paragraph | Ġ/G = (7.1 ± 7.6)×10⁻¹⁴ yr⁻¹ is attributed to Williams, Turyshev & Boggs 2004. That value is Hofmann & Müller 2018 (CQG 35, 035015). Williams et al. 2004 gave (4 ± 9)×10⁻¹³ yr⁻¹. The "bound loosened 13×" makes it unclear which bound was actually used. | medium | Correct the attribution and state the bound used numerically. |
| critical-density, knee-law list | Says the archive's velocity exponent +0.5 is "excluded at ~6σ". Against the measured −0.16 ± 0.19, (0.5 + 0.16)/0.19 = 3.5σ, which is what wide-binaries and the plotter say. | medium | Change to ~3.5σ. |
| index, "Scientific Outcomes" TEST-10 paragraph | Still gives Draco at 4.9σ and Crater II at 4.2σ. The scoreboard row on the same page corrects Draco to 4.5σ and drops Crater II because it is tidally disrupting. | medium | Bring the paragraph in line with the scoreboard row. |
| index vs key-claims, refutation count | Key Claims says the site-wide count is "4 executed refutations on external data". The landing page says 5 of the 6 ran on outside data. | medium | Use one number, taken from the ledger. |
| key-claims, "what survives (a)" | "~116× apart at V = 300 km/s" between the MOND-required knee (∝V⁻²) and the framework's knee (∝V⁺²). I could not reproduce this with any knee on file: at A = 0.029 the gap is about 10⁵, at 4.6×10⁻⁵ about 10³. | low | State the normalisation, or recompute. |
| index, Bell/clock row | Cites Bell 1986, Phys. Rep. 137, 49 as "Quantum field theory without observers". From memory, the published title is "Beables for quantum field theory". | low | Check the title against the journal. |
| wide-binaries, Chae, Park & Yoon citation | arXiv:2610.40388 is a 5-digit number above typical monthly submission volumes. | low | Check the locator, under the same rule that withdrew "Saurabh & Desmond". |
| galaxy-plotter, DDO 154 box and "What You're Seeing" | Still says "green line is also 7% low by its normalisation" (the BTFR circularity, removed 2026-11-10) and "this galaxy's maximum C(ρ) is 0.001", while the control above shows 0.244 at the default knee. | medium | Rewrite for the default knee, or tag those passages "(units-hybrid setting)". |
| wide-binaries, "Why Wide Binaries?" and "The Data" box | Calls wide binaries a clean two-body test with "no complex baryonic physics", yet the same page documents hidden-companion contamination deciding the result. The data box still presents DR3 with "~6 months analysis time" eight days before DR4. | low | Mention triples and contamination in the intro and update the data box for DR4. |
| key-claims / index, density-keyed G | Missing prior art: chameleon, symmetron and dilaton screening (Khoury & Weltman 2004; Hinterbichler & Khoury 2010) are the main literature on gravity whose strength depends on ambient density, with laboratory constraints. Eddington-inspired Born–Infeld gravity is also relevant. Only Refracted Gravity is cited. | medium | Add these, and say what the Oort/LLR/BBN results add beyond screening-model bounds. |
| key-claims / plotter, division wiring | A pointwise G_eff = G/C(ρ) applied without an action breaks Newton's third law when the two bodies sit at different densities, which produces self-acceleration and non-conservation of momentum. The site says an action exists (L3) but never states this objection to the L2 (no-action) reading. | medium | Add it next to the AQUAL argument: a second reason the algebraic reading is not a theory. |
| index, cosmology row | DESI DR2 prefers evolving dark energy (w₀w_a, with a phantom crossing) at roughly 3–4σ in combination. The site says its dark-energy sector "Is Λ" but never says whether any γ ≠ ½ form moves toward or away from the DESI preference. | medium | Add one sentence on w_eff(z) for the forms that differ from Λ. |
| wide-binaries, possible extra check | The recombination-era G bounds from CMB+BAO are not used. At about 50 M☉/pc³, C is near but not equal to 1, so they could be a fourth check on the amplitude. | low | Optional: run it alongside the BBN check. |
| index, overall | No frozen, versioned, citable document. Every page carries rolling revision notes, so I cannot cite "the site's result" as of a date. | medium | Publish a dated PDF or Zenodo snapshot of the ledger and the no-go results. |

### Tools Tested
- Galaxy Curve Plotter (text only): could not operate it; scientifically accurate in its main statements. The formulas as described check out. The default archive knee (0.028·V^0.5) puts the bright centres above the knee and the outskirts at the 3.17× floor, and the green curve is a real simple-ν MOND prediction on SPARC baryons with one global a₀. It correctly discloses that the simple ν it uses as the benchmark fails Cassini. Some explanatory text is still written for the old units-hybrid setting (see friction log). The two-wirings demonstration (quadrature does nothing, division is capped) is pedagogically effective.
- DR4 reading key (wide-binaries, static table): fine as a dated mapping from measured boost to γ. It is not a test, and the site says so.

### Unanswered Questions
1. Do the Oort/LLR/BBN exclusions add anything beyond existing bounds on chameleon and symmetron screening? If they apply to a wider class (any law G(ρ_smoothed) without a screening scalar), say so explicitly. That is the one result here worth writing up as a short note.
2. For the dark-energy forms with γ ≠ ½, what is w_eff(z), and does any of them reach the w₀–w_a region DESI DR2 prefers?
3. Has anyone outside contacted Chae et al. or Saad & Ting about the hidden-companion estimate (a per-star rate of 0.3 moving γ from 1.87 to about 1.2)? If it holds up, it matters more to the wide-binary community than anything else on the site.
4. Will the 12 forks waiting on the project lead be settled before DR4? While "the framework" is still a family of versions, any refutation can be routed around.
5. Under the action (L3) reading, is momentum conserved and the external-field effect non-zero? If the external-field effect is non-zero, the "EFE = 0" argument and the AQUAL comparison need restating.

### Verdict
Nothing here is new physics. Every live branch of the framework is either MOND (at γ ≈ ½), Λ, an interpretation of QM with no rate parameter, or excluded, and the site's "0 confirmed novel predictions" is accurate. The part a researcher can use is the set of no-go results for density-keyed MOND substitutes, especially the BBN and Ġ/G arguments that do not depend on SPARC, plus a careful, if unreviewed, view of the wide-binary dispute. To be credible to outside readers, the site still needs to fix the "1 selected Synchronism" error and the misattributed citations (Hensen, Ġ/G), cite the screening-model literature, and publish a frozen version that can be cited.

"""Characterise how today's real visitor passes read the site: Agent (subagent) prompts and Bash commands."""
import json, glob, os, sys, collections
D = "/home/dp/.claude/projects/-home-dp-ai-workspace-synchronism-site-visitor"
files = sorted(glob.glob(D + "/*.jsonl"), key=os.path.getmtime)[-4:]
kinds = collections.Counter()
for f in files:
    print("====", os.path.basename(f), os.path.getmtime(f))
    for line in open(f):
        try:
            o = json.loads(line)
        except Exception:
            continue
        msg = o.get("message") or {}
        if msg.get("role") != "assistant":
            continue
        for c in msg.get("content") or []:
            if isinstance(c, dict) and c.get("type") == "tool_use":
                i = c["input"]
                if c["name"] == "Agent":
                    kinds["agent:" + str(i.get("subagent_type"))] += 1
                    print("  AGENT", i.get("subagent_type"), "|", i.get("prompt", "")[:200].replace("\n", " "))
                elif c["name"] == "Bash":
                    cmd = i.get("command", "")
                    k = "curl" if "curl" in cmd else ("python" if "python" in cmd else "other")
                    kinds["bash:" + k] += 1
                    if len(sys.argv) > 1:
                        print("  BASH", cmd[:160].replace("\n", " "))
print(kinds)

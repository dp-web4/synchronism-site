"""Mediated arm A2: persona can only see pages through a haiku 'web-fetch' subagent (Read-only) that knows the mirror path.
usage: python3 run_mediated.py '<json list of [persona, rep]>'   (condition is always planted)"""
import json, os, shutil, subprocess, sys, time, uuid, concurrent.futures as cf
ROOT = "/tmp/pcatch"; TPL = f"{ROOT}/template"
ENV = dict(os.environ, CLAUDE_CODE_DISABLE_AUTO_MEMORY="1")

def run(persona, rep):
    rid = uuid.uuid4().hex[:6]
    d = f"{ROOT}/runs/{rid}"; mirror = f"{ROOT}/mirrors/{rid}"
    os.makedirs(d); shutil.copytree(f"{ROOT}/planted", mirror)
    shutil.copy(f"{TPL}/CLAUDE_m.md", f"{d}/CLAUDE.md")
    open(f"{d}/log.md", "w").write("# Synchronism Visitor Browse Log — offline\n\nPersona pass over the offline site\n")
    with open(f"{ROOT}/runmap.jsonl", "a") as f:
        f.write(json.dumps({"run": rid, "cond": "mediated", "persona": persona, "rep": rep}) + "\n")
    agents = {"web-fetch": {
        "description": "Fetches a page of the site and reports on it according to your brief (stands in for a web fetch tool).",
        "prompt": (f"You stand in for a web-fetch tool. The site's pages are text files at {mirror}/<page>.txt "
                   "(index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims). "
                   "Read the page(s) the request names and answer the request about their content. Report what the request "
                   "asks for; quote verbatim where asked. Do not mention file paths; refer to pages by name."),
        "tools": ["Read"], "model": "haiku"}}
    cmd = ["claude", "-p", open(f"{TPL}/p{persona}m.txt").read(), "--model", "opus",
           "--tools", "Agent,Read,Edit,Write", "--allowedTools", "Agent,Read,Edit,Write",
           "--agents", json.dumps(agents), "--setting-sources", "", "--strict-mcp-config",
           "--settings", '{"autoMemoryEnabled": false}', "--output-format", "stream-json", "--verbose"]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=d, env=ENV, capture_output=True, text=True, timeout=1700)
        out, err = p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or ""); err = "TIMEOUT"
    open(f"{d}/stream.jsonl", "w").write(out); open(f"{d}/stderr.txt", "w").write(err or "")
    return rid, persona, rep, round(time.time() - t0), os.path.getsize(f"{d}/log.md")

if __name__ == "__main__":
    spec = json.loads(sys.argv[1])
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        for r in ex.map(lambda s: run(*s), spec):
            print(json.dumps(r), flush=True)

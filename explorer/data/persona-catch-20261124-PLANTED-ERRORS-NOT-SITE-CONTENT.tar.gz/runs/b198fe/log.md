# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 3: Graduate Physics Student

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe
- **Overall impression**: Most of the algebra holds when I recompute it, and the site names its own reparametrizations more honestly than most framework sites. But I found about a dozen numerical, citation and stale-text errors, and three of them change what a claim says: the BBN "3σ" exclusion, the wide-binary "+24%", and Key Claims saying "1 selected Synchronism over MOND".

### Journey
I skipped the beginner framing and opened the "for people checking the work" half of the index, then the ρcrit page, Key Claims, the plotter's formula box and Wide Binaries. I went back to Why Synchronism and First Encounter only to check whether they agree with the technical pages.

**What I checked and found correct** (recomputed by hand):
- C = tanh(γ ln(1+x)) = [(1+x)^{2γ}−1]/[(1+x)^{2γ}+1]. At γ = ½ this gives x/(x+2) = μ_simple(x/2). That is an exact identity, not a fit, and the site says so. The same cancellation gives (1−C)/C = 2/x, so ρ_DE = 2ρcrit, which is a cosmological constant. With ρcrit = ρΛ/2 ≈ 4.3×10⁻⁸ M☉/pc³ you get C₀ = Ωm. The numbers check out. This is the best reparametrization finding on the site, and it is stated plainly.
- Shape facts: C is concave in ρ for every x ≥ 0 (C'' = −γ sech²u (1+2γ tanh u)/(1+x)² < 0). The log-axis bend is at u ≈ 0.772 (from 2u tanh u = 1), so x ≈ 0.77/γ for large γ. The minimum 10–90% width is log₁₀(atanh 0.9/atanh 0.1) = 1.17 decades, i.e. a factor of about 15. At γ = 2, C(ρcrit) = 0.88, C = ½ sits at x = 3^{1/4}−1 = 0.316, and the steepest point vs ln ρ is at C ≈ 0.60. All correct.
- Mean-field question: the site does **not** claim a mean-field derivation of tanh. It explicitly says there is no self-consistency loop, no free energy and no critical exponents. That is the right answer: Curie–Weiss tanh comes from m = tanh(β(Jzm+h)), and nothing like that appears here. It also concedes that γ = 2/√Ncorr runs opposite to fluctuation scaling and that Ncorr is back-solved. Honest.
- ρcrit / Jeans: A = 4π/(βJ²GR₀²) = 4.57×10⁻⁵ at βJ = 1, R₀ = 8 kpc (correct). 0.029/4.57×10⁻⁵ = 635. The equivalent length √(4π/(0.029G)) = 317 pc. The virial bound x = (3/16π²)βJ²(Vc/Vflat)² = 0.019βJ². At βJ = 4.5, x = 0.385 and C = 0.57. The 17σ for βJ is correct. NGC 3198 x = 2.64 and 1.39×10⁻³ are both correct.
- a₀ = cH₀/2π = 1.04×10⁻¹⁰ m/s². At H₀ = 73 it is 1.13; at z = 1 it is ×E(z) = 1.79, giving 1.86. Inverting gives H₀ = 77.6 ± 15.5. Freeman Σ₀ = a₀/2πG = 119 M☉/pc². The a₀-tracking knee a₀²/(4πGV²) = 6.3×10⁻³ at 200 km/s, and it equals (c/2πV)²(2/3)ρc0 algebraically. All correct.
- Plotter: simple ν = ½+√(¼+1/y) is correct, and so is McGaugh's ν = 1/(1−e^{−√y}). The Freeman-disc formula is right, and so are the 0.622 vs 0.542 √(GM/Rd) peak comparison and 1/(Ga₀) = 62.8, giving (47/62.8)^{1/4} = 0.93. DDO 154: knee 0.192 vs 64 (a factor of 334). Cρ max 0.244 corresponds to x = 0.13, and the floored boost is 1.44× in speed. N_corr ≈ 17 at γ = 0.49.
- Wide binaries: the 10⁴ AU ≈ 0.05 pc threshold and the MW field ≈ 1.8 a₀ are right. ν_simple(0.1) = 3.70, so +92% with no EFE. Γ → γ = 10^{2Γ} gives 1.21 / 1.60. The solar-neighbourhood boosts at all three knees (+64%/+223%, floored +33%/+62%, +18.6%/+116%, +9.4%/+0.005%) recompute exactly. Bovy & Rix Σ = 68 ± 4 is correct.
- Bell: Giustina p ≈ 3.7×10⁻³¹, Shalm 2.3×10⁻⁷, Hensen S = 2.42 ± 0.20, p = 0.039 all match my memory. The CHSH arm is labelled as Bell's theorem itself rather than as a test, which is correct. The same goes for the "0 of 512 is the Peres–Mermin theorem itself" note. The scan-vs-interference objection (a time-averaged scan is a mixture with no off-diagonals, so no fringes) is correct and is the right first objection.
- Quadrature-boost unboundedness (1 + (Vflat C/vb)² → ∞ as vb → 0) is correct. The radial-shape no-go is also correct: division gives a boost ∝ e^{r/Rd}, while a flat curve needs a boost ∝ r.

**"Validated" badges**: these look honest now. "Validated" is deprecated. The ρcrit page openly says its old "Validated, 5% agreement" claim was false and that an outside reader caught it, not the badge system. The "0 of 9" audit is correctly flagged as an uncalibrated LLM instrument (specificity 0/6) and is kept separate from the data refutations. I agree with that separation.

**Reparametrizations identified by the site**: MOND μ_simple (exact at γ = ½), Λ (exact at γ = ½), Debye model (chemistry), Abrikosov–Gor'kov (η factor), Palma–Suominen–Ekert (Γ = κ²(1−c)), dynamical decoupling (resync), Milgrom's cH₀ coincidence, Freeman = a₀/2πG. I agree with all of them. Two more the site could name:
- The floored division form g = gbar/(Ωm + (1−Ωm)C) has a ceiling of 1/Ωm. That is essentially the "cosmic baryon fraction" ceiling familiar from halo models, so the boost-cap tests are really testing a cosmic-ratio assumption, not anything about tanh.
- Ca = x/(1+x) with x = (g/a₀)^{0.618} is a Hill-type interpolating function of the kind already used in MOND fits.

**Errors I found** (details in the friction log):
1. **BBN, Refracted Gravity knee at γ = 2 "excluded at about 3σ"**: wrong. C at that knee is 1 − 1×10⁻⁴, so G_BBN/G_lab ≈ 0.9999. Against 0.99 (+0.06/−0.05 at 2σ) that is about 0.3σ, i.e. consistent. This looks like a decimal slip.
2. **BBN, archive-knee range "0.37–0.57"**: the unfloored γ = 0.489 value is C = 0.095. The quoted "36σ" endpoint only works with 0.095 ((0.99−0.095)/0.025 ≈ 36), so the printed prediction range leaves out the value that produces its own upper σ.
3. **Wide binaries "up to about +24% in velocity (√1.4 ≈ 1.24)"**: √1.4 = 1.183, so it is +18%. The revision note even says the ~18% figure was the right one.
4. **ρcrit page "archive's +0.5 is excluded at ~6σ"**: (0.5+0.16)/0.19 = 3.5σ. The plotter and Wide Binaries both say 3.5σ.
5. **Key Claims, Session 63 t-test**: "t = (0.640 − 0.500)/(0.0196/√8) ≈ 7.1". That formula gives 20.2; 7.1 is Δ/SD with the √n dropped. The p ≈ 1.8×10⁻⁷ next to it matches t ≈ 20 (df = 7), not 7.1. The 0.618 and 2/3 p-values are consistent with the correct t.
6. **Key Claims, AQUAL citation**: AQUAL is cited as "(1983, ApJ 270, 365)". That is Milgrom's original MOND paper; AQUAL is Bekenstein & Milgrom 1984, ApJ 286, 7. Wide Binaries cites it correctly as 1984. The claim that AQUAL "rejected this substitution", as if it argued against a density key, also reads like an over-attribution. As far as I know BM84 keyed on |∇Φ| for field-equation reasons, not as a rebuttal of a ρ-keyed law.
7. **Wide Binaries, LLR**: Ġ/G = (7.1 ± 7.6)×10⁻¹⁴/yr is attributed to Williams, Turyshev & Boggs 2004. That value is Hofmann & Müller 2018. WTB 2004 gave (4 ± 9)×10⁻¹³/yr.
8. **Key Claims, TEST-09 paragraph**: it says "1 selected Synchronism over MOND (2 discriminated, one selected each)". The index says both discriminating tests selected the MOND class. This sentence reads as a win the site does not claim anywhere else.
9. **First Encounter**: "the number is 1/(2π), which the coherence transition fixes". Key Claims and Parameter Derivations say the 2π is posited and "no calculation on file yields the 2π". The beginner page overstates a derivation the technical pages withdraw.
10. **First Encounter**: it cites the quantum Zeno effect as "a real measured effect, Misra & Sudarshan 1977". M&S is the theory paper; the measurement is Itano et al. 1990, which Key Claims cites correctly.

I also found stale text on the plotter. Several passages still describe the units-hybrid knee as if it were the default, contradicting the default 0.028·V^0.5 knee (details in the friction log).

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| wide-binaries, BBN box | "Refracted Gravity's knee at γ = 2 is excluded at about 3σ". The prediction is G_BBN/G_lab ≈ 0.9999 vs 0.99 (+0.06/−0.05 at 2σ), which is ~0.3σ and consistent. The "except RG at γ=2" paragraph below it is consistent with not-excluded. | high | Change to "consistent (~0.3σ)" and recheck the script output |
| wide-binaries, BBN box | Archive-knee prediction printed as "0.37–0.57", but unfloored γ=0.489 gives C=0.095, and the quoted 36σ endpoint requires 0.095 | medium | Print "0.10–0.57" |
| wide-binaries, "What MOND predicts" | "+24% in velocity (√1.4 ≈ 1.24)", but √1.4 = 1.18 | high (arithmetic in a headline sentence) | Restore "+18%" |
| wide-binaries, header badge | Badge reads "Untested", but the body reports the density branch excluded (Oort/Kz, LLR, BBN, SPARC) and the acceleration branch failed via TEST-25 | medium | Use a badge that matches the content, or explain why "Untested" survives |
| wide-binaries, LLR | (7.1±7.6)×10⁻¹⁴/yr attributed to Williams, Turyshev & Boggs 2004; that is Hofmann & Müller 2018 (WTB 2004 is (4±9)×10⁻¹³) | medium | Fix the citation; if the 2004 bound was intended, the "loosened 13×" arithmetic changes |
| critical-density, knee list | "+0.5 is excluded at ~6σ"; (0.5+0.16)/0.19 = 3.5σ, as the plotter and wide-binaries say | medium | Change to ~3.5σ |
| critical-density, a₀/Σ₀ cards | Bare "13% error" and "≈4% error". Key Claims says a bare 13% is misleading without the systematic, and that sub-percent/percentage Freeman matches were retired | low | Carry the same "0.7σ against systematics" wording here |
| key-claims, Session 63 t-test | t ≈ 7.1 doesn't follow from the printed formula (that gives 20.2); the p-value matches 20.2 | medium | Correct t to ≈20 |
| key-claims, AQUAL | Cited as "1983, ApJ 270, 365" (Milgrom's MOND paper); AQUAL is Bekenstein & Milgrom 1984, ApJ 286, 7. "AQUAL rejected this substitution" over-attributes intent | medium | Fix the reference; soften to "AQUAL keys on \|∇Φ\|, which avoids this divergence" |
| key-claims, TEST-09 paragraph | "1 selected Synchronism over MOND (2 discriminated, one selected each)" contradicts the index ("both selected the MOND class") | high | Rewrite: "2 discriminated; both selected MOND" |
| key-claims, V-scaling | "~116× apart at V = 300 km/s" has no stated anchor. The table's absolute knees give 10³–10⁶ at 300 km/s | low | State the normalisation velocity or drop the number |
| key-claims, decoherence row | "the reversible, inhomogeneous part, T2*". T2* is the total free-induction dephasing time; the refocusable part is the inhomogeneous contribution (often written T2′) | low | Reword |
| first-encounter, section E | "1/(2π), which the coherence transition fixes" contradicts "no calculation on file yields the 2π" | high (beginner page asserts a derivation the site retracted) | Say "posited, following Milgrom's form" |
| first-encounter, section F | Zeno "measured effect, Misra & Sudarshan 1977": that is the theory paper; the experiment is Itano et al. 1990 | low | Cite Itano 1990 for the measurement |
| galaxy-plotter, stale passages | "What You're Seeing" (max C 0.001, uniform boost), the legend ("Newton ×1.78"; "BTFR mass"), "The chart draws only A = 0.029", "The toy exponential disc survives only as the density profile fed to Cρ" (superseded 11-17). All contradict the default 0.028·V^0.5 knee and the SPARC Σ input | high (it's the tool page; a reader can't tell which description matches the plot) | Sweep the page for units-hybrid-only text; label each remaining instance "(units-hybrid setting)" |
| index, TEST-10 paragraph | Says Draco and Crater II exceed the cap at "4.9σ and 4.2σ … corrected 2026-11-19", while the scoreboard says Draco is now 4.5σ and Crater II was dropped on 11-20 (disrupting) | medium | Update to Draco 4.5σ; remove Crater II |
| index, Ca row | "the tails match only at γ = 0.309": only the high-g tail matches (g^{−0.618} vs 2g^{−2γ}); the low tail never does (g^{0.618} vs linear) | low | Say "the upper tail" |
| why-synchronism vs index | Why Synchronism: "the broader frame behind it has been ruled out as well". Index: the ontology is "untested rather than refuted" / "partly tested" | medium | Pick one statement (the index's nuanced one is right) |
| why-synchronism, galaxy card | "175 SPARC + 14,585 ALFALFA–SDSS (quality cut)" sums to 14,760, not 14,610. 14,585 is the registered cross-match; 14,435 is post-cut (as Key Claims says) | medium | Use 14,435 |
| key-claims vs index | Environment test called TEST-08 (Key Claims), TEST-03s (index) and TEST-03/05 (Why Synchronism) | low | One ID, with aliases listed once |
| index, hero | Very long; the physics reader has to get through about 4 screens of meta-commentary before the equation | low | Optional: anchor link "Physicists: jump to equation" at the top |

### Tools Tested
- Galaxy Curve Plotter: text only (can't operate it). The physics as described is correct. The simple-ν MOND, the RAR ν, the Freeman disc, the SPARC mass-model combination (V_gas|V_gas| + Υ V_disk² + 1.4Υ V_bul²), the floored-division boost cap of 1/Ωm (1.78× in v) and the DDO 154 numbers all check out. It is genuinely a like-for-like comparison now that MOND runs on SPARC baryons. The page itself is confusing: at least four passages still describe the old units-hybrid default, so the "what you're seeing" prose disagrees with the default plot. The caveat that the green line uses a function Cassini excludes is a nice touch of honesty.
- Coherence Explorer / γ Calculator: not mirrored. I could only check their captions as quoted on other pages (the 1.17-decade width and the concavity claim), and both are correct.

### Unanswered Questions
1. If the cosmological sector is exactly Λ at γ = ½ and the galaxy sector is exactly μ_simple at γ = ½, is there any γ ≠ ½ observable that isn't already excluded? The "three shapes the equation forbids" link isn't mirrored.
2. The DESI γ = 0.487 vs the P(k) bound |2γ−1| < 10⁻⁵ means the mean-density and local-fluid readings disagree by a factor of thousands. Which reading is the theory? That seems to be one of the 12 pending forks.
3. Why does the boost cap use 1/Ωm (total matter over the total, including CDM) when the framework's premise is that there is no CDM? The baryon-budget ceilings Ωm/Ωb seem the only self-consistent choice, and TEST-09 doesn't fire at those.
4. Is the BBN smoothing condition (lab and solar neighbourhood at one smoothed density) the same smoothing scale the SPARC fits use (h = 0.3 kpc)? If so, the BBN exclusion and the galaxy fits are using the same density definition, and that should be stated.
5. Where is a variational or self-consistency argument that would pick tanh(γ ln(1+x)) over any other compander? The site says none exists. Then what, other than notation, is "the framework" in the galaxy sector?

### Verdict
Most of the mathematics recomputes correctly. The site's central self-diagnosis is right: at γ = ½ the equation is exactly MOND's simple μ in galaxies and exactly Λ in cosmology, the density-keyed version fails on SPARC, and tanh is a chosen curve, not a mean-field result. The badges look honest now, and the site labels the reparametrizations clearly. However, I found about a dozen concrete errors: a √1.4 slip, a 3σ that should be 0.3σ, a dropped √n in a t-statistic, a 6σ that is 3.5σ, two wrong citations, a "selected Synchronism" sentence that contradicts the scoreboard, and stale plotter text. With this much in-place revision, the internal consistency checks are lagging behind the content. I'd trust the conclusions more than any individual number.

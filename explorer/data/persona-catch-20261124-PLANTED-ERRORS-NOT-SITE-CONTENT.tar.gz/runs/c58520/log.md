# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 2: Technical Writer

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: partial
- **Would return?**: maybe
- **Overall impression**: The Beginner Path scaffolding is careful and honest, but the pages under it read like a changelog layered on a lab notebook: stale sentences sit next to their corrections, counts disagree between pages, and one symbol (C, γ, ρcrit, "compander") names several different things.

### Journey
I started on the landing page. The top nav (Start Here, Learning Paths, Tier 1, Test Roadmap, Interactive Tools, Glossary, Research Philosophy, For Researchers, Honest Assessment) is clear. In the text mirror the tagline runs straight into the last nav item ("Honest AssessmentAn Open Research Notebook…"), which may only be an extraction artifact. The hero explains the idea and the verdict plainly. It does, though, carry three separate "New here? stop/start here" callouts before the "Below this line: for people checking the work" divider, plus a fourth after Key Claims. Each is helpful alone. Together they show the page doesn't trust its own structure.

Under the divider the landing page becomes a reference document. Before the full abbreviation key (the "Scientific Outcomes" block), I met a four-row table of C functions, a scoreboard table with very long cells (the Bell row is several hundred words), and five labelling systems: status badge, scoreboard word, ledger class, operational state and lifecycle verb (line 69). The page does try to help. An "Abbreviations ahead" line links a short key. Still, Υ (stellar mass-to-light ratio) is used in the C-functions table and never appears in the abbreviation key at all.

I followed the Beginner Path: Why Synchronism (step 1) → First Encounter (step 2) → Galaxy Curve Plotter (step 3). The step banners with Prev/Next work and agree with each other. Step 3's Next points to "What Synchronism Is Not" (step 4, not mirrored), which matches the landing page's description of the path. The path is discoverable and consistent, and that is the site's strongest structural feature.

Why Synchronism is well built: three-line summary, an explicit "that is all you need" exit, then an optional fold. Its message conflicts with the landing page, though. It says "the broader frame behind it has been ruled out as well", while the landing page says the ontology is "untested rather than refuted" and "partly tested".

First Encounter's lettered sections A–G are explained well, and the page says how they differ from the step counter. That is good writing. Its expert note uses BEC and BCS without expanding them on that page.

The Galaxy Plotter is the weakest page for a reader on step 3. The beginner layer at the top is good. Below it, several paragraphs describe the old "units-hybrid" setting as if it were still the default. "What You're Seeing" says the max C is 0.001, the legend says violet is "Newton's shape ×1.78", and an assumption bullet says "The chart draws only A = 0.029". Meanwhile the knee panel, for the actual default, reports max Cρ = 0.244 and a boost that varies with radius. A reader can't tell which description matches the chart on screen.

I then went sideways to Critical Density, Wide Binaries and Key Claims. The breadcrumbs (Home / Core Theory / …, Home / Cosmology / …) use section names that don't appear anywhere in the top nav. A breadcrumb level a reader can't reach any other way doesn't help with orientation. Key Claims has the clearest badge explainer of all the pages, but it contradicts itself (see friction log) and it quotes a stale refutation count.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index, Methodology note | "0.14% internal-consistency survival rate (≈47 … out of ~3,300 sessions)". 47/3,300 ≈ 1.4%, not 0.14%. | high | Fix the arithmetic, or the numerator if 47 is wrong. Compute the percentage from one source. |
| why-synchronism (intro) vs index (hero, "One distinctive move") | Why Synchronism: "the broader frame behind it has been ruled out as well." Index: ontology "untested rather than refuted" / "partly tested". These are opposite verdicts on beginner step 1. | high | Use the index wording on step 1, or define "broader frame" so it clearly means something narrower than the ontology. |
| why-synchronism, Galaxy card detail | "14,610 galaxies (175 SPARC + 14,585 ALFALFA–SDSS (quality cut))". 175 + 14,585 = 14,760, and 14,585 is the *pre*-cut number (index and Key Claims say 14,435 after the cut). The card's own note says this figure is "now rendered from one source." | high | Render 14,435 here from the same source as the landing tile. |
| key-claims, Claim 1 caveat | "site-wide count is 4 executed refutations on external data", and the note says it is "now read from the site ledger". Index and footer say 6, of which 5 are on external data. | high | Pull the number from the ledger as the note claims, or remove it. |
| key-claims, "What's not on this page" | "1 selected Synchronism over MOND (2 discriminated, one selected each)" is garbled and seems to contradict the index ("both selected the MOND class"). | high | Rewrite as: "Two tests discriminated between Synchronism and MOND; both selected MOND." |
| key-claims, "How to read this page" | "The first claim is the foundational one — the others follow from it." The same page says the consciousness C "shares the name… not the function", and the index says to read the claims bottom-up. | medium | Delete the "others follow from it" sentence or qualify it. |
| galaxy-plotter, multiple sections | Stale units-hybrid descriptions presented as current: "What You're Seeing" (max C 0.001), the legend (×1.78), "two assumptions" ("The chart draws only A = 0.029"), the mass-model note ("toy disc survives only as the density profile", which line 69 says ended 2026-11-17), and the legend's "BTFR mass" for MOND (ended 2026-11-10). | high | Audit every sentence against the current default, and label each remaining hybrid description "(units-hybrid setting only)". |
| galaxy-plotter | Position references to things a reader can't find: "see the red box above", "the two-C's box inside the chart card", "see the switch above the chart". Curve names also drift: "dots" / "Blue dots", "Green" / "Green dashed", "five things" when two are hidden by default. | medium | Give each box a visible heading and refer to it by name. Use one name per curve. |
| galaxy-plotter (Beginner step 3) | Five beginner bullets, then roughly 15 dense expert paragraphs. Most are behind "For physicists" folds, but many unfolded paragraphs are expert-level too ("Parsimony note", "γ note", "Related environment result", "Which MOND"). | medium | Move all non-beginner prose into folds. Keep only the three-step "How to read this chart" unfolded. |
| index, scoreboard vs "Which six?" | Line 74: Draco at 4.5σ (corrected from 4.9σ), and Crater II dropped because it is disrupting. Line 85 on the same page still says "Draco and Crater II exceed it at 4.9σ and 4.2σ … corrected 2026-11-19". | medium | Update line 85 to match line 74. |
| environment test, all pages | One test carries four IDs: TEST-03 (index, why-synchronism), TEST-03s (index), TEST-03/05 (why-synchronism), TEST-05 and TEST-08 (key-claims). The "three IDs are one environment test" note doesn't say which three. | medium | Pick one canonical ID and give the aliases once, in the Test Roadmap. |
| chemistry "1,703", index vs why-synchronism vs first-encounter | Index: a "phenomenon type" counter, explicitly "not a corpus size" (the corpus is 2,671 sessions). Why Synchronism: "1,703 logged chemistry sessions". First Encounter: "~1,700 chemistry sessions". | medium | Use the index phrasing on all pages. |
| "compander" term | Why Synchronism defines it as a family of compressor–expander curves (μ-law, Hill…). Wide Binaries defines "the compander" as "this framework's acceleration-keyed curve". | medium | Use "compander family" for the general class and "acceleration-keyed C (Cg)" for the framework's function. Link the glossary. |
| ρcrit naming | URL `critical-density`, title "Reference Density", H1 "Saturation Knee", First Encounter "switch-over density", plus "knee" throughout. The page itself says "crit" is kept only because the scripts use it. | low | Keep the symbol, but use one prose name ("reference density (knee)") site-wide and mention the old name once. |
| A-discrepancy magnitude | The same gap is quoted as 635× (critical-density, key-claims), 644× (critical-density), "about 600×" (galaxy-plotter) and ×334 (plotter knee panel, a different comparison). | low | State one number and explain each variant where it appears. |
| AQUAL date, key-claims | The same paragraph says AQUAL "rejected this substitution in 1984" and cites "(1983, ApJ 270, 365)". Wide Binaries cites "Bekenstein & Milgrom 1984". | low | Reconcile the citation year. |
| MOND age | "40-year-old" (index, first-encounter, why-synchronism) alongside "1983", which is 43 years before the current date. | low | Say "from 1983" everywhere; it won't go stale. |
| Acronyms | Undefined on the page where they appear: Υ (index; missing from the key), BEC/BCS (first-encounter expert note), QUMOND, AQUAL, RUWE, IPD, RV, M/L, SH0ES (wide-binaries), DFS, SNARC, SH0ES (key-claims), L2/L3 (index), a0′ (index, wide-binaries), Ġ/G (index). | medium | Expand on first use per page, or add an ⓘ link to the glossary. Add Υ to the index key. |
| Badges | Index says "full set of nine is at the link". Key Claims defines three badges. Wide Binaries' badge ("Untested — Self-Eliminating-or-Tie — density branch identically null…") is a whole paragraph. "Audited-Negative" (critical-density) is never defined on any mirrored page. The badge explainers are good where they exist. | medium | Cap descriptor length (move the detail into body text). Define every badge used on a page in that page's badge line, as Key Claims does. |
| index, label taxonomies | Five classification systems (badge, scoreboard word, ledger class, operational state, lifecycle verb) appear before the reader has any reason to tell them apart. | medium | Move the taxonomy explainer into the glossary. On the index, show only the scoreboard words. |
| Breadcrumbs | "Core Theory" and "Cosmology" aren't top-nav sections. Wide Binaries (a local-gravity test) is filed under Cosmology. Galaxy Plotter's breadcrumb (Interactive Tools) and its Beginner-step banner give two different "where am I" answers. | medium | Align breadcrumb parents with the nav. Consider "Tests" for Wide Binaries. |
| Inline revision history, all pages | Running text is full of "Until 2026-xx-xx this said…" and "(a simulated-visitor persona pointed out…)". Even where separate "Revision notes" blocks exist, the corrections still leak into the main text, so the current claim is hard to scan. | high | Enforce the site's own rule: present-tense claims in the body, history only in collapsed revision blocks. |
| Internal file paths | Script and finding paths (`maintainer/scripts/…py`, `explorer/findings/…md`) and git hashes (PREREG c31d20e) appear as citations, but a reader can't follow them. | low | Link them to the public repo, or move them into a "Sources" footnote. |
| wide-binaries stat tiles | "Gaia DR3 / ~6 months / 104 AU" reads as stale next to the DR4 section. The superscript is lost ("104 AU" should be 10⁴ AU), which may be a mirror artifact. | low | Update the tiles for DR4 and check that superscripts render in plain-text contexts. |
| "Coherence ≠ quantum coherence" disclaimer | Repeated at least 8 times across 5 pages, in slightly different words and with slightly different explanations. | low | Write one canonical disclaimer (glossary anchor) and use a short pointer everywhere else. |
| Beginner Path timing | Step 5 (Honest Assessment) is said to be ~18,000 words, read "only the box at its top". The path's ~37 min total depends on that. | low | Make the top box its own page or anchor, so the step links straight to it. |

### Tools Tested
- Galaxy Curve Plotter — not operable (text mirror) — confusing. Controls visible in the text: five galaxy buttons, a Υdisk slider, a two-option knee selector, and two checkboxes for the optional curves. The control labels and the "How to read this chart in three steps" list are clear. Many surrounding captions describe the non-default knee setting as if it were the current state, so the text and (presumably) the rendered chart disagree. Badge plus tool-type labelling ("Model Explainer" vs claim badges) is explained, which is good.
- Coherence Explorer and γ Calculator — referenced on index, Why Synchronism and First Encounter but not mirrored; couldn't evaluate.

### Unanswered Questions
1. Is the refutation count on external data 4 or 5? (Key Claims vs index.)
2. Which single ID is canonical for the environment test (TEST-03, 03s, 05 or 08)?
3. Is the "broader frame" ruled out (Why Synchronism) or untested (index)?
4. What does the "Audited-Negative" badge mean, and where is the full list of nine badges? (Honest Assessment isn't mirrored.)
5. Do the breadcrumb sections "Core Theory" and "Cosmology" have index pages, and why aren't they in the nav?
6. Which plotter captions describe the chart a visitor actually sees by default?

### Verdict
The information architecture at the top level is good: a five-step Beginner Path with working Prev/Next, clear "you can stop here" exits, and explicit badge explainers. The weakness is maintenance. Each correction is added next to the old text instead of replacing it, so pages disagree with each other (counts, galaxy totals, refutation tallies) and sometimes with themselves (Galaxy Plotter, index Draco figures). A single editorial pass would help readers more than any new content. It should move all history into collapsed notes, render shared numbers from one source, and give one name to each symbol and test.

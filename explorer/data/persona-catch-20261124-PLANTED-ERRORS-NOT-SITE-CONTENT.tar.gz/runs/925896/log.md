# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 3: Graduate Physics Student

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (to watch the Gaia DR4 reading against the pre-committed key, not for the physics)
- **Overall impression**: The site is more honest about its own failure than almost any "unified framework" site I've seen, and nearly all the arithmetic I checked is right. But the layers of dated corrections now contradict each other, especially on the Galaxy Plotter, and I found one numerical error in the new BBN paragraph.

### Journey
I went straight to the landing page's "for people checking the work" section, then Key Claims, Critical Density, Galaxy Plotter and Wide Binaries. I read Why Synchronism and First Encounter last, to check that the beginner pages agree with the technical ones.

**What I recomputed by hand (all correct unless noted):**
- **The central identity.** tanh(γ ln(1+x)) = [(1+x)^{2γ} − 1]/[(1+x)^{2γ} + 1]. At γ = ½ this is x/(x+2) = μ_simple(x/2). This is exact, not asymptotic, so the "Reparametrization" verdict for the acceleration-keyed version is earned. The same cancellation gives (1−C)/C = 2/x, so ρ_DE = 2ρ_crit, which is exactly Λ. With ρ_crit = ρ_Λ/2 the model gives C₀ = Ωm/(Ωm+Ω_Λ) = Ωm, which matches the "calibrated so that C₀ = Ωm" claim. Both reparametrizations are correctly identified.
- **Shape claims.** C(ρ_crit) at γ = 2 is tanh(2 ln 2) = 0.882. C = ½ sits at x = 0.316. In linear ρ the curve is concave everywhere: C'' = −γ sech²u (1 + 2γ tanh u)/(1+x)² < 0. On a log axis the large-γ inflection is at w tanh w = ½, so w ≈ 0.772 and x ≈ 0.77/γ. The narrowest possible 10–90% width is log₁₀(1.472/0.1003) = 1.17 decades, matching the "factor ~15" on First Encounter. The maximum slope against log-density at γ = 2 falls at x ≈ 0.415, where C ≈ 0.60, matching Key Claims. All correct.
- **Ca versus the tanh-log form.** In the upper tail, 1 − x^{−0.618} against 1 − 2x^{−2γ} matches only at γ = 0.309. Correct.
- **Milgrom and Freeman numbers.** a₀ = cH₀/2π = 1.042×10⁻¹⁰ m/s² at H₀ = 67.4, and 1.13×10⁻¹⁰ at H₀ = 73. Inverting gives H₀ = 77.6 ± 15.5. The z = 1 value is 1.042 × E(1) = 1.042 × 1.790 = 1.86. Σ₀ = a₀/2πG = 119 M☉/pc². All correct.
- **The A parameter.** 4π/(G R₀²) at R₀ = 8 kpc gives 4.57×10⁻⁵ M☉ pc⁻³ (km/s)⁻². The 635× ratio to 0.029 is right, and so is βJ·R₀ = 317 pc for A = 0.029. The coarse-grained virial ratio x = 3βJ²/(16π²)·(Vc/Vflat)² = 0.0190 βJ² is right, as is βJ = 4.5 → x = 0.385 → C = 0.57. The knee values (64, 0.19, 0.343, 652, 1160, 1.8, and ρ_Λ/2 = 4.3×10⁻⁸ M☉/pc³) all check.
- **Galaxy and Bell numbers.** The TEST-09 separation is 0.406/0.124 = 3.27σ. The cap 1/Ωm is 3.17, or 1.78× in speed. f_DM = 0.927 → B = 13.7. 2/√Ncorr = 0.49 → Ncorr ≈ 17. 1/(G a₀) = 62.8 M☉ (km/s)⁻⁴, and (47/62.8)^¼ = 0.93. The Freeman-disc and spherical-enclosed-mass comparison at 2.2 Rd (0.622 vs 0.542) is right, as is Γ = κ²(1−c) as the κA = κB case of the correlated-dephasing formula.
- **Wide binaries.** At 10⁴ AU the acceleration between two 1 M☉ stars is 1.19×10⁻¹⁰ m/s², about a₀. MOND's simple ν at y = 0.1 is 3.70, so +92% in velocity. All the density-keyed solar-neighbourhood boosts check: +64% and +225%, floored +33% and +62%, +18.6% and +116%, +0.005% and +9.3%. So does the near-Newtonian knee window of 3.8×10⁻⁵ to 3.2×10⁻⁴.
- **Mean field.** I came in expecting a "tanh from mean field" claim. The site explicitly disowns it: no self-consistency loop, no free energy. That is the right call, since Curie–Weiss tanh comes from m appearing on both sides of the equation, and here C never feeds back.

**Where it breaks down:** most problems are stale text left beside newer text. The Galaxy Plotter is the worst case. On 2026-11-14 its default knee changed from the units-hybrid 0.029·V² to the archive's 0.028·V^0.5, and several captions still describe the old chart. For DDO 154 the page reports max Cρ = 0.244, which gives C_f = 0.48 and a boost varying from 1.44× to 1.78× in speed. Yet the legend says "Newton's shape ×1.78", and "What You're Seeing" says C never moves off its floor and "the boost is the same everywhere". The landing page has the same problem: it still says the curve is "a straight line to better than the data's precision" at the galaxy sector's parameters. That was measured under the hybrid knee, where x ≈ 10⁻³. At the current default, x reaches 2.6–3.9 and 111/123 discs exceed Ωm.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| wide-binaries, BBN paragraph | **Numerical error.** The archive-knee prediction for G_BBN/G_lab is printed as "0.37–0.57", but the page's own inputs give C(0.09/0.42) = 0.370 (γ=2), 0.568 (γ=2 floored), **0.095** (γ=0.489 unfloored) and 0.380 (γ=0.489 floored). The quoted "17–36σ" only works if 0.095 is included: with σ ≈ 0.025, (0.99−0.095)/0.025 = 36. With 0.37 as the low end the maximum would be about 25σ. So the range and the σ figure disagree. The velocity-blind (0.21–0.80) and Refracted Gravity (0.84–0.89) rows are consistent. | medium | Change the range to "0.09–0.57". |
| galaxy-plotter, legend, "What You're Seeing", step 3 of "How to read" | These describe the hybrid-knee chart (constant 1.78× speed boost, "C never moves off its floor") while the default chart shows a boost that varies with radius (1.44×→1.78× for DDO 154, near 1× in bright centres). Neither caption says which setting it describes. | high | Make each caption depend on the selected knee, or rewrite them for the default and move hybrid text under the hybrid toggle. |
| galaxy-plotter, "Two assumptions" box | Says "The chart draws only A = 0.029", which is false since 2026-11-14. The caveat bullet ends "This plot shows the framework under its own stated law", which refers to the V² law. | medium | Update to the two selectable knees. |
| galaxy-plotter, DDO 154 Vflat box | Says "the green line is also 7% low by its normalisation". That was the BTFR-mass circularity, and the same box says it was removed on 2026-11-10. | low | Delete the stale clause. |
| galaxy-plotter, Mass-model note | Says the toy disc "survives only as the density profile fed to Cρ". The formula box says Cρ has used SPARC surface densities since 2026-11-17. | low | Delete or date the sentence. |
| index, "in ρ itself … a straight line to better than the data's precision" | Holds only at the hybrid knee. At the default archive knee, C saturates in disc centres. | medium | Qualify with "at the units-hybrid knee", or remeasure at the default knee. |
| key-claims, "What survives … (a) V-scaling inversion" | Calls this "parameter-free … for every value of A" and quotes "~116× apart at V = 300 km/s, diverging as V⁴". The exponent mismatch is independent of A; the 116× is not (the ratio scales as 1/A). I could not reproduce 116 from any knee on critical-density: 0.029·V² gives about 10⁶×, 4.6×10⁻⁵·V² gives about 1.5×10³×. Also, the site now names V^0.5 as the archive's own law, so the gap grows as V^2.5, not V⁴. The plotter withdrew a similar "240–300,000×" number for exactly this reason. | medium | Keep the sign-of-exponent argument (−2 vs +0.5 or +2). Drop or derive the 116×, and state which law is meant. |
| key-claims, dark-matter "What's new" | The paragraph retracts mass cancellation for the V^0.5 law. Later paragraphs still lean on "the mass-cancellation no-go" as a data-free argument. A reader can't tell which no-go survives. | medium | Say once that mass cancellation is a V²-law result only; the locality argument (Milgrom/AQUAL) is the general one. |
| critical-density, Freeman's Σ₀ card | "≈4% error vs Freeman's value", while the same card says Σ₀ = a₀/2πG is "the same number" as a₀ (13% gap). If Freeman's value is a₀_obs/2πG ≈ 137 M☉/pc², the gap must also be about 13%. A 4% gap implies a different reference value (≈124). Key Claims says precise match percentages were retired on 2026-07-17. | medium | Remove the 4% or give its reference value. Use Key Claims' "within the factor-~2 M/L systematic" wording. |
| first-encounter section D; why-synchronism "What changes" (2) | γ ≈ 1 is called "roughly the quantum-classical boundary", and C is said to make that boundary "a calculable density threshold". Critical-density explicitly retracts the quantum↔classical reading of C as "backwards physics" (degeneracy sets in at high nλ³). | medium | Remove the quantum-classical language from beginner pages, or mark it as the retracted original framing. |
| index status table, Bell row vs refutation table | The status row says "S ≤ 2 on the three constructions built here, none of which signals". The refutation table says "the one arm above 2 (up to 2.67) signals". | low | Say: three no-signalling constructions with S ≤ 2, plus one signalling arm reaching 2.67. |
| index, the "6 refutations" headline | One of the six (Bell/CHSH) is Bell's theorem applied to a local model, and the site concedes this. Counting a theorem as an "executed refutation" pads the number even with the caveat. The two strongest data exclusions of the headline density law (ΔBIC +2,843, LLR) sit outside the count. As a reader I'd prefer the count to track evidence. | low | Report "5 data refutations + 1 theorem check", and list the uncounted density-law exclusions next to the count rather than in the footer. |
| index / galaxy-plotter, capped-boost (Ca, Cf) rows | The site doesn't state the a-priori result: any boost bounded by B_max gives g_obs ≤ B_max·g_bar → Keplerian decline at large r. That rules out asymptotically flat curves and a BTFR slope of 4 before any data. TEST-09/10 measured how badly a pre-doomed form misses. As a deep-MOND check, Ca → Ωm as g_bar → 0, so it is Newton with G/Ωm, not MOND. | medium | Add one line to the capped-boost row stating the bounded-boost no-go, so readers don't read TEST-09/10 as informative about the tanh form itself. |
| galaxy-plotter γ = 2 bullet | Calls the γ = 2 pin "disfavoured at about 2σ", but the free-Υ by-point result has a galaxy-block bootstrap 95% interval of −26 to +132, which includes zero. | low | Use one significance statement consistent with the bootstrap. |
| wide-binaries, acceleration-keyed section | Leads with in-house Cassini numbers (14.5–19.3σ, M/L pinned). The published figures are 8.7σ fiducial and 1.9σ with M/L freedom (Desmond, Hees & Famaey 2024). On this page the in-house instrument reads about 2× harsher than the literature and the literature is not mentioned. Index and the plotter handle this better. | medium | Quote 8.7σ / 1.9σ (published) first here as well, then the M/L-pinned in-house numbers. |
| wide-binaries badge | "Untested — Self-Eliminating-or-Tie" sits above a body that excludes the density branch at 4–36σ (Oort, LLR, BBN) and the acceleration branch via Cassini. The badge is about the wide-binary test itself, but a skimming reader will take it as "nothing known". | low | Add "(density branch excluded locally; see BBN/LLR)" to the badge descriptor. |
| wide-binaries citations | Several sources are flagged "locator pending" (Park et al. 2026, Saglia 2025, Pasquini 2026), and arXiv:2610.40388 has an unusually high sequence number for one month. | low | Verify every arXiv ID before DR4 traffic arrives on 2 Dec. |
| All theory pages | Revision notes are interleaved with current claims. Of the plotter's ~10k words, maybe a fifth describes the current chart. The two independent stale-caption problems I found both came from this layering. | high | Move every "until YYYY-MM-DD this read…" note into one collapsed changelog per page, and audit each page for sentences tied to a superseded setting. |

### Tools Tested
- **Galaxy Curve Plotter**: text only, so I could not operate it. The physics in its formula box is correct:
  - SPARC v_b² with V_gas|V_gas|, Υ_bul = 1.4Υ_d, and the 1.33 helium factor.
  - Simple-ν MOND, ν = ½ + √(¼ + 1/y), with one global a₀.
  - The Freeman 1970 disc formula.
  - C_f = Ωm + (1−Ωm)Cρ and division wiring.

  Comparing like for like on the same SPARC baryons is the right design. The captions, however, describe two different charts (see the friction log). From the text alone I can't tell what the default rendering looks like without recomputing it myself.
- **Coherence Explorer and γ Calculator**: not mirrored. The landing-page claims attributed to them, such as the concavity and the 1.17-decade minimum width, check out analytically.

### Unanswered Questions
1. Where does "~116× at V = 300 km/s" (Key Claims) come from, and under which knee law?
2. What reference value is behind Freeman's "≈4% error", given Σ₀ = a₀/2πG inherits a₀'s 13%?
3. The BBN argument assumes G_lab = G_bare/C(ρ_smoothed). With the knee tied to the host galaxy's V_flat, what is ρ_crit at BBN, when no galaxy exists? The answer C = 1 needs ρ ≫ every knee, which is plausible, but the knee law itself is undefined there.
4. Is there a written reason, even a heuristic one, for the 1/Ωm cap, or was it chosen to make C_f bounded?
5. Will the project lead choose between L2 (algebraic) and L3 (action) before DR4? Several verdicts, including the globular-cluster fork, depend on that choice.
6. Why is the RAR-shape kill (ΔBIC +184 / ≈+11) uncounted while the environment registration, which the site admits the equation never predicted, is counted?

### Verdict
I checked about forty derivations and numbers, and almost all hold. The key reparametrizations are proven exactly, not argued by analogy: tanh-log at γ = ½ is MOND's simple μ, and the dark-energy sector at γ = ½ is Λ. There are no remaining "Validated" badges on these pages, and the old A ≈ 0.029 "5% agreement" is openly retracted. Scientifically the framework is dead where it was tested, and the site says so.

The problem now is maintenance, not honesty. Accreted correction notes have left the Galaxy Plotter describing a chart it no longer draws, and the new BBN paragraph has a range that doesn't match its own σ values. A careful reader will find contradictions faster than claims. A consolidation pass, with each page stating only the current result and history moved elsewhere, would do more for credibility than another audit.

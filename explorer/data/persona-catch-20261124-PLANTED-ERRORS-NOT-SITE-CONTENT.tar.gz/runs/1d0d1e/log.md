# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 1: Casual Science Enthusiast

### Summary
- **Pages visited**: 6 (index, why-synchronism, first-encounter, galaxy-plotter, key-claims [top only], wide-binaries [first screen only]). Skipped critical-density; the title sounded like homework.
- **Understanding achieved**: partial
- **Would return?**: maybe (to see how Gaia DR4 turns out on 2 December 2026, though I'd probably forget)
- **Overall impression**: An unusually honest "we tried a big idea and it lost" story. The plain-English parts are good, but every page buries them in a pile of footnotes, revision notes and Greek letters that make me feel like I walked into someone's lab notebook.

### Journey
**Landing page.** The headline ("What if one equation described reality from quantum to cosmic?") is exactly the kind of thing that gets me to click from Reddit. The first paragraph was a surprise in a good way. The marching band vs. crowd picture made sense right away, and "We proposed this. We tested it. It did not hold as stated" is a hook I've never seen on a science site. I liked that MOND got a one-line explanation the first time it came up.

Then the same paragraph kept going: superconductors, Bell tests, "a family of versions", Gaia DR4, "retrodiction". By the second paragraph I'd been told the theory was "dead so far", "alive" as a record, and "partly tested" as a picture of reality, and I couldn't keep the three straight. The page told me "New here? That is everything you need from this page. Press Start here", and I was glad it did. I scrolled down anyway out of curiosity and hit a wall: a tanh equation, a four-row table of different "C" functions, ΔBIC +2,843, and a "Where each piece stands" table whose Bell row is a whole essay with Lorentz, Bohm and superdeterminism. A huge abbreviation list sits *after* the table that uses the abbreviations. I bounced back up and clicked "Start here".

**Why Synchronism? (Step 1).** This was the best page for me. "What happened, in three lines" is perfect: proposal, tested, lost, and the rest is still open. The short answer to "Why does matching an existing theory count as losing?" finally made it click: if you only rediscover MOND, you haven't predicted anything new. I expanded the optional fold. "The Problem" and "The Approach" were readable. Under "Show the equation" there's a warning that superconductors score low, and I didn't follow it ("the formula γ = 2/√Ncorr gives a system with more parts moving together a flatter curve"). I didn't know why I should care about superconductors at that point. The melting point (53% error) and superconductor (607 K vs 93 K) failures were concrete and easy to understand. I liked those.

**First Encounter (Step 2).** This page promises "No prerequisites needed" and "about 10 minutes". Section A on density was fine, and the neutron star vs. lone electron comparison is vivid. MRH ("Markov Relevancy Horizon") was a mouthful, but "the bubble of neighbours that matter" got me through. Section B explains tanh as "a dimmer switch" and ln as "squashes huge ranges", which works. Section C lost me. It tells me γ "failed" before I really understood what γ was, and then gives "γ in three lines" with three different γ values (2/√N_corr, 2, ≈0.5). I came away knowing only that γ is a knob and every setting of it is bad. The predicted +0.55 vs measured −0.55 example was nice and concrete. Section D (γ ≈ 1 band, "template-bias caveat") meant nothing to me. Section E: I didn't need the a₀ ≈ cH₀/2π coincidence, but I appreciated it saying straight out "probably a coincidence". Section F, where measurement is a "boundary crossing" and there's no observer, is the coolest idea on the site, and the whisper-in-a-loud-room analogy was great. Then it pivots to the quantum Zeno effect and interference fringes, and I couldn't tell whether the idea was dead or just "the same as normal quantum mechanics". Overall it took longer than 10 minutes, and I reread section C twice.

**Galaxy Curve Plotter (Step 3).** The top three bullets are excellent: dots = measured, gray = visible matter only, green = MOND, violet = this theory, and violet doesn't match. I *got* the dark-matter puzzle from this better than from most YouTube videos. "Why should the gray line fall at all?" (the Neptune comparison) is great, but it sits near the bottom of the page and should be near the top. The rest of the page is a wall. Units-hybrid vs. archive knee, division vs. quadrature "wiring", Ωm floor, Υdisk, revision notes dated to the day, explanations of what a previous visitor persona got wrong... I had no idea which "violet" line I was supposed to be looking at, since there are solid, dashed and amber versions. I can't operate the tool in the mirror. From the text, though, I'd expect to be confused about which checkboxes to leave alone. One thing undermined my confidence: the "What You're Seeing" section says "this galaxy's maximum C(ρ) is 0.001", while the switch box a bit above says "the highest Cρ on this disc is 0.244". As a beginner I can't tell which one is true. Things like this make me trust the plain-English summaries less.

**Key Claims (glanced).** "In plain words: the three claims, one sentence each" is perfect for me. Quantum strangeness from things falling into step: can't be tested yet. Consciousness: a placeholder formula. Dark matter: tested and failed. It then says "The rest of this page is written for readers with some physics", so I left. That was honest and helpful.

**Wide Binaries (first screen only).** I clicked because the landing page mentioned the Gaia date. The status badge alone ("Untested — Self-Eliminating-or-Tie — density branch identically null in the ratio but not in absolute dynamics…") is one long sentence of jargon. "Why Wide Binaries?" was readable: two stars far apart, gravity very weak, a clean test. After that it was percentages for γ = 2 vs γ = 0.489 and I bailed.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index: hero paragraph | One giant paragraph mixes the hook, the AI-notebook disclaimer, superconductors, MOND, retrodiction and the cluster scale. The good one-liner ("We proposed this. We tested it. It did not hold") gets buried. | high | Cut the hero to about 4 short sentences: idea, marching band picture, "it lost to an older theory", "watch how". Move the superconductor and cluster caveats down. |
| index: "alive or dead?" | Three different answers (dead / alive / partly tested) back to back, plus Bell tests and "family of versions" | medium | Give one plain answer up top ("As physics: it lost. As a record: worth reading."), with the details lower down. |
| index: abbreviation list | The giant abbreviation key appears after the "Where each piece stands" table that uses RAR, ΔBIC, σ, etc. | medium | Put the key before the first table, or link each term inline. |
| index: "Where each piece stands" Bell row | One table cell is hundreds of words of Lorentz/Bohm/superdeterminism. It's visually overwhelming even to scroll past. | medium | Collapse long cells behind "details". |
| index / all pages: revision notes | "Revision notes (history; not the current claim)" blocks, dated corrections and "a simulated-visitor persona found…" are everywhere, including on beginner steps | medium | Hide all revision history behind a single collapsed control per page, or move it to a changelog page. It reads as clutter to a newcomer. |
| why-synchronism: "Show the equation" | The superconductor and γ = 2/√Ncorr warning comes before the reader knows what γ or Ncorr are | low | Move the warning after γ is introduced, or link to it from there. |
| first-encounter: Section C | γ is introduced and declared failed in one breath, with three different γ values. Hard to hold. | high | Show γ as a simple "how fast the dimmer turns" knob first, then one sentence: "Every setting we tried either lost or turned into MOND." Move the three-value list into an expert box. |
| first-encounter: Section D | "template-bias caveat", "crossover band", "Reparametrization" badge with no plain explanation | low | Either cut it from the beginner flow or give it one plain sentence. |
| first-encounter: Section F | The cool idea (no observer needed) is immediately buried under Zeno effect and interference-fringe caveats. Unclear whether it survived. | medium | Add a one-line status: "Same predictions as ordinary quantum mechanics, so not testable as different." |
| first-encounter: time estimate | "About 10 minutes" felt more like 20 with rereading | low | Say ~15 min, or trim. |
| galaxy-plotter: below the 3 intro bullets | Wall of expert text (units-hybrid, wiring, Ωm floor, Υdisk, ΔBIC) sits between the beginner explanation and the chart on Beginner Path step 3 | high | Put the chart right after the intro bullets. Fold everything else into one "For physicists" box below the chart. |
| galaxy-plotter: "Why should the gray line fall at all?" | The clearest beginner explanation (the Neptune comparison) is buried near the bottom | medium | Move it to the top, before the bullets. |
| galaxy-plotter: contradictory number | "What You're Seeing" says max C(ρ) is 0.001 for this galaxy; the switch box above says 0.244 (default setting) | medium | Update "What You're Seeing" to match the current default calibration. |
| galaxy-plotter: legend | Solid violet, dashed light violet, amber dotted, green dashed, gray dashed. Too many lines for a beginner to track. | medium | In the beginner text, mention only gray, dots, green and solid violet. |
| wide-binaries: status badge | The badge text is a full jargon sentence | low | Use a short badge ("Untested") with the explanation in a tooltip. |

### Tools Tested
- Galaxy Curve Plotter: couldn't be operated (text-only mirror). The intro text is intuitive and the core lesson (violet misses the dots, green hits them) comes through clearly. The surrounding explanation is confusing: too many line types and calibration settings, and the "max C" numbers on the page contradict each other (0.001 vs 0.244).
- Coherence Explorer and γ Calculator: linked from First Encounter but not in the mirror, so not tested. First Encounter calls the Coherence Explorer the "best hands-on intro on the site", so it's a pity it was the one I couldn't reach.

### Unanswered Questions
1. If the main idea lost, what's the "bigger question" that "remains open"? Why Synchronism says this, but I couldn't find a plain statement of what's still alive.
2. Is the "no observer needed" quantum idea something new, or just a different way of describing normal quantum mechanics? The site seems to say the second, but not in plain words.
3. Is MOND right, then? The plotter shows MOND matching galaxies but failing a Cassini test. As an outsider I don't know what to make of that.
4. Why use AI agents to do physics research, and does the human (dp) actually check anything? The landing page says no outside physicist reviewed it, which makes me wonder how much to trust any of it.
5. What will Gaia DR4 actually show me on 2 December, if it "cannot confirm anything new"? Why should I care about the date?

### Verdict
The core story is genuinely interesting and refreshingly honest: a big idea, tested in public, that lost to a 40-year-old theory, with the clearest explanation I've seen of why "matching the old theory" doesn't count as winning. The beginner signposts ("New here? Stop here", the "in plain words" summaries) work when I find them. But every beginner page is wrapped in expert footnotes, dated revision notes and Greek letters, so I spent more effort ignoring things than reading them. Strip the beginner path down to the plain-English layer and this would be a great Reddit link.

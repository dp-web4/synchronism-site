# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 2: Technical Writer

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: partial
- **Would return?**: maybe
- **Overall impression**: The site is unusually candid, and the Beginner Path scaffolding works. The trouble is that changelog text, internal audit notes and cross-page numbers that have drifted apart are mixed into the reader-facing copy, and the result often can't be scanned and sometimes contradicts itself.

### Journey
I started on the landing page. The hero opens with a clear one-line idea (the 0-to-1 "crowd vs marching band" dial), followed by roughly 900 words before the first call to action. The "Start here" CTA appears three times, with "New here?" interrupts at lines 13, 19 and 55 of the page. Readers will find the CTA, but the page is effectively an index, a scoreboard, a changelog and a methods note all in one. Each section tries to protect a beginner with "you can stop here" signals, which suggests the structure itself is the problem. The "Below this line: for people checking the work" divider is a good device. It just arrives too late, after the hero has already covered MOND, Bell tests, Gaia DR4 and the "family of versions" caveat.

Next I followed the Beginner Path: Why Synchronism (step 1) → First Encounter (step 2) → Galaxy Curve Plotter (step 3). The step counters and Prev/Next links agree on all three pages, and they match the index's description (step 4 What Synchronism Is Not, step 5 Honest Assessment). Why Synchronism is the best-written page in the mirror. It has a short "what happened, in three lines" summary and an explicit "that is all you need" stop point, and it folds the technical material away. First Encounter's lettered sections A–G are well explained. Its expert notes, however, use BEC/BCS, CRT, QM and YBCO without expanding them on the page.

The Galaxy Plotter is labelled Beginner step 3, but it is by far the densest page I read. It does have a three-step "how to read this chart" box, though that box comes after several thousand words of calibration notes, revision notes and audit history. On this one page the text contradicts itself about the default chart: one passage says max C is 0.244 and another says 0.001, and the legend describes a ×1.78 constant boost that applies only to the non-default setting.

Off the path, Wide Binaries, Critical Density and Key Claims are written for physicists. That is reasonable, but they leave acronyms undefined (AQUAL on Wide Binaries, QUMOND, RUWE, IPD, M/L, Υ, L2/L3). Badge separators also vary: em-dash on one page, pipe on another, both in one badge on Critical Density. On Key Claims and the index, the same statistics differ in ways the text doesn't reconcile (details below).

Breadcrumbs: Home / Why Synchronism?; Home / First Encounter; Home / Interactive Tools / Galaxy Curve Plotter; Home / Cosmology / Wide Binaries; Home / Core Theory / Reference Density (ρ_crit); Home / Key Claims. They are internally consistent. However, "Cosmology" and "Core Theory" are hubs that don't appear in the top nav, and the mirror can't confirm whether they resolve. Wide Binaries sitting under Cosmology is surprising, since the page itself is about local gravity tests. Key Claims and Research Archive appear in the footer but not in the top nav.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| Key Claims, "What's not on this page" (BTFR paragraph) | "1 selected Synchronism over MOND (2 discriminated, one selected each)" contradicts the index ("2 of those 4 discriminated… and both selected the MOND class"). Read literally, it says one test favoured this framework. | high | Fix to "both selected MOND". This is the single most misleading sentence I found. |
| Key Claims, claim 1 caveat ("Count currency") | Says "the site-wide count is 4 executed refutations on external data". The index and footer say 6 (5 on external data + 1 construction check). | high | Change to the current count, or pull the number from the same source as the footer. |
| Site-wide (index, Why Synchronism, Galaxy Plotter, Key Claims, Critical Density) | Revision notes and "until 2026-xx-xx this said…" text is mixed into the body copy, often mid-paragraph. Readers can't separate current claims from history. Some pages fold this away ("Revision notes (history…)"), many don't. | high | Move all dated corrections into one collapsed changelog per page, or a site-wide errata page. Keep the body in the present tense. |
| Galaxy Plotter, "What You're Seeing" + legend | "This galaxy's maximum C(ρ) is 0.001" and "the violet line is Newton's shape ×1.78" describe the units-hybrid setting. The default since 2026-11-14 is the 0.028·V^0.5 knee, where the same page reports max Cρ = 0.244 and a varying boost. | high | Regenerate these captions from the selected setting, or label them "(units-hybrid setting only)". |
| Galaxy Plotter (Beginner step 3) | The beginner orientation ("How to read this chart, in three steps") comes after very long technical blocks. "New here? That is the whole lesson" appears mid-page, after physics content. | high | Put the three-step reading guide and chart right after the intro. Collapse everything else under one "For physicists" fold. |
| Why Synchronism vs index vs Key Claims (galaxy counts) | Why Synchronism: "14,610 galaxies (175 SPARC + 14,585 ALFALFA–SDSS (quality cut))". 175 + 14,585 = 14,760, not 14,610. The index, plotter and Key Claims give 14,435 as the quality-cut figure. | medium | Change to 14,435 on Why Synchronism. Key Claims already explains the three numbers; link to that. |
| Environment test ID | The same environment test is called TEST-03s (index ledger table), TEST-03/05 (Why Synchronism badge), "TEST-08" (Key Claims claim 3), and TEST-03 with "never run as registered" elsewhere. | medium | Pick one canonical ID and add a one-line alias note on the Test Roadmap. |
| Critical Density vs Galaxy Plotter / Wide Binaries | The archive's +0.5 velocity exponent is "excluded at ~6σ" on Critical Density but "~3.5σ" on the Plotter and Wide Binaries (same measured −0.16 ± 0.19). | medium | Reconcile and state the figure in one place. |
| Critical Density / Plotter / Key Claims | The A-coefficient gap is given as 635×, 644× and "about 600×" for nominally the same discrepancy. 644 is explained as the archive's figure, but readers have to work that out. | medium | Use one number and footnote the others once. |
| Index vs Why Synchronism (ontology status) | Why Synchronism: "the broader frame behind it has been ruled out as well". Index: "the ontology underneath is untested rather than refuted" / "partly tested". | medium | Align these. The beginner page currently makes the stronger claim. |
| Chemistry "1,703" | Index: a counter, "not a corpus size". Why Synchronism: "1,703 logged chemistry sessions". First Encounter: "~1,700 chemistry sessions (a session counter…)". | medium | Use the index phrasing everywhere ("phenomenon-type counter"). |
| Badges, site-wide | Separators are inconsistent: the index says text after a dash is a descriptor, Why Synchronism says "after the bar", and Critical Density uses both ("Audited-Negative — A-from-Jeans \| scale-dependent…"). Wide Binaries' badge is a full sentence ("Untested — Self-Eliminating-or-Tie — density branch identically null…"). Casing also varies ("audited-negative" / "Audited-Negative"). | medium | Set a style rule: Badge — short descriptor (≤5 words), with explanations in body text. Apply it everywhere. |
| Badges defined per page | Index and Key Claims define their badges inline (good). Wide Binaries ("Untested") and Critical Density ("Audited-Negative") don't. Their only explanation is an ⓘ icon. | medium | Add the same one-line "Badges on this page:" key every page uses. |
| Index, "Which label answers which question" | Five label systems (status badge, scoreboard word, ledger class, operational state, lifecycle verb) are introduced in one paragraph. That is a lot of taxonomy for a landing page. | medium | Move this to the Glossary or Honest Assessment and keep one sentence on the index. |
| Wide Binaries | AQUAL, QUMOND, RUWE, IPD, AU, M/L and PREREG are undefined on the page. AQUAL is expanded only on Key Claims, and QUMOND nowhere in the mirror. | medium | Expand on first use, or add an abbreviation key like the index's. |
| Index (pre-key content) | SPARC, Υ, M/L, a0′, gbar/gobs, L2/L3 and μ/ν appear in the "Which C" table and the scoreboard before, or without, the abbreviation key. L2/L3 ("algebraic reading", "action") is never defined. | medium | Move the key above the first table and add L2/L3 and Υ to it. |
| First Encounter | BEC/BCS (expert note), CRT ("Two Reframes for the CRT analogy"), QM (Section F header) and YBCO aren't expanded on this page. A stray "Continue ↓ Section B" label shows in the text render. | low | Expand inline. Check that the stepper control has a text fallback. |
| Galaxy Plotter, checkbox location | "stay hidden unless you tick them below the chart" vs "behind a checkbox above the chart". | low | Pick one. |
| Galaxy Plotter, "Why a second (amber) curve?" | Describes "the dotted one" and "the solid one" as two amber curves. Elsewhere amber is only the dotted stand-in, and solid is violet. | low | Rewrite as "Why show the amber stand-in next to violet?" |
| Galaxy Plotter, mass-model note | Says the toy disc "survives only as the density profile fed to Cρ", but the formula box says SPARC surface densities replaced it on 2026-11-17. | low | Update the note. |
| Wide Binaries, γ symbol | Acknowledged clash: γ = boost here vs the framework's shape parameter. The note comes after γ has already been used on the page with the framework meaning. | low | Rename the boost (e.g. "boost B" or γ_g) throughout this page, as Key Claims did with κ. |
| Wide Binaries, stat tiles | "Gaia DR3 · ~6 months estimated analysis time · 10⁴ AU" tiles look stale next to the DR4 section (the superscript also renders as "104 AU" in text). | low | Update or remove the tiles. Use "10^4" in text fallbacks. |
| Terminology for ρcrit | Called "reference density", "knee", "saturation knee", "switch-over density", "switch" and "critical density" (URL/title), with "crit" kept only for legacy. | low | Settle on "knee (ρcrit)" in prose. Keep the glossary entry naming the synonyms. |
| Site-wide meta-language | "simulated-visitor persona", "explorer", "maintainer" and file paths (maintainer/scripts/…) appear in reader copy without definition. | low | Define once on Research Philosophy and link it. Move file paths to a "sources" footnote. |
| Index "Where to Start" cards | In the text render, each step label sits above a different card heading, so "Shortcut · also Beginner Path step 5 of 5" reads as if it belongs to Research Philosophy. | low | Put the step label inside its card, after the title. |
| Footer vs index roots | Footer: "3 against the framework's own content". Index: "5 roots, only 2 of them specific to this framework". Both are said to be valid groupings, but they sit next to each other without a bridge. | low | Use one grouping in the footer and link to "counting rules" for the others. |

### Tools Tested
- Galaxy Curve Plotter: text only in the mirror, so I couldn't operate it. **Confusing.** The controls (galaxy buttons, Υdisk slider, knee-law selector, two checkboxes) are described clearly. The captions around them, though, describe two different default states (max C 0.244 vs 0.001; varying boost vs constant ×1.78), so a reader can't tell what the chart currently shows. The "Model Explainer" tool type vs claim-status badge distinction is well explained.
- Coherence Explorer and γ Calculator are referenced from the index and First Encounter but aren't in the mirror. Not evaluated.

### Unanswered Questions
1. What is the canonical ID for the environment test: TEST-03, TEST-03s, TEST-03/05 or TEST-08?
2. Did any discriminating test favour Synchronism over MOND? Key Claims seems to say yes and the index says no.
3. What exactly are the "L2" and "L3" readings mentioned on the index?
4. Where do the "Core Theory" and "Cosmology" breadcrumb hubs live, and why aren't they in the top nav?
5. Is the ~6σ or the ~3.5σ figure for the +0.5 velocity exponent the current one?
6. What is the complete set of nine badges? The index links to it, but none of the mirrored pages lists all nine.

### Verdict
As documentation, the site has a sound skeleton: a numbered Beginner Path with working Prev/Next links, plain-language summaries with explicit stop points, and abbreviation keys and badge legends on several pages. It undermines that skeleton by mixing a running changelog into the body copy and by letting the same numbers, IDs and verdicts drift between pages. The Key Claims "selected Synchronism" sentence and the stale "4 refutations" count are the clearest cases. Splitting history from current claims and running a single-source pass on the recurring numbers (counts, test IDs, σ values) would do more for clarity than any rewrite of the physics.

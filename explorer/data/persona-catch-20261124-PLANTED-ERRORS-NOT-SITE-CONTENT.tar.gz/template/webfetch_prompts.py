"""Extract WebFetch calls (url, prompt) from today's real visitor transcripts; count usage of Bash/curl as alternative."""
import json, glob, os, collections, sys
D = "/home/dp/.claude/projects/-home-dp-ai-workspace-synchronism-site-visitor"
files = sorted(glob.glob(D + "/*.jsonl"), key=os.path.getmtime)[-int(sys.argv[1]):]
tools = collections.Counter()
for f in files:
    print("====", os.path.basename(f))
    for line in open(f):
        try:
            o = json.loads(line)
        except Exception:
            continue
        msg = o.get("message") or {}
        if msg.get("role") != "assistant":
            continue
        for c in msg.get("content") or []:
            if isinstance(c, dict) and c.get("type") == "tool_use":
                tools[c["name"]] += 1
                if c["name"] == "WebFetch":
                    inp = c["input"]
                    print(" ", inp.get("url", "")[38:80], "|", inp.get("prompt", "")[:230].replace("\n", " "))
print(tools)

# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 1: Casual Science Enthusiast

### Summary
- **Pages visited**: 5 (index, why-synchronism, first-encounter, galaxy-plotter, plus a quick bounce off key-claims and wide-binaries; the last two count as glances, not reads)
- **Understanding achieved**: partial
- **Would return?**: maybe
- **Overall impression**: The pitch ("we tried one big idea, it lost, here's how you can tell") is clear and actually pretty cool, but every page buries its simple core under a mountain of physicist footnotes and revision history.

### Journey
**Landing page.** The headline grabbed me: "What if one equation described reality from quantum to cosmic?" The marching band vs. crowd picture made sense right away. Then the next sentence told me they tested it and it didn't work. That surprised me, but in a good way: it's not the usual "one weird theory solves physics" Reddit link. Within about 60 seconds I knew three things: it's an idea about how "together" things act, it failed against galaxy data, and the site is the record of that failure. So the value proposition did land.

What slowed me down: the hero section is one huge paragraph. Before I even reach the "Start here" button it covers superconductors, "γ = 2/√Ncorr", "hand-assigned Ncorr", "no measurement protocol", Bell tests, "nearest neighbours" and Gaia DR4. I didn't understand why a superconductor scores low, and the explanation made it worse. The site did keep telling me to stop scrolling and press "Start here" (I counted three "New here?" signposts), which was kind. I scrolled a bit further anyway, hit "C(ρ) = tanh(…)", the table of four different C functions, "ΔBIC +2,843", and a row about the Bohm class, Lorentz invariance and "one-loop lattice checks". I gave up and clicked Start Here.

The Gaia DR4 date (2 December 2026, next week!) was the most exciting thing on the page. Then the same sentence said it "cannot confirm anything new", which deflated it.

**Why Synchronism? (step 1).** This was the best page for me. "What happened, in three lines" is exactly what I wanted. The answer to "why does matching an existing theory count as losing?" finally made it click: if your formula just turns into MOND, you haven't added anything. Good. I stopped at "that is all you need from this page", as told. I peeked into the fold. The crowd/marching band part was fine. The superconductor/γ paragraph lost me again ("sign-inverted", "back-solved from a fitted γ").

**First Encounter (step 2).** Sections A and B were readable. Comparing the neutron star to a lone electron worked. "tanh is like a dimmer switch" and "ln makes 10×, 100×, 1000× into evenly spaced steps" were explanations I could actually use. Section C is where it got hard. There are three versions of γ (the proposed formula, γ=2, and the fitted 0.5), plus "+0.55 predicted, −0.55 measured". I followed the gist (the knob either fails or turns into MOND) but not the details. Section E dropped "ρ_crit = 0.028 × V_flat^0.5" on me. I didn't know what a power of 0.5 on a speed meant here, and I skimmed it. The a₀ ≈ cH₀/2π "coincidence" box was interesting, and I liked that it said "probably a coincidence" up front. Section F (quantum measurement, the Zeno effect) went over my head, but the one-line status ("an interpretation… same predictions as standard QM") told me what I needed. Section G was short and clear.

**Galaxy Curve Plotter (step 3).** The top three bullets are great. Dots = measured, gray = visible matter only, green = MOND fits, violet = this idea doesn't. Plus "Why should the gray line fall at all?", the Neptune comparison. That is the dark-matter puzzle explained better than some YouTube videos. Everything after that is a wall. Amber lines, "units-hybrid", "division vs quadrature wiring", "Ωm floor", "Υdisk", revision notes about which simulated visitor caught what. I can't operate the tool in the mirror, but even reading the text I got confused about what the violet line actually does. One part says the violet line is "the gray line times 1.78 at every radius" and "the boost is the same everywhere". The DDO 154 box says it's 1.44× at the centre, "rising to" 1.78× further out. Which one is on my screen by default? The page seems to describe two different settings without saying clearly which is the default in each place. There's also an "amber" curve that's "hidden unless you tick it", but the text keeps asking "Why a second (amber) curve?" as if I can see it.

**Key Claims / Wide Binaries (glances).** Key Claims has a nice "three claims, one sentence each" box. After that it says "the rest of this page is written for readers with some physics", so I left. Wide Binaries opens with a status badge that's a full sentence of jargon ("Self-Eliminating-or-Tie — density branch identically null in the ratio…"). I bounced within seconds, even though "two stars orbiting each other far apart" is a fun topic I'd have liked to learn about.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| Landing page hero | One giant paragraph mixes the clear pitch with superconductor caveats, γ = 2/√Ncorr, Bell tests and Gaia DR4. The beginner reads all of it before the Start button. | high | Keep the hero to the first ~4 sentences (idea, it failed, why that's interesting, AI-run notebook) and the Start button. Move the superconductor and Bell asides below the fold. |
| Landing page, superconductor note | Explained twice in the hero/intro using Ncorr and γ, which a beginner hasn't met. It confused me more than it helped. | medium | One plain sentence: "This 'coherence' is not quantum coherence. Superconductors score low; that's one of the things that went wrong." Link out for the why. |
| Landing page, Gaia DR4 | The most exciting hook (data next week!) is immediately undercut by "cannot confirm anything new". | low | Fine to be honest, but say in plain words what a beginner should watch for on Dec 2 (e.g. "it may settle whether MOND is right about weak gravity"). |
| Landing page, "Where each piece stands" table | The Bell row is a huge paragraph about Bohm, retrocausality, Lorentz, one-loop lattices. A casual reader scrolling past sees a wall. | low | Collapse long rows by default, like the "for physicists" blocks. |
| Landing / plotter, "simulated-visitor persona" revision notes | Lots of notes like "a graduate simulated-visitor persona noticed…". A newcomer doesn't know what these are, and they read like internal chatter. | medium | Hide revision notes behind one "page history" toggle per page, or define "simulated visitor" once. |
| First Encounter §C | Three different γ values (formula, 2, 0.5) and a ±0.55 correlation in one section. I lost the thread. | medium | Lead with the "γ in three lines" summary (it's good!) and fold the paragraph above it. |
| First Encounter §E | "ρ_crit = 0.028 × V_flat^0.5" appears with no plain-words version. | medium | Say "the switch point is set from how fast the galaxy spins" and fold the formula. |
| Galaxy Plotter | It's step 3 of the Beginner Path, but about 90% of the page is expert material ("units-hybrid", "division vs quadrature", Ωm floor, Υdisk). | high | Put the beginner intro and the chart at the top, then ONE "for physicists" fold containing everything else. |
| Galaxy Plotter, violet line description | The legend and "What You're Seeing" say the violet line is a constant ×1.78 / "the same boost everywhere". The DDO 154 box says 1.44× rising to 1.78× at the default setting. It seems to contradict itself about the default. | medium | Make the beginner-facing legend and "What You're Seeing" describe the default (archive) setting, and label the other text "under the alternative setting". |
| Galaxy Plotter, amber curve | The text explains "Why a second (amber) curve?" even though amber is hidden by default. | low | Only mention amber inside the checkbox's own explainer. |
| Wide Binaries badge | The status badge is a whole jargon sentence and the first thing on the page. | medium | Short badge ("Untested") plus a plain one-liner: "This test can't tell this idea apart from MOND." |

### Tools Tested
- Galaxy Curve Plotter — not operable in the mirror (text only), so I can't say whether it works — the beginner explanation at the top is intuitive, the rest is confusing — The three-bullet "what to look at" intro and the Neptune analogy are excellent. The galaxy buttons and the Υdisk slider are described, but the slider explanation ("mass per unit of 3.6 μm light") meant nothing to me. The descriptions of the violet line seem to disagree about what the default setting shows.
- Coherence Explorer / γ Calculator — mentioned on First Encounter ("Best hands-on intro on the site") but not in the mirror, so not tested.

### Unanswered Questions
1. Why exactly does a superconductor score low if it's the most "marching band" thing there is? The site says the formula gets it backwards, but I didn't get *why* in words I understood.
2. What will I actually be able to read about on December 2 when Gaia DR4 comes out? Will this site post something?
3. If the AI agents "share a training distribution" and no outside physicist reviewed this, how much should I trust the parts that say it failed? (I assume failing is the safer claim, but the site doesn't say that to beginners.)
4. Is the "presence" idea (temperature, catalytic surfaces…) part of the theory or not? It's mentioned once on the landing page and then dropped.
5. What does the violet line look like on my screen by default: constant ×1.78, or changing with radius?

### Verdict
As a Reddit clicker, I came away actually understanding something: what the dark-matter puzzle looks like, what MOND is in one sentence, and why "turns into an old theory" counts as a loss. That's more than most science links give me, and the honesty is refreshing. But every page makes me dig the beginner layer out from under physicist footnotes and revision logs, and the Beginner Path's own step 3 (the plotter) is mostly expert material. I'd come back for the Gaia DR4 news if someone linked it, but I wouldn't browse here for fun.

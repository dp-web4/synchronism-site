"""Run persona passes against the offline mirror (clean or planted) in isolated run dirs.

usage: python3 run_personas.py <spec>  where spec is a JSON list of [cond, persona, rep]
       python3 run_personas.py probe
Mapping run_id -> (cond, persona, rep) is written to /tmp/pcatch/runmap.jsonl (scorer stays blind via run_id).
"""
import json, os, shutil, subprocess, sys, time, secrets, concurrent.futures as cf

ROOT = "/tmp/pcatch"
TPL = f"{ROOT}/template"
ENV = dict(os.environ, CLAUDE_CODE_DISABLE_AUTO_MEMORY="1")
BASE_CMD = ["claude", "-p", None, "--model", "opus",
            "--tools", "Read,Edit,Write,Glob", "--allowedTools", "Read,Edit,Write,Glob",
            "--setting-sources", "", "--strict-mcp-config",
            "--settings", '{"autoMemoryEnabled": false}', "--output-format", "json"]

def setup(cond, persona, rep):
    rid = secrets.token_hex(3)
    d = f"{ROOT}/runs/{rid}"
    os.makedirs(d)
    shutil.copytree(f"{ROOT}/{cond}", f"{d}/site")
    shutil.copy(f"{TPL}/CLAUDE.md", f"{d}/CLAUDE.md")
    with open(f"{d}/log.md", "w") as f:
        f.write("# Synchronism Visitor Browse Log — offline mirror\n\nPersona pass over the offline mirror in ./site/\n")
    with open(f"{ROOT}/runmap.jsonl", "a") as f:
        f.write(json.dumps({"run": rid, "cond": cond, "persona": persona, "rep": rep}) + "\n")
    return rid, d

def run(cond, persona, rep):
    rid, d = setup(cond, persona, rep)
    prompt = open(f"{TPL}/p{persona}.txt").read()
    cmd = list(BASE_CMD); cmd[2] = prompt
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=d, env=ENV, capture_output=True, text=True, timeout=1500)
        out, err = p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        out, err = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), "TIMEOUT"
    dt = time.time() - t0
    open(f"{d}/result.json", "w").write(out)
    open(f"{d}/stderr.txt", "w").write(err or "")
    return rid, cond, persona, rep, round(dt), os.path.getsize(f"{d}/log.md")

def probe():
    d = f"{ROOT}/runs/probe"
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    shutil.copytree(f"{ROOT}/clean", f"{d}/site")
    shutil.copy(f"{TPL}/CLAUDE.md", f"{d}/CLAUDE.md")
    cmd = list(BASE_CMD); cmd[cmd.index("opus")] = "haiku"
    cmd[2] = ("Without using any tools first: list every CLAUDE.md, memory, or project-instruction block present in your context "
              "(quote its first line), and say whether you see anything about 'Synchronism' refutations in context. "
              "Then use Glob to list ./site/*.txt and Read the first 5 lines of ./site/index.txt.")
    p = subprocess.run(cmd, cwd=d, env=ENV, capture_output=True, text=True, timeout=300)
    print(p.stdout[-3000:]); print(p.stderr[-2000:])

if __name__ == "__main__":
    if sys.argv[1] == "probe":
        probe(); sys.exit()
    spec = json.loads(sys.argv[1])
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        for r in ex.map(lambda s: run(*s), spec):
            print(json.dumps(r), flush=True)

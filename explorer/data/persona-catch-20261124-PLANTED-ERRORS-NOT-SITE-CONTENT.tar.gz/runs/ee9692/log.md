# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 4: Leading-Edge Researcher

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (to read the negative results on density-keyed couplings, not the framework itself)
- **Overall impression**: The site's own verdict is correct: nothing here that differs from MOND + ΛCDM has survived. The best things on the site are its generic negative results on density-keyed gravity (lunar laser ranging, BBN, and the vertical Kz gradient), but they are written up without the two literatures they belong to: Refracted Gravity and symmetron/chameleon screening.

### Journey
I opened the landing page and went straight to the "Where each piece stands" scoreboard. It is the most useful object on the site, and it already answers my main question. The density law is excluded. The acceleration-keyed law is a MOND interpolating function. The dark-energy sector is Λ at γ = ½. The quantum side has no rate parameter. The local substrate is excluded by Bell. The only row left standing that differs from constant-a₀ MOND is a₀(z) = cH(z)/2π. ΛCDM-with-baryons simulations make the same prediction, the RC100 run came out inconclusive (1.11 measured, 1.74 predicted, 1 for constant a₀), and the idea is Milgrom's. So **no surviving prediction differs from both MOND and ΛCDM**. The "0 confirmed novel predictions" headline is accurate, and if anything it is generous to the framework.

I spot-checked the algebra and numbers and they hold up:
- tanh(γ ln(1+x)) = [(1+x)^{2γ}−1]/[(1+x)^{2γ}+1] exactly. At γ = ½ this gives x/(x+2) = μ_simple(x/2), and (1−C)/C = 2/x, so ρ_DE = 2ρ_crit = const.
- The minimum transition width at large γ is ≈1.17 decades (atanh 0.9 / atanh 0.1 ≈ 14.7).
- C(ρ) is concave in ρ for every γ. I checked the sign of the second derivative: it is −(n+1)(1+x)^n + (n−1) < 0 with n = 2γ.
- The steepest point in log ρ at γ = 2 sits at C ≈ 0.60.
- A = 4π/(β_J² G R₀²) = 4.6×10⁻⁵ M☉ pc⁻³ (km/s)⁻².
- a₀²/(4πGV²) = 6.3×10⁻³ M☉/pc³ at 200 km/s, and ρ_Λ/2 = 4.3×10⁻⁸.
- cH₀/2π = 1.04×10⁻¹⁰ (1.13×10⁻¹⁰ at H₀ = 73), Σ₀ = 119 M☉/pc², and 1/(G a₀) = 62.8.
- Chae's Γ → γ conversion (0.042 → 1.21, 0.102 → 1.60).
- The no-EFE simple-ν boost of 3.70 at 0.1 a₀, and the Milky Way field at the Sun of ≈1.8 a₀.
- The Bell numbers: Hensen S = 2.42 ± 0.20 at p = 0.039, Giustina at 11.5σ, Shalm at p = 2.3×10⁻⁷.
- Bovy & Rix 68 ± 4 M☉/pc², Hofmann & Müller Ġ/G, Collins et al. 2004, Bell 1986 Phys. Rep. 137, 49, and Wharton & Argaman RMP 92, 021002.

The arithmetic discipline is good.

**Missed connections. These are the most important findings of this pass.**
1. **Refracted Gravity is direct prior art for the headline equation.** Matsakos & Diaferio (2016) use a gravitational permittivity ε(ρ) = ε₀ + (1−ε₀)·½{1 + tanh[Q ln(ρ/ρ_c)]} inside a modified Poisson equation ∇·[ε(ρ)∇φ] = 4πGρ. Cesare, Diaferio and collaborators tested it on DiskMass/SPARC-type data in 2020–22, and Sanna et al. 2023 give a covariant version. That is a tanh of log local density with a floor, which is essentially Cρ with the Ωm floor (Cf), already published and fitted to rotation curves. The site uses Refracted Gravity only as a source for one knee value (0.0083 M☉/pc³) and never names it as prior art for the functional form. The Key Claims argument that "the density-keyed substitution is the one AQUAL rejected in 1984 because it diverges in vacuum" also needs this context: Refracted Gravity's floor ε₀ avoids exactly that divergence. The divergence objection applies only to the unfloored division wiring, and Key Claims does say it is wiring-conditional.
2. **Symmetron and chameleon screening** (Hinterbichler & Khoury 2010; Khoury & Weltman 2004; review: Burrage & Sakstein 2018). A coupling that switches off above a critical matter density and acts below it is exactly the "density knee" idea, with real field equations. Those theories settle the site's unresolved smoothing-scale question (what is lab G? pointwise or smoothed ρ?) through the scalar field's Compton wavelength and the thin-shell effect, and they come with a large body of laboratory, Solar-System and astrophysical constraints. The density-keyed law's open problems are already solved or excluded there.
3. **The local-fluid P(k) bound |2γ−1| ≲ 10⁻⁵ on the dark-energy page** is the Sandvik, Tegmark, Zaldarriaga & Waga (2004, PRD 69, 123524) "end of unified dark matter" result for generalized Chaplygin/Cardassian fluids, with α ≲ 10⁻⁵. Cite it. The fluid interpretation of Cardassian models is Gondolo & Freese (2003).
4. **DESI DR2.** This is the one live anomaly where a new dark-energy form could earn its keep, and the site never says plainly whether the family can produce the DESI-preferred w₀w_a shape with a phantom crossing. By my algebra, ρ_DE ∝ x/((1+x)^{2γ}−1) is monotonic in x for every γ. That means w(z) stays on one side of −1 and cannot cross it. The near-Λ γ = 0.487 fit therefore cannot pick up DESI's crossing signal. That is a clean, citable statement and it is missing.

**What I think is genuinely worth something.** The lunar-laser-ranging bound (a density-keyed G changes as the Sun moves through the disc), the BBN G-ratio argument, the Kz vertical-gradient argument, and the virial-ratio ceiling x ≲ 0.019β_J² are generic constraints on any density-keyed modification of G. If someone ran them against Refracted Gravity's actual ε(ρ), with its own Q and ε₀ rather than the compander with Refracted Gravity's knee plugged in, the result could be a short paper. The joint "Bell escape + absolute clock" framing (a preferred-frame forward tick needs a Bohm-class foliation hidden from radiative corrections at 10⁻¹⁸–10⁻³⁰) is a nice synthesis of Bell 1986, Collins et al. 2004 and Dürr et al. 2014, but it is not new.

**Is A2ACW sound?** As a discovery method it is not calibrated, and the site says so. The canonical-discovery benchmark (Dirac, Bell, BCS, …) cannot calibrate anything because every item is in the training data; Youden's J = 0 under the literal rule. Two further problems:
- (a) **Citation hygiene is the main failure mode, and the site shows it.** "Saurabh & Desmond 2024" was withdrawn as a likely recall error, and Park et al. 2026, Saglia 2025 and Pasquini 2026 are still "locators pending". I also suspect **arXiv:2610.40388** (Chae, Park & Yoon): a five-digit sequence number above 40,000 would mean more than 40k submissions in one month, which is implausible at current volumes. Please verify it.
- (b) **The corrections loop is AI personas auditing AI output.** Almost every revision note credits a "simulated-visitor persona". That catches internal inconsistencies, as the many fixes show, but it cannot supply the out-of-distribution knowledge whose absence produced misses 1–3 above. Those are the things a human referee in modified gravity would flag in the first five minutes.

**Wide binaries.** The physics on this page is right. EFE-suppressed MOND gives 1.0–1.4× in g. The density branch cancels in the wide/close ratio, and no outcome selects the framework, which is honest. My one concern is the long "in-house" hidden-companion paragraph. It is better hedged than it apparently used to be, but it is still a substantive, uncontacted, one-session analysis of a live dispute, published on a public page. Either write it up and send it to Chae et al. and to Saad & Ting, or cut it to one sentence. The 2023–2024 Newtonian-leaning analyses are also undersold: Banik et al. 2024 (MNRAS 527, 4573) claim Newton is preferred over MOND at ~16σ, which is stronger than "Newtonian-consistent". Chae 2024 (arXiv:2309.10404) appears to be published as ApJ 960, 114; please check the volume.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| key-claims, critical-density, galaxy-plotter | Refracted Gravity (Matsakos & Diaferio 2016; Cesare+2020–22; Sanna+2023) uses a floored tanh(ln ρ) permittivity. That is prior art for the headline C(ρ) and for Cf. It is cited only as a knee value. | high | Add it as the closest prior art for the density-keyed form, ahead of superfluid DM. Rerun the LLR, BBN and Kz arguments on Refracted Gravity's actual ε(ρ). |
| wide-binaries, key-claims | Symmetron/chameleon screening literature is never mentioned, although it is the field-theoretic version of a "density knee" and resolves the smoothing-scale ambiguity that conditions the BBN and lab-G arguments. | high | Add a prior-art paragraph and state where the density law sits relative to symmetron constraints. |
| key-claims ("P(k) pins \|2γ−1\| below 10⁻⁵") | Same result as Sandvik et al. 2004 for unified-dark-matter fluids, but uncited. | medium | Cite Sandvik et al. 2004 PRD 69, 123524 and Gondolo & Freese 2003. |
| key-claims / dark-energy sector | No statement on whether the family can reproduce DESI DR2's w₀w_a phantom crossing. ρ_DE(x) looks monotonic, so it cannot. | medium | Add one line: "the family cannot cross w = −1; DESI's evolving-DE signal gives it no foothold." |
| wide-binaries | arXiv:2610.40388 has an implausibly high sequence number. Chae 2024 "volume not checked" (likely ApJ 960, 114). | medium | Verify every locator. Treat any LLM-recalled identifier as unverified until resolved. |
| wide-binaries ("Status: still hung") | A long, uncontacted in-house reanalysis of the 36-system dispute, on a public page. | medium | Contact the authors or reduce it to a one-line pointer to the script. |
| index ("Refutations executed" cell) vs index scoreboard row | The scoreboard row says Crater II was dropped on 2026-11-20 (disrupting, not an equilibrium test). The refutations cell still cites "Draco and Crater II … 4.5σ and 4.2σ". | medium | Remove Crater II from the refutations cell. |
| galaxy-plotter ("What You're Seeing", legend, formula box, mass-model note) | Several passages describe the units-hybrid behaviour as if it were the default: "never moves off its floor", "boost the same everywhere", "Newton's shape ×1.78", "Cρ < 10⁻³ on every disc", "toy disc survives only as the density profile fed to Cρ". They sit next to the default-knee number max C = 0.244, which gives Cf ≈ 0.48 and a radially varying boost (1.44–1.78× in v). | medium | Rewrite these passages for the 0.028·V^0.5 default, or tag them explicitly "units-hybrid only". The mass-model note contradicts the 2026-11-17 switch to SPARC Σ. |
| index (line beginning "The one distinctive move") | Says "the ontology underneath is untested rather than refuted", while the same page reports local substrates excluded by loophole-free Bell tests and the preferred-frame sector excluded by 15–27 orders of magnitude without an unexhibited protection mechanism. | medium | Use "partly tested; local and naive preferred-frame versions excluded", which the hero paragraph already says. |
| critical-density ("Freeman's Σ₀ ≈ 4% error") | A percentage match, while Key Claims says sub-percent matches were retired because the observable only supports a factor of ~2 (M/L). | low | Replace with "consistent within the factor-~2 M/L systematic". |
| galaxy-plotter / TEST-25 | In-house Cassini significances (15–21σ) sit next to Desmond+2024's marginalized 8.7σ. The compander is called "μ-form" (AQUAL-like) but run through QUMOND, and the AQUAL and QUMOND quadrupoles differ at O(1). | low | State the μ→ν conversion used, and lead with the marginalized published number everywhere. |
| first-encounter §C | "Predicted +0.55, measured −0.55" looks like a sign flip of one number rather than two independent results. | low | Give n, the uncertainty and the source, or explain why the magnitudes are identical. |
| index hero | "The one galaxy test that could tell it apart" contradicts the "2 discriminating tests (TEST-09, TEST-10)" elsewhere. | low | Say "the galaxy tests that could tell it apart". |
| site-wide | Revision notes and counting-rule bookkeeping (6 / 4–8 / ≤5 roots) bury the physics. A referee has to dig to find the three or four results that matter. | low | Add a one-screen "for researchers: transferable results" list: the LLR/BBN/Kz constraints on density-keyed G, the Möbius identity, and the virial-ratio ceiling. |

### Tools Tested
- Galaxy Curve Plotter: text only in the mirror, evaluated from the disclosed formulas. The baryon model is now SPARC's own (V_gas|V_gas| + Υ V_disk² + 1.4Υ V_bul²) and the MOND reference is the real simple-ν with one global a₀, which is a fair like-for-like comparison. The equations are correct as written. The problem is that much of the explanatory text still describes the old 0.029·V² setting while the default is 0.028·V^0.5 (see Friction Log). A single uniform thickness h = 0.3 kpc is a real bias for gas-dominated dwarfs, where HI flares. It is disclosed, but x ∝ 1/h, so DDO 154's crossing is sensitive to it.
- DR4 reading key table (wide-binaries; static): the boost-to-γ mapping matches the compander's Q2/EFE logic. Dating it before the data is good practice, but it is not adopted, so it has no force.

### Unanswered Questions
1. Why is Refracted Gravity, a published, data-tested, floored tanh-of-log-density modified Poisson equation, not named as prior art for C(ρ)? Do the LLR, BBN and Kz exclusions carry over to its actual ε(ρ)?
2. Can any γ in the dark-energy family produce a w = −1 crossing, and has the DESI DR2 + Pantheon+/DES-SN5YR w₀w_a fit been compared directly rather than only fitting γ?
3. Which smoothing prescription defines ρ? The BBN, lab-G and LLR arguments all depend on it. A symmetron-style field equation would fix it. Has one been written down?
4. Has arXiv:2610.40388 been resolved to a real paper? How many other identifiers on the site were checked by retrieval rather than recall?
5. Under the "dark matter in step / out of step" ontology, what does the framework predict for the Bullet Cluster lensing offset beyond "fails like any local-baryon theory"? Is there any cluster-scale content left?

### Verdict
The 0-novel-predictions verdict holds up under expert scrutiny: every surviving piece is MOND, Λ, or a non-unique a₀(z). The site's honesty and arithmetic are better than most human-written alternative-gravity sites I review. Its blind spot is the one A2ACW cannot see: it misses Refracted Gravity and symmetron/chameleon screening, the two literatures that already contain its central idea and the field equations that would settle its open smoothing question. The salvageable contribution is a short note applying the LLR, BBN and Kz constraints to density-keyed G theories like Refracted Gravity. That would need a human referee and verified citations before it could go anywhere.

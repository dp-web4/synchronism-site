# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 1: Casual Science Enthusiast

### Summary
- **Pages visited**: 5 (index, why-synchronism, first-encounter, galaxy-plotter, key-claims). I didn't open wide-binaries or critical-density; the titles sounded like specialist pages and I'd stopped by then.
- **Understanding achieved**: partial
- **Would return?**: maybe
- **Overall impression**: The site is honest in a way that hooked me ("We proposed this. We tested it. It did not hold as stated."), but each page after the opening paragraphs buries me in symbols, acronyms and correction notes.

### Journey
**Landing page.** The headline is a good hook: "What if one equation described reality from quantum to cosmic?" The one-line idea also landed for me: everything gets a number from 0 (a crowd of strangers) to 1 (a marching band) for how much its parts act together. Then it says right away that the idea didn't hold up. As a Reddit visitor I didn't expect that. It made me trust the site more, but it also made me ask why I should keep reading about a theory that failed. Answering that question is the site's real pitch, and the landing page never states it outright. I think the answer is "watch how science gets tested," but I worked that out myself. The equation C(ρ) = tanh(γ · ln(ρ/ρcrit + 1)) is visible near the top. "Smooth S-curve" helped, but tanh and ln mean nothing to me. Below the fold, the scoreboard section is a wall of acronyms: MOND, ΛCDM, SPARC, ΔBIC, BTFR, RAR, CHSH, A2ACW. I skimmed straight past it. Clear calls to action ("Start here: Why Synchronism? ~8 min") saved the page, so I clicked that.

**Why Synchronism?** The opening is great: "quantum rules for the very small, gravity for the very large, and no one equation for both." I've seen that framing on PBS Space Time, so I was on board. The crowd vs. marching band and dimmer-switch analogies work. The superconductor test was the most satisfying part of the site for me. The theory predicted 607 K and the real answer was 93 K, so it was plainly wrong, and I could see why without any physics. After that it quickly turns into "Debye-model restatements", "Abrikosov–Gor'kov", "compander", "Hill/Naka–Rushton", "kill criterion", "R²". Sentences like "the formula is audited-negative and sign-inverted… arguably empty rather than merely inverted" lost me. By the end I couldn't tell what the idea claims and what the tests showed. The landing page said this page takes about 8 minutes, but the page itself gives no reading time.

**First Encounter.** It's billed as the gentle 10-minute intro. The marching-band intro is nice, but the next thing I read is a spoiler: the formula gives superconductors, the most "in step" materials, a *low* score. That's the opposite of the picture I'd just been given. So the analogy is set up and knocked down in the same paragraph, and I didn't know which one to keep in my head. One thing helped a lot: ln explained as "10×, 100×, 1000× become evenly spaced steps." I actually got that! Then γ = 2/√N_corr arrives, followed straight away by "did not survive testing (predicted +0.55, measured −0.55)". After that come a₀ ≈ cH₀/(2π), BCS, BEC, quantum Zeno and Markov blankets. Seven sections in 10 minutes felt rushed, and I skimmed D through F. The page mentions a Coherence Explorer with sliders and calls it the "best hands-on intro on the site", but I couldn't use it today. I also noticed that the end of section G says "Continue ↓ Section B", which looks like a leftover label.

**Galaxy Curve Plotter.** The "New here? Look at three things on the chart" opening is the friendliest instruction on the site, and "a rotation curve is just how fast things orbit" was exactly what I needed. I understood the story: visible matter alone predicts stars should slow down at the edges, they don't, and that gap is the dark matter puzzle. MOND (green) fits the dots, and Synchronism's line (violet) doesn't. That was the clearest "aha" of my visit. Without the chart, though, I had to take the colours on trust. Below that the page explodes into Bessel functions, ΔBIC, Υdisk, "units hybrid", Cassini quadrupole and dated revision notes ("Since 2026-11-10…"). For something labelled Beginner Step 3, I bailed about a third of the way down.

**Key Claims.** The "In plain words: the three claims, one sentence each" box is great. I'd move it to the top. The three claims are: quantum weirdness comes from things falling into step (can't be tested), consciousness as an "acting as one" level (placeholder), and dark matter as matter that's out of step (tested, failed). Those three sentences were the clearest summary of the whole project I found anywhere on the site. The page then admits "the rest of this page is written for readers with some physics", so I stopped there. That was fair warning. One thing confused me: the intro promises "not restatements in different notation", but half the cards are labelled Reparametrization, which the page defines as exactly that. The refutation count also varies from section to section (1, 4, 6, "4–8").

I didn't open Wide Binaries or Critical Density. Nothing on the pages I read made them sound like beginner material, and by this point I'd had my fill of acronyms.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| Index | The page says the theory failed but never says why a newcomer should keep reading | high | Add one sentence for curious readers, e.g. "Read on to see how an idea gets tested and what it got wrong" |
| Index | The scoreboard is a wall of acronyms (ΔBIC, BTFR, RAR, CHSH, A2ACW) right below the hero section | medium | Collapse it behind "For people checking the work", or lead with a one-line plain summary |
| Index | The tanh/ln equation sits near the top of the landing page | low | Show the words version first and put the equation behind a "show the equation" toggle, as Why Synchronism already does |
| Why Synchronism | After the strong opening the jargon wall arrives fast (Debye, Abrikosov–Gor'kov, compander, Naka–Rushton) | high | Move the technical caveats into the "For physicists" fold and keep the main column in plain language |
| Why Synchronism | Stacked hedges ("audited-negative… sign-inverted… arguably empty") make it hard to tell what was claimed and what was found | medium | Use a simple two-column "We said / Data said" table |
| Why Synchronism | The landing page promises "~8 min" but this page shows no reading time | low | Show the reading time on the page itself |
| First Encounter | The marching-band analogy is contradicted by the spoiler in the very next lines | high | Teach the idea cleanly first, then reveal the failure in a dedicated section (G already exists for that) |
| First Encounter | 7 sections with 4 to 5 formulas and many terms (BCS, BEC, Zeno, Markov blanket) don't fit in "10 minutes" | medium | Cut D to F from the beginner path, or raise the estimate honestly |
| First Encounter | Section G ends with "Continue ↓ Section B" | low | Fix the stale label |
| First Encounter | The best hands-on tool (Coherence Explorer) is only mentioned in passing | low | Make it a prominent step in the Beginner Path |
| Galaxy Plotter | Labelled Beginner Step 3, but most of the page is Bessel functions, ΔBIC and revision history | high | Keep the beginner page to the chart and the three-step reading guide, and move the formula box and changelog to a separate "technical notes" page |
| Galaxy Plotter | Dated revision notes ("Since 2026-11-10…", "used to say…") clutter the body text | medium | Move them to a changelog |
| Galaxy Plotter | Text alone can't confirm the result (no numbers, only colours) | low | Add one plain sentence with numbers, e.g. "at 30 kpc stars move at ~150 km/s; Synchronism predicts ~X" |
| Key Claims | The best plain summary (three one-sentence claims) is not at the top | medium | Move it right under the title |
| Key Claims | The intro says "not restatements", yet several cards are labelled Reparametrization (= restatement) | medium | Reword the intro, e.g. "claims that were *intended* to be new; here's how each fared" |
| Site-wide | The refutation count differs (1, 4, 6, "4–8") between pages and sections | medium | Use one headline number everywhere and link to the counting rules |

### Tools Tested
- Galaxy Curve Plotter — not operable today (text only); the text loads — the three-step "how to read this chart" guide is intuitive, but the rest of the page is confusing — The core story (gray line sags, green MOND fits, violet Synchronism fails) came through in words, but without the picture I couldn't check it. The sliders and "For physicists" dropdown are beyond me.
- Coherence Explorer / γ Calculator — only mentioned on First Encounter, not reachable today — they sound like the most beginner-friendly thing on the site, but I couldn't try them.

### Unanswered Questions
1. If the main idea failed, what is the site *for* now? Is it a lesson in how science works, an ongoing project, or an archive?
2. What does "AI-run research notebook" actually mean? Did AIs come up with the theory? What's an "A2ACW session", and why are there 3,300 of them?
3. If MOND fits the galaxies so well, why isn't MOND the accepted answer to dark matter? (The site assumes I know.)
4. Why does the formula score superconductors low if they're the most "in step"? Was that a bug in the idea or in the math?
5. What do the wide-binaries and critical-density pages add for someone like me? Nothing pointed me there.

### Verdict
The first paragraph of almost every page is excellent: clear, humble and honest about failure in a way I've never seen from a "theory of everything" site, and the superconductor and galaxy-curve examples gave me real "oh, I get it" moments. But each page then drops into specialist detail and correction notes within a screen or two, so a casual reader learns *that* it failed long before learning *what the idea was*. If the beginner path kept to plain language and moved the physicist material elsewhere, I'd happily share this on Reddit as a great example of science checking itself.

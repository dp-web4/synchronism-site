# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 4: Leading-Edge Researcher

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe. I would come back for the Gaia DR4 post-mortem and the falsification ledger, not for new physics.
- **Overall impression**: As physics there is nothing new here. Every surviving sector reduces exactly to MOND or Λ. Unusually, the site says so itself. The one ingredient that departs from baseline MOND, a₀(z) = cH(z)/2π, is listed on the index and then never tested.

### Journey
I started on the **index**. Its verdict, "dead so far: no prediction that differs from MOND or the standard cosmology has survived", is the right headline, and I rarely see that kind of candour. I skipped the motivation on **why-synchronism** and **first-encounter** and went looking for anything with a free parameter that MOND or ΛCDM does not have.

**The MOND reduction is exact, not approximate.** Key-claims gives the identity tanh(½ ln(1+x)) = x/(x+2) = μ_simple(x/2). I checked it: tanh(½ ln u) = (u−1)/(u+1). So the acceleration-keyed compander at γ = ½ *is* Milgrom's simple μ with an effective a₀ = 2a₀′. For general γ the deep-MOND limit is C ≈ γx, so a₀,eff = a₀′/γ. The only place γ shows up is the shape of the transition region. Free γ converges to 0.49 with RMS "identical to McGaugh-MOND to four digits", which is consistent with exactly ½. The site should say outright that the fitted a₀′ is about a₀/2 (or a₀/γ in general). Otherwise a reader comparing a₀′ to 1.2×10⁻¹⁰ will be confused.

**The tanh family cannot describe a phase transition.** First-encounter says the switch is "never narrower than a factor of 15 in density". I verified this: atanh(0.9)/atanh(0.1) ≈ 14.7, so the 10–90% width in x is fixed for any γ. An analytic function with fixed log-width has no N→∞ sharpening and no critical exponents. That is a structural reason the "calculable quantum/classical threshold" and the critical-exponent claims could never work. It is more basic than the empirical failures the site lists, and the site should state it as such.

**Density-keyed branch.** Its distinctive predictions were a boost ceiling at 1/Ωm = 3.17, an environment dependence, and a knee scaling as V^+0.5. All three failed, and they failed decisively. Dwarf LSBs routinely have g_obs/g_bar ≫ 3.17. ΔBIC is +8,404 at the archive knee. The measured knee scaling is V^−0.16±0.19. I accept these. Capping the boost at 1/Ωm was never motivated anyway: the cosmic dark-to-baryon ratio is Ωm/Ωb ≈ 6.4, not 1/Ωm.

**Wide binaries.** The numbers check out:
- ν_simple(0.1) = 3.7, as stated.
- The Galactic external field at the Sun is about 1.8 a₀.
- r(g = a₀) ≈ 7,000–10,000 AU for 1–2 M☉.

The page's observation that a density-only G_eff is absorbed into the binary's mass (ratio ≡ 1) is correct and useful. Bounding it instead with the vertical K_z dynamics is the right move. I also agree with the bottom line that no DR3 or DR4 outcome selects Synchronism.

The page has a logical gap, though. It says the acceleration branch "predicts MOND's wide-binary boost, EFE included", and it maps DR4 boosts onto γ. Meanwhile the galaxy-plotter page says a "canonical coupling is still required for the EFE". Without a field equation (an AQUAL- or QUMOND-type Lagrangian for C), the EFE is undefined, so the γ reading key has no theoretical basis. Of the cited works, Chae 2023/2024, Banik+2024 and Pittordis & Sutherland 2023 are the ones I know. I can't verify the 2026 arXiv IDs from here. Given the site's own history of "recall error" citations, every one of them needs checking.

**Cassini.** The site reports that simple-μ and McGaugh-ν fail Cassini at 15–21σ. Desmond, Hees & Famaey 2024, which the site cites, give 8.7σ after marginalising. The in-house number is roughly twice the published one and needs reconciling. It is also an overclaim to say "the MOND formula fails" in general. The Cassini quadrupole constraint rules out specific ν families in QUMOND/AQUAL with the EFE. Interpolating functions with sharper transitions survive.

**BTFR test (TEST-09).** The framework predicts slope 3.35, the page quotes MOND at 3.81, and the observed value is 3.75. Deep MOND predicts exactly 4. A quoted "3.81" has to be a finite-range or estimator-dependent number, and the page doesn't say how it was obtained. The page does admit the kill is "convention-dependent". It should specify the estimator: V_flat vs V_max, orthogonal vs forward fit, and how gas mass is handled. As written the kill is ambiguous.

**Critical density.** This page has the most internal bookkeeping trouble:
- The 0.028 coefficient has no stated units.
- The discrepancy factor appears as both 635× and 644×.
- ρc0 is never defined.
- β_J is 1.1 ± 0.2 empirically, but the formula uses 4.5.
- The cosmological knee is "calibrated so that C₀ = Ωm". In other words Λ is renamed, as the index admits ("Is Λ").

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index | Lists a₀(z) = cH(z)/2π, the only element that departs from baseline (constant-a₀) MOND, but never presents it as a test. At z≈2, H ≈ 3H₀, which shifts the BTFR zero-point by ~0.5 dex at fixed V. That is testable against KMOS3D/RC100/JWST high-z kinematics. | high | Register it as a Tier 1 test. Note the prior art (Milgrom's own a₀–H₀ speculation and emergent-gravity variants), so even a pass is "shared" rather than unique. |
| key-claims | "0 confirmed predictions" sits alongside "1 selected Synchronism over MOND (2 discriminated, one selected each)". A reader will see a contradiction. | high | Explain what was selected, and why it doesn't count as a confirmation. |
| wide-binaries vs galaxy-plotter | Wide-binaries says the acceleration branch predicts MOND's boost "EFE included". Galaxy-plotter says the coupling needed for the EFE is unregistered. | high | Without a field equation the EFE prediction is undefined. Either supply a Lagrangian or label the DR4 γ-mapping as assuming QUMOND. |
| galaxy-plotter / key-claims | Cassini given as 15–21σ against the cited published 8.7σ. "MOND fails Cassini" is stated too generally. | medium | Reconcile with Desmond+2024. Restrict the claim to the specific ν families tested. |
| key-claims (TEST-09) | "MOND 3.81" BTFR slope; deep-MOND predicts 4. The estimator is unspecified. | medium | Give the fitting convention, and the MOND slope from the same pipeline on SPARC with real baryonic models. |
| index / galaxy-plotter | The headline ΔBIC +184 is per point. Per galaxy it is ≈ +11, or +2.7 with Υ free. Per-point BIC with correlated within-galaxy residuals overstates significance. | medium | Lead with the galaxy-block numbers. |
| why-synchronism vs key-claims | ALFALFA–SDSS count is 14,585 on one page and 14,435 on the other; 175 + 14,435 = 14,610 is the consistent total. | low | Fix why-synchronism. |
| critical-density | 635× vs 644×. Units for 0.028 missing. ρc0 undefined. β_J of 1.1 vs 4.5. | medium | One units-explicit table, and one canonical value for each quantity. |
| first-encounter / why-synchronism | The fixed ~15× log-width isn't identified as the structural reason tanh(γ ln(1+x)) can't produce sharp transitions or critical exponents. | medium | State it. It explains several failures at once. |
| all physics pages | Missed connection: density-keyed coupling strength that switches off above a critical density is exactly the screened-modified-gravity phenomenology (symmetron, chameleon, dilaton). It comes with mature constraints: Eöt-Wash, atom interferometry, Desmond & Ferreira galaxy-scale fifth-force tests. | high | Compare the density branch with symmetron screening explicitly. Environment-dependent signals are not unique to this framework either. |
| first-encounter §F / key-claims | Missed connection: "collapse as a density/boundary crossing" already has a quantitative template in CSL (rate set by smeared mass density) and Diósi–Penrose. Both have hard bounds: LISA Pathfinder, cantilevers, underground Ge X-ray (parameter-free DP excluded). Decoherence and quantum Darwinism aren't discussed at all. | high | If the quantum sector is ever to have "a number to test", phrase it as a point in (λ, r_C) space. |
| critical-density / index | No mention of DESI DR1/DR2 evolving dark energy (w₀wₐ preference at ~3–4σ). A density-keyed C evaluated at ρ(z) would in principle give a w(z), which is a channel that could discriminate from Λ. | medium | Compute w(z) implied by the cosmological knee and compare with DESI+CMB+SNe, or state why it's identically −1. |
| index (cosmology) | Recombination test fails (1.5× vs 5.4× needed); clusters need a second parameter. Both are the known MOND failures. | low | Name the parallel, and the relativistic completions (e.g. Skordis–Złośnik AeST) that this framework would have to match or beat. |

### Tools Tested
- Galaxy Curve Plotter: evaluated from text only (not operable today). The formulas are scientifically correct: the SPARC baryonic sum with V_gas|V_gas| and Υ_bul = 1.4Υ_disk, simple-ν MOND, ρ = Σ/2h, and the BTFR 47 vs 1/(Ga₀) = 62.8 coefficient check. It is honest about circularity, since V_flat is an input. It is confusing that the green "MOND" benchmark (simple ν) differs from the function used in the ΔBIC test (McGaugh ν), and from what the page says fails Cassini. The page admits this, but readers will still conflate them.
- Other interactive tools: not available.

### Unanswered Questions
1. Is a₀(z) = cH(z)/2π a commitment of the framework? If so, why isn't high-z BTFR/RAR evolution the top Tier 1 test? It is the only sector where the predictions differ from Milgrom's baseline.
2. What field equation governs C in the acceleration branch? Without one, the EFE, wide-binary and cluster predictions are undefined.
3. Has the density branch been compared with symmetron/chameleon screening constraints, which already exclude large regions of exactly this phenomenology?
4. What was the "1 selected Synchronism over MOND" result, and how is it compatible with "0 confirmed"?
5. Have the 2026 wide-binary citations been verified by a human against arXiv, given the earlier withdrawn "recall error" entries?
6. A2ACW: 3,300 sessions run by agents with a shared training distribution. Novelty calibration gives specificity 0/6, i.e. Youden J = 0. What independence assumption makes "adversarial" meaningful here? Has any claim ever been checked by a non-LLM reviewer?

### Verdict
The site's own "0 unique confirmed predictions" verdict is accurate. If anything it is generous: every discriminating test that was run (boost ceiling, BTFR slope, environment, V-scaling of the knee) killed the distinctive version. What survives is the simple-μ MOND function and a renamed Λ, with γ as a transition-shape parameter that Cassini already constrains. As a discovery engine, A2ACW is not sound. Its novelty filter has zero discriminating power, its agents fail in correlated ways, and its citations need human verification. As a falsification-and-audit engine it worked well, and a public negative-results ledger like this has some real value. The one direction I would pursue is redshift evolution of a₀, framed as a test shared with emergent-gravity proposals rather than claimed as unique. It should be benchmarked against screened-gravity and CSL constraints, which the site currently ignores.

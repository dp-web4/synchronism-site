# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 3: Graduate Physics Student

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (for Gaia DR4 on 2 Dec 2026, to see whether the pre-dated reading key is honoured)
- **Overall impression**: This is not a crank ToE pitch but a strikingly self-critical post-mortem. Nearly every derivation I re-did checks out arithmetically, the site already identifies its own reparametrizations, and the badges are, if anything, harsher than I would have been. Still, it has a few arithmetic slips, an overloaded symbol, and density that makes it hard to read.

### Journey
A colleague called this an "AI project", so I went in expecting a grand-unified sales pitch with "Validated" stickers on fits. The **index** sets that expectation aside in its first paragraph: "We proposed this. We tested it. It did not hold as stated." It also gives "0 confirmed predictions, 6 refutations" and "As tested physics, dead so far." It says "Validated" is a deprecated badge. On every page I saw, the only badges were Failed, Reparametrization, Speculative and Audited-Negative, so there were no dishonest Validated badges to find.

I went straight to the equations.

**The core function, C(ρ) = tanh(γ ln(1 + ρ/ρcrit)).** why-synchronism says outright that tanh is "a phenomenological choice", the log is "chosen too", and "there is no variational principle or self-consistency equation that selects tanh." This answers my main question about a mean-field origin. A Curie–Weiss solution is an *implicit* self-consistency equation, m = tanh(β(Jzm + h)). This function is an explicit compander of ln ρ, with no coupling, no temperature and no order parameter. Any claim that it came from mean-field theory would be false, and the site, to its credit, makes no such claim on these pages.

**The γ = 2/√Ncorr ansatz.** first-encounter and why-synchronism both call it inverted and circular. Ncorr is back-solved from the fitted γ, and the γ assigned to the most-correlated systems is the smallest. That critique is physically right. Fluctuation and finite-size arguments make transitions *sharper* as the number of correlated degrees of freedom grows, so the slope should scale like √N, not 1/√N. The site even reports the galaxy-level sign flip (predicted correlation +0.55, measured −0.55).

**The reparametrization identity on key-claims.** I verified it:
- tanh(γ ln(1+x)) = [(1+x)^{2γ} − 1]/[(1+x)^{2γ} + 1] follows exactly from tanh u = (e^{2u} − 1)/(e^{2u} + 1).
- At γ = ½ this becomes x/(x+2) = μ_simple(x/2).
- With x = g_obs/a0′, the acceleration-keyed C is exactly MOND's simple interpolating function with a0 = 2a0′. The fitted γ ≈ 0.49 on the plotter sits on top of it.

So the "fits galaxies" version *is* MOND, and the site says so. That is the correct identification, and it is the most important one.

**Other numbers I checked by hand:**
- **critical-density:**
  - tanh(2 ln 2) = 0.882 ✓; the C = ½ midpoint is at ρ ≈ 0.316 ρcrit ✓.
  - The low-density ramp C ≈ γρ/ρcrit ✓.
  - A = 4π/(G R0²) with G = 4.30×10⁻³ pc (km/s)² M☉⁻¹ and R0 = 8 kpc gives 4.6×10⁻⁵ ✓, and 0.029/4.6×10⁻⁵ ≈ 635 ✓.
  - 3/16π² = 0.0190 ✓.
  - ρ_Λ/2 ≈ 4.3×10⁻⁸ M☉/pc³ at H0 = 67.4 ✓.
  - The MOND-tracking knee a0²/(4πGV²) = 6.3×10⁻³ at V = 200 km/s ✓.
  - (c/2πV)²·(2/3)ρc0 is algebraically equal to a0²/(4πGV²) with a0 = cH0/2π ✓.
  - The 6.6–10.4 dex gap between galactic and cosmological knees ✓.
  - NGC 3198: 0.028·√150 = 0.343, giving ρ/ρcrit = 2.64 ✓; 0.029·150² = 652 ✓.
- **a0 = cH0/2π:** ≈ 1.04×10⁻¹⁰ m/s² at H0 = 67.4 (13% low) and ≈ 1.13×10⁻¹⁰ at H0 = 73 ✓. This is Milgrom's 1983 coincidence, and the site badges it Reparametrization, correctly. Σ0 = a0/2πG is the same number, and the site says so.
- **first-encounter:** "never narrower than a factor of ~15 in density" is correct. At large γ, C ≈ tanh(γx), and 10%→90% spans γx = 0.10→1.47, a factor of 14.7 ✓.
- **galaxy-plotter:**
  - Midplane density Σ/2h is correct for an exponential vertical profile.
  - Υ_bul = 1.4 Υ_disk matches the SPARC convention.
  - The old BTFR toy levelling at (47/62.8)^{1/4} ≈ 0.93 Vflat ✓, since 1/(G a0) ≈ 62.9 M☉ (km/s)⁻⁴.
  - DDO 154: ρcrit = 0.028·√47 = 0.19 ✓.
- **wide-binaries:**
  - Density-keyed boosts at ρ = 0.09, ρcrit = 0.42: +64% (γ = 2) and +223–225% (γ = 0.489) unfloored; +33% and +62% with the Ωm floor. All ✓.
  - Without the external field effect (EFE), MOND's simple ν(0.1) = 3.70, which is +92% in velocity ✓.
  - Chae's Γ → γ = 10^{2Γ}: 0.102 → 1.60 and 0.042 → 1.21 ✓.
- **Cosmology:** Ωc/Ωb = 5.4 ✓; boost cap 1/Ωm = 3.17 ✓. A capped boost of 3.17 is obviously killed by low-surface-brightness (LSB) outskirts with boosts above 10, and the site reports exactly that (TEST-10: 106/153 discs exceed the cap).
- **Bell numbers:** Giustina p = 3.7×10⁻³¹ quoted as 11.5σ; Hensen S = 2.42 ± 0.20. Both are correctly cited. The framework's substrate gives S = 1.85, which is a local model and therefore excluded. Correct.

**Statistics practice.** This is better than I expected. ΔBIC is reported both per point and per galaxy, with a galaxy-block bootstrap, and the site acknowledges that point-level BIC inflates evidence when residuals are correlated.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index (scoreboard) | "0.14% internal-consistency survival rate (≈47 candidate claims out of ~3,300 sessions)", but 47/3,300 = **1.4%**, not 0.14%. This is off by 10×, assuming the fetcher quoted it correctly. | medium | Recompute. Either the numerator or the percentage is wrong. |
| wide-binaries ("What MOND predicts") | "√1.4 ≈ 1.24" and "up to about +24% in velocity". In fact √1.4 = 1.18, so a 1.4× boost in g is about **+18%** in velocity. A +24% velocity boost needs about 1.54× in g. | medium | Fix to +18%, or restate the g-range as 1.0–1.5×. |
| why-synchronism vs index/key-claims | why-synchronism gives "175 SPARC plus 14,585 ALFALFA–SDSS" next to a total of 14,610. That sums to 14,760, the figure the same page says was corrected. Index and key-claims say 14,435. | medium | Use 14,435 everywhere. If 14,585 is the pre-cut cross-match for TEST-03, label it as such. |
| wide-binaries, key-claims, plotter | **Symbol collision:** γ means the compander width in C, the gravity boost g_obs/g_N (Chae's convention, "⟨γ⟩ = 10.82" in Session #581), and the γ in γ = 2/√Ncorr. The DR4 "reading key" maps boost-γ to compander-γ in one table, which is a recipe for misreading. | medium | Rename the boost (e.g. B = g_obs/g_N) and keep γ for the compander. |
| key-claims, TEST-09 BTFR line | "1 selected Synchronism over MOND (2 discriminated, one selected each)" is opaque. With a prediction of 3.35 ± 0.07 against data of 3.75 ± 0.10 (≈3.3σ off), and MOND at 4 (≈2.5σ off on this measurement), the data are closer to MOND. It is unclear what "selected Synchronism" means here. The observed slope also depends on the convention (Vflat vs Vmax, fitting method). | medium | State the metric used for "selected", and quote the slope convention and source (e.g. Lelli et al. 2019). |
| first-encounter §C | γ = 2 "loses to MOND… only just, once whole galaxies… are counted". By galaxy with Υ free, ΔBIC = +2.7 and the bootstrap 95% CI is −26 to +132, which includes 0. That is indistinguishable, not a loss. The Failed badge is still earned through the knee forms (ΔBIC +8,404 / +2,843), but this sentence overstates the γ = 2 result. | low | Say "statistically indistinguishable at galaxy level; loses per point". |
| critical-density | The Freeman Σ0 is listed at "≈4% error" while the page says it is the same number as a0, which is 13% off. Readers will ask how one number has two errors. The answer is that the Freeman reference value is soft (it depends on M/L and band), but the page doesn't say that. | low | Quote the Freeman Σ0 reference value and its M/L assumption. |
| why-synchronism vs critical-density | NGC 3198 mid-disc ρ is "about 0.6 M☉/pc³" on one page and 0.904 on the other, with no radius given. | low | Give the radius, or use one number. |
| wide-binaries citations | Chae, Park & Yoon "arXiv:2610.40388" has a 5-digit suffix above typical monthly arXiv volumes, so it looks suspicious. The page has already withdrawn one citation as a "likely recall error". | low | Spot-check every arXiv locator against arXiv before DR4 day. |
| wide-binaries header | The status badge is a ~50-word sentence ("Untested — Self-Eliminating-or-Tie — density branch identically null in the ratio but not in absolute dynamics…"). | low | Use a short badge and move the qualifiers into body text. |
| site-wide | Four different functions share the symbol C (Cρ, Cf, Cg, Ca), and the plotter's tested Ca uses x = (g_bar/a0)^{1/φ} while key-claims' MOND identity uses Cg keyed on g_obs. The site acknowledges this ("a family, not one theory"), but on each page I had to work out which C was meant. | medium | Always subscript C on every page, and add a one-line legend near each equation. |
| key-claims / plotter | The MOND identity holds for Cg (keyed on g_obs, no floor). The galaxy plotter's green curve uses simple-ν on g_N, while the ΔBIC tests use McGaugh's ν. The site flags the ν mismatch, but not which C-variant was actually fitted to get γ ≈ 0.49. | low | State explicitly which C and which ν produced γ ≈ 0.49. |
| (positive) all pages | Every page carries the same "0 confirmed · 6 refutations (4–8)" ledger, and there are dated correction notes. That is exemplary scientific hygiene. | — | Keep. |

### Tools Tested
- Galaxy Curve Plotter — not operated (text only), but the formulas were audited — physics is correctly represented. The baryonic baseline uses SPARC conventions correctly (helium 1.33, Υ_bul = 1.4Υ_d, V_gas·|V_gas|), MOND uses the genuine simple-ν with no per-galaxy fitting, and the density-law curve is honestly computed rather than fitted. It correctly notes that a curve built from Vflat can't predict Vflat. One display quibble: the quadrature-wired dashed curve "lies on the gray line", which raises the question of why it is shown at all.
- Coherence Explorer / γ Calculator — linked from first-encounter, not among the 7 pages, so not evaluated.

### Unanswered Questions
1. Which C-variant and which ν function produced the γ ≈ 0.49 fit? Is the point-level ΔBIC of +7 against MOND computed with Cg (exactly μ_simple at γ = ½) or with Ca?
2. What exactly does "selected Synchronism over MOND" mean in the TEST-09 BTFR slope entry, and which slope convention gives 3.75 ± 0.10?
3. Is there any statement of the ansatz's dynamics, the "Appendix D" Lagrangian the plotter mentions? Without a field equation I can't check conservation of momentum or the EFE in the density-keyed law. A G_eff(ρ) that depends on local density typically breaks momentum conservation, which is the classic issue Bekenstein & Milgrom 1984 solved.
4. Why are the density-keyed predictions still quoted at γ = 0.489 and γ = 2 at all, given that γ = 2/√Ncorr is retracted and the knee forms are excluded? Is any version of the density law still live?
5. Is the 0.14% (or 1.4%) survival-rate figure meant to be a calibration of the AI audit pipeline? If so, what is the denominator?

### Verdict
As physics, there is nothing here. The core function is a phenomenological compander, γ = 2/√Ncorr runs backwards relative to fluctuation theory, and the one version that fits galaxies is algebraically MOND's simple μ (I verified the identity). The interesting result is that the site *says all of this itself*. Its badges are honest (no Validated anywhere), its derivations check out arithmetically apart from two slips (a 10× percentage error and √1.4 ≈ 1.24), and it names its own reparametrizations correctly. I'd tell my colleague it is a well-documented negative result and a decent case study in AI-run research hygiene. The fixes it needs are notation hygiene and a few factual corrections, not more honesty.

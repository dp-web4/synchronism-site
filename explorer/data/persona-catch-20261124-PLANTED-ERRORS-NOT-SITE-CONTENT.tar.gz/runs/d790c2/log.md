# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 3: Graduate Physics Student

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (to watch the Gaia DR4 reading key on 2 Dec, not for the theory)
- **Overall impression**: An unusually honest post-mortem of a failed framework. Most of the numbers I re-derived check out, but I found a handful of real arithmetic and consistency errors, and the core function is mathematically mis-described as a "switch."

### Journey
I came in expecting a crank ToE and got a self-audit. The index says "As tested physics, dead so far," and gives 0 confirmed predictions and 6 refutations. "Validated" is explicitly deprecated: 0 of 9 audited claims survive, and the old Validated badge on the A-from-Jeans claim is retracted on critical-density. So the badge question has a quick answer: no page I saw carries a live "Validated" badge, and the badges that are there (Failed / Reparametrization / Speculative / Untested) are honest, if anything harsh on the project itself.

So I spent my time checking the math myself.

**The coherence function C(ρ) = tanh(γ ln(1 + ρ/ρcrit)).** The site admits there is no mean-field derivation. That's correct: no self-consistency equation m = tanh(βJm), no free energy, nothing. I'd go further. The tanh-of-log isn't a tanh in any physical sense. Algebraically, C = ((1+x)^{2γ} − 1)/((1+x)^{2γ} + 1), which is a Hill-type rational function of a power law. At γ = ½ it is exactly x/(x+2) = μ_simple(x/2). I verified the site's identity, so "matches MOND by construction" is right whenever x is an acceleration ratio. Two consequences the site gets only half right:
- dC/dx = γ sech²(γ ln(1+x))/(1+x) decreases monotonically for x ≥ 0. So **C is strictly concave in linear ρ, with maximum slope at ρ = 0**. The first-encounter description "S-shaped… flat at first, then rising, then levelling off" is false on a linear density axis. It only holds when plotted against ln ρ. There is no threshold at ρcrit. critical-density does correctly say "saturation knee… not a critical point."
- why-synchronism says "no γ makes the rise sudden." That's not quite right. For large γ, C ≈ tanh(γx) near zero, which is a very sharp rise, but it sits at ρ ~ ρcrit/γ → 0, not at ρcrit. The accurate statement is that no γ puts a sharp onset *at ρcrit*.
- "The +1 keeps C finite at zero density" is imprecise. Without the +1, C(0) = tanh(−∞) = −1, which is finite. The +1 fixes C(0) = 0 and keeps C non-negative.

**γ = 2/√Ncorr.** The site correctly calls this a dimensional ansatz that is sign-inverted relative to Ginzburg/mean-field intuition. Larger correlation volume should suppress fluctuations and *sharpen* a transition, not flatten it. It also correctly notes that Ncorr is never measured independently, so the relation is empty. Arithmetic checks: γ = 0.49 → Ncorr = (2/0.49)² ≈ 16.7 ✓; γ = 2 → Ncorr = 1 ✓. But the galaxy-plotter quotes "Ncorr ≈ 17" from the *acceleration-keyed* RAR fit, while the γ–Ncorr relation was defined for the *density* law. Those are different parameters sharing one symbol.

**ρcrit / A (critical-density).** I recomputed A = 4π/(βJ² G R₀²) with G = 4.30×10⁻³ pc (km/s)²/M☉ and R₀ = 8 kpc: 4.57×10⁻⁵ ✓. Back-solving A = 0.029 gives βJR₀ = 317 pc ✓, and the ratio (8000/317)² ≈ 637 ✓. The "4π factor is 12.57 of the 635" remark makes no sense, because 4π cancels in the ratio. Other checks:
- MOND-matched knee a₀²/(4πGV²) at 200 km/s = 6.3×10⁻³ M☉/pc³ ✓, and the identity with (c/2πV)²(2/3)ρc0 is correct.
- ρΛ/2 = 4.3×10⁻⁸ M☉/pc³ at H₀ = 67.4 ✓.
- C(ρcrit) = tanh(2 ln 2) = 0.88 ✓; midpoint at 0.316 ρcrit ✓.
- 3/(16π²) = 0.0190 ✓.
- cH₀/2π = 1.04×10⁻¹⁰ m/s², 13% below 1.2 ✓. H₀ = 2πa₀/c = 77.6 km/s/Mpc ✓.
- **Error:** critical-density says the V^+0.5 exponent is excluded at "~6σ" by −0.16 ± 0.19. It's (0.5+0.16)/0.19 = **3.5σ**, which is what wide-binaries says. The ~11σ for V² is correct.
- Σ₀ = a₀/2πG with cH₀/2π gives ≈119 M☉/pc². The "≈4% vs Freeman" figure depends on which Freeman Σ₀ is used (the usual ~140 gives ~15%). The value isn't stated.

**Galaxy plotter physics.** It correctly represents:
- the SPARC baryonic convention (Vgas|Vgas| + Υd Vdisk² + 1.4Υd Vbul², i.e. Υbul = 0.7 at Υd = 0.5);
- the simple ν(y) = ½ + √(¼ + 1/y);
- midplane ρ = Σ/2h.

A structural point the site doesn't state plainly: any version floored at Ωm (Cf = Ωm + (1−Ωm)C, g = gbar/Cf) saturates at g → gbar/Ωm as gbar → 0. Rotation curves then go Keplerian at large r. **A floored law can't produce asymptotically flat curves or a slope-4 BTFR, whatever the fit.** That's the real reason for the 3.17× ceiling failure and the BTFR slope of 3.35, and it deserves one sentence up front. The Vflat-keyed ρcrit is circular, and the page says so honestly.

**Wide binaries.** I re-derived most numbers:
- a(10⁴ AU, 2 M☉) ≈ 1.2×10⁻¹⁰ ✓; g_MW ≈ 1.8a₀ ✓; ν(0.1) = 3.70 ✓; 10^{2Γ} conversions ✓.
- Density-law boosts at ρ = 0.09, ρcrit = 0.42: factor 2.70 / 10.6 unfloored and 1.76 / 2.63 floored, i.e. +64%/+223% and +33%/+62% in v. All ✓.
- The 0.161 and 0.0083 knee numbers ✓.
- **Error:** "up to about +24% in velocity (√1.4 ≈ 1.24)". √1.4 = **1.18**.
- **Error (BBN leg):** the archive knee "predicts 0.37–0.57, excluded at 17–36σ". The 36σ corresponds to C = 0.095 (γ = 0.489, unfloored), which is outside the stated range. The range should read 0.09–0.57.
- **Error (BBN leg):** the Refracted-Gravity knee at γ = 2 gives C = 1 − 10⁻⁴ ≈ 1.000. That is *inside* G_BBN/G₀ = 0.99 (+0.06/−0.05), so "excluded at about 3σ" can't be right.
- The ratio-cancellation argument (a local G_eff absorbed into dynamical masses, so TEST-02's γg ≡ 1) is correct.
- The MOND+EFE framing (1.0–1.4×) is fair to both sides of the Chae/Banik dispute.

**Reparametrizations.** The site identifies them correctly:
- a₀ = cH₀/2π is Milgrom 1983.
- Freeman Σ₀ is the same number again.
- Γ = κ²(1−c) is correlated dephasing.
- Bell freezing c(d) comes from waveguide QED.
- The η factor is Abrikosov–Gor'kov.
- The chemistry correlations are the Debye model.
- C_g is a MOND interpolating function at every γ.

I didn't find a reparametrization they missed. If anything, C_a with exponent 1/φ is just a fitted Hill exponent, which they also say.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| first-encounter §B | C(ρ) described as S-curve "flat at first"; it is strictly concave in linear ρ (max slope at ρ=0); sigmoid only on log axis | medium | Say "S-shaped when plotted against log density"; add C'(0)=γ/ρcrit |
| why-synchronism | "no γ makes the rise sudden" is wrong for large γ (rise ~tanh(γx) near 0) | low | "no γ puts a sharp onset at ρcrit" |
| why-synchronism | "+1 keeps C finite at zero density": C(0) would be −1 (finite) without it | low | "+1 makes C(0)=0 and C≥0" |
| critical-density | V^+0.5 exponent "~6σ" from −0.16±0.19; correct is 3.5σ (wide-binaries has it right) | medium | Fix to 3.5σ; reconcile pages |
| critical-density | "4π factor is 12.57 of the 635" is incoherent, since the ratio is (R₀/317 pc)² ≈ 637 and 4π cancels | low | Delete or explain |
| critical-density | Σ₀ "≈4% vs Freeman" with no Freeman value stated; with Σ≈140 M☉/pc² the gap is ~15% | low | State the reference Σ₀ and M/L used |
| wide-binaries (MOND+EFE) | "√1.4 ≈ 1.24", actually 1.18 | medium | Fix; "+18%" (matches ~20% signal) |
| wide-binaries (BBN) | Archive-knee range "0.37–0.57" inconsistent with "17–36σ" (36σ needs C≈0.09) | medium | Range 0.09–0.57 |
| wide-binaries (BBN) | RG knee γ=2 predicts C≈0.9999, inside the bound, so it can't be "excluded at ~3σ" | high | Recompute; likely "not excluded" |
| galaxy-plotter / key-claims | γ≈0.49 from acceleration-keyed fit mapped to Ncorr≈17 via density-law relation (two parameters share one symbol) | medium | Use γ_ρ vs γ_g notation; drop Ncorr mapping for γ_g |
| galaxy-plotter | Doesn't state that any Ωm-floored law goes Keplerian as gbar→0, so it can't give flat curves / BTFR slope 4 | medium | One-line explanation; makes the Failed badge self-evident |
| all pages | Dense dated revision notes, multiple C forms (Cρ, Cf, Cg, Ca), and multiple knees bury the physics | medium | A single "formula sheet" box with which C each test uses |
| galaxy-plotter | "γ=2 disfavoured ~2σ, not refuted" (RAR) sits next to the "Failed" badge; reconcilable (different wiring) but confusing | low | State explicitly which wiring the Failed badge covers next to the 2σ line |

### Tools Tested
- Galaxy Curve Plotter: not operable today (text only). The formulas as written are physically correct: SPARC baryon sum, simple-ν MOND, Σ/2h midplane density, Ωm floor. The circularity of the Vflat inputs is disclosed. The amber "stand-in" is correctly labelled as hand-tuned. The text represents the physics accurately, apart from the γ/Ncorr symbol conflation.
- γ Calculator / Coherence Explorer: referenced but not available.

### Unanswered Questions
1. Which Freeman Σ₀ (and M/L) gives the "≈4%" figure?
2. Where does the "~6σ" on critical-density come from? Is it a different error bar, or a stale number?
3. How was the RG-knee γ=2 BBN exclusion computed, given C≈1?
4. Is the γ≈0.489 "free-γ SPARC fit" the density law or the acceleration law? key-claims and galaxy-plotter seem to refer to both.
5. The 0.028 coefficient in ρcrit = 0.028·V^0.5: what are its units, and where is the fit that produced it?
6. Was any free-energy or self-consistency route to C(ρ) ever attempted, or was tanh chosen from the start?

### Verdict
This isn't a crackpot ToE page. It's a candid record of a phenomenological curve failing everywhere it was tested, and the badges are honest. Most of the numbers I checked reproduce. The mathematical framing is weaker than the bookkeeping, though. The function is concave rather than a switch, the floored law structurally can't give flat curves, and γ means two different things across pages. There are also four checkable arithmetic slips: √1.4, 6σ vs 3.5σ, the BBN range, and the RG-knee "3σ". A physicist will spot these quickly, and they undercut the site's main asset, which is its credibility.

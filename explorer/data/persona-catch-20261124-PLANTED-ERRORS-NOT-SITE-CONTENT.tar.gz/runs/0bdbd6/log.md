# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 4: Leading-Edge Researcher

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (to watch the Gaia DR4 / DESI DR3 entries and the ledger, not because of the physics)
- **Overall impression**: The physics brings nothing new: where it works it is MOND (galaxies) or Λ (cosmology), and where it differs from them it has been excluded. The self-audit is unusually honest. The site's own headline, "0 confirmed predictions", holds up, and if anything it is generous.

### Journey
I went straight to the claims. The **index** gives the verdict up front: "no prediction that differs from MOND or ΛCDM survived the tests run so far", 0 confirmed novel predictions, 0 prospective tests completed, and 6 refutations (stated range 4–8). That framing saved me time. It also concedes the framework is "a family, not one theory": four functions share the symbol C, there are two candidate dynamics, and 12 choices between versions are still open. As a referee I would weight that last point most. A family with 12 unresolved branches cannot make sharp predictions, and the site admits as much.

**Checking the algebra.** I re-derived the central identity myself. With γ = ½, tanh(½ ln(1+x)) = x/(x+2) = μ_simple(x/2). Key the function on g_obs and the result is exactly simple-μ MOND with a₀ = 2a₀′. Key it on ρ and apply it in the cosmological sector, and ρ(1−C)/C = 2ρ_crit, which is constant, so the result is exactly Λ. Both "Is MOND" and "Is Λ" are therefore algebraic identities, not empirical coincidences, and the key-claims page says so. I also checked these numbers, and all are correct:
- C(ρ_crit) at γ = 2 is tanh(2 ln 2) = 0.88, and the midpoint sits at ρ ≈ 0.32ρ_crit.
- The MOND-matching knee a₀²/(4πGV²) is 6.3×10⁻³ M☉/pc³ at 200 km/s.
- ρ_Λ/2 is 4.3×10⁻⁸ M☉/pc³.
- 3/16π² = 0.0190.
- cH₀/2π is 1.04×10⁻¹⁰ m/s² at H₀ = 67.4, i.e. 13% low.
- H₀ = 2πa₀/c = 77.6.
- The simple-ν factor at 0.1a₀ is 3.70.
- The boost cap 1/Ω_m is 3.17.

The arithmetic on the site is better than in most arXiv submissions I referee.

**What is actually new?** I looked for any branch whose predictions differ from MOND + ΛCDM:
1. **Density-keyed C(ρ) (the headline equation).** This is the only genuinely non-MOND branch. The boost depends on ambient density, not on internal acceleration. It is dead on SPARC: ΔBIC +8,404 at the archive knee and +2,843 with one free global knee, and the locality no-go shows a ~1.7 dex offset between local ρ and g_bar. The RAR is tight in g_bar and the density law cannot reproduce that. On wide binaries it is "identically null in the ratio", because close-binary mass calibrations absorb the boost.
2. **Boost cap B_max = 1/Ω_m ≈ 3.17.** This does differ from MOND, and it is refuted outright: 579 SPARC points have g_obs/g_bar > 3.17, and deep-MOND dwarfs reach B ~ 10. TEST-10 is the clean kill. The site calls TEST-09 (BTFR slope 3.35 vs observed 3.75 ± 0.10) "convention-dependent", which is fair.
3. **Environment dependence.** MOND's EFE predicts this too, so it does not discriminate. The measured effect is null anyway (r² = 0.0001 against a >20% claim).
4. **a₀(z) = cH(z)/2π.** This is Milgrom-lineage prior art and gives no unique leverage.
5. **Quantum "synchronization".** An interpretation that reproduces QM via the Lüders/Zeno reset. The literal scan picture is excluded by single-photon interference and by Bell (S ≤ 2 substrate). All three quantum sub-cards are correctly badged as reparametrizations (Palma–Suominen–Ekert 1996 correlated dephasing, waveguide QED, dynamical decoupling).
6. **Consciousness at C ≥ 0.50.** f, D and S are undefined. This is not physics yet.

So the honest answer to "does any prediction differ from MOND + ΛCDM and survive?" is no. The "0 unique confirmed predictions" verdict is accurate.

**A possible untapped lever.** As far as I can tell, the cosmological sector is only discussed at γ = ½. My own back-of-envelope calculation: for x ≫ 1, ρ_DE ≈ 2ρ_crit·x^(1−2γ), which gives w → −2γ at early times and Λ-like behaviour late. That would make the cosmology a one-parameter w(z) family with a phantom past for γ > ½, which is exactly the DESI DR2 w₀w_a territory. The site quotes a DESI DR2 fit of γ = 0.487 (+0.024/−0.021), but on the 7 pages I could read it never shows the implied w(z), and it flags that the required knee "misses by a factor of thousands". If the knee problem kills this branch, the site should say so explicitly. If it doesn't, this is the only place I can see where the framework could make a non-Λ prediction for DESI DR3 or Euclid.

**Wide binaries.** The literature summary is current and even-handed: Chae 2023/2024, the Chae et al. 2026 36-binary 3D sample against Saad & Ting 2026 (with the disagreement traced to the semi-major-axis model), Banik 2024, Pittordis & Sutherland, and the Cassini quadrupole constraint. The MOND+EFE numbers (1.0–1.4× in g, up to about +24% in velocity) are right. The page correctly says no wide-binary outcome can select Synchronism. Two citation hygiene issues:
- arXiv:2610.40388 has a five-digit sequence number of 40,388, which is implausibly high for one month's submissions. It needs verifying.
- Park et al. 2026, Saglia 2025 and Pasquini 2026 are cited with "locator pending". For an AI-generated site, a citation without a locator is a hallucination risk until proven otherwise.

**Critical-density** is a candid post-mortem: A is calibrated, not derived; there is a units slip (0.029 vs 4.6×10⁻⁵); and the open 17σ β_J gap is listed. It ends with the right conclusion: "If one exists, the unifying object is a₀, not ρ_crit." I agree.

**A2ACW (AI-to-AI Adversarial Collaboration Workshop).** This is described only on the index: ~3,300 sessions, a 0.14% internal-consistency survival rate, and a novelty benchmark that flagged all six canonical discoveries as prior art (specificity 0/6). That benchmark shows the method cannot tell novelty from prior art. Further problems for a methods referee:
- Agents from the same model family produce correlated critiques, which is not the independent review that "adversarial" implies.
- The "12 pending version choices", 4–8 refutation counting rules and post-hoc wiring forks (quadrature vs division) are researcher degrees of freedom of exactly the kind preregistration exists to remove.
- Only 2 of 26 kill criteria are fully specified.
- Every quantitative test so far is a retrodiction.

As a **bookkeeping and self-falsification** method, it worked: it found its own failures and published them. As a **physics-generating** method, the evidence is that it rediscovers MOND, Λ and textbook formulas and labels them correctly only after the fact. It is not sound for generating physics, but it is reasonably sound as a public audit trail.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index / key-claims | Cosmological sector shown only at γ = ½ (= Λ). The implied w(z) for γ ≠ ½ (my estimate: w → −2γ at early times) is never written out, even though a DESI DR2 fit (γ = 0.487) is quoted. | high | Write out w(z) for general γ and say whether the knee problem kills it. This is the only branch with any chance of a non-Λ prediction for DESI DR3/Euclid. |
| wide-binaries | Citation arXiv:2610.40388 has an implausible sequence number. Three papers are cited with "locator pending". | high | Verify every arXiv ID and drop any citation without a locator until one is found. Unverified citations will cost an AI-generated site all credibility with referees. |
| wide-binaries | LLR (a bound on Ġ/G) and BBN (G_BBN/G₀, measured in a dense early universe) are used to exclude a *static* density-keyed boost near the Sun. Neither obviously constrains a time-constant boost in a sparse environment, and a static boost is absorbed into GM☉. | medium | Justify why each constrains the density law, or drop them. The vertical Oort/K_z argument is the relevant one. |
| critical-density / galaxy-plotter / wide-binaries | The density law has no stated smoothing scale ℓ and no field equation. Two problems follow. (a) Unsmoothed, the r⁻² solar-wind density gradient makes G vary with radius, which planetary ephemerides (INPOP/EPM) would kill outright. (b) A force rescaled by 1/C at the test particle's own location is non-reciprocal, so it violates momentum conservation (the pre-AQUAL problem). | medium | State ℓ and give an action, or list ephemerides and momentum conservation as further kills of the density branch. |
| galaxy-plotter | Missed discriminators for the density branch: ultra-diffuse galaxies (NGC 1052-DF2/DF4, near-Newtonian at low stellar density) and tidal dwarf galaxies. Clusters also need more than the 3.17 cap allows. | medium | Add them as kill tests. They are cheap with existing data and sharper than SPARC environment tests. |
| index | a₀(z) "survives only if bars are 1σ (≈4.4σ if 95%)", but the dataset is not named on the index. | medium | Name the high-z kinematic sample (e.g. Genzel-type RC samples or JWST) and give the bar convention explicitly. |
| critical-density vs galaxy-plotter | The V^+0.5 exponent is "excluded at ~6σ" on one page and "~3.5σ" on the other. The A mismatch is 635× in one place and 644× in another, and the coefficients 0.028 and 0.029 coexist. | low | Reconcile across pages, or state the different sample or level (point vs galaxy) each figure uses. |
| wide-binaries | Desmond, Hees & Famaey 2024 is quoted as implying "no deviation from Newtonian gravity in nearby wide binaries" without noting that this holds only within the QUMOND/interpolating-function families they tested. | low | Add the model-dependence caveat. |
| first-encounter | "10×, 100×, 1000× → 2.3, 4.6, 6.9" are ln(10ⁿ), but the formula uses ln(ρ/ρ_crit + 1), which gives 2.40 at 10×. Also 2/√10²⁴ = 2×10⁻¹², not ≈10⁻¹². | low | Fix the numbers or say "approximately ln(ρ/ρ_crit)". |
| wide-binaries / key-claims (text render) | Superscripts lost: "~104 AU" should read 10⁴ AU, and "512 = 29" should read 2⁹. | low | Check exponent rendering in the text and plain-HTML output. |
| galaxy-plotter | The green MOND benchmark uses simple ν, which the site itself says Cassini excludes. | low | Use McGaugh's RAR function as the benchmark and keep simple ν as an optional overlay. |

### Tools Tested
- Galaxy Curve Plotter — page text only; the tool could not be operated — formulas are clearly stated and correct (SPARC mass model with Υ_bul = 1.4Υ_disk, the 1.33 helium factor, the real simple-ν function, the 1/Ω_m cap, and the γ = ½ ↔ simple-μ identity) — commendably, it says it shows "how the equation fails" rather than presenting itself as a predictor. The Vflat-input circularity is disclosed. The open quadrature-vs-division wiring fork is a researcher degree of freedom that should be closed.
- Coherence Explorer — referenced on the index but not reachable today; not evaluated.

### Unanswered Questions
1. What is w(z) for the cosmological sector at γ ≠ ½, and does the knee mismatch ("misses by a factor of thousands") formally exclude the DESI-fit branch, or only the mean-density reading?
2. What smoothing scale ℓ defines ρ in C(ρ), and is there an action? Without one, how does the density law conserve momentum and pass planetary ephemerides?
3. Which high-z dataset is behind the a₀(z) "≈4.4σ if 95%" statement?
4. Are arXiv:2610.40388 and the three "locator pending" papers real and correctly cited?
5. For A2ACW: what fraction of "adversarial" critiques came from a model family different from the generator's, and was any human-expert blind review ever run against the 47 surviving candidate claims?
6. Has the density branch been run against DF2/DF4 or tidal dwarf galaxies, which are the natural discriminators against MOND's EFE?

### Verdict
Nothing here is new physics. Every branch either is MOND or Λ by exact identity, or differs from them and has been excluded (density law, the 3.17 boost cap, a knee that scales with V). The site's "0 unique confirmed predictions" is accurate, and its self-audit, with correct arithmetic, honest badges and dated retractions, is more rigorous than much of the human-written alternative-gravity literature I review. The one place I would push the authors is the γ ≠ ½ cosmological branch against DESI. I would also want every citation verified before any researcher takes the wide-binary summary at face value.

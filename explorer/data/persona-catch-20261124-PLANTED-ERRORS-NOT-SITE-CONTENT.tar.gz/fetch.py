"""Fetch live site pages as HTML and strip to readable text (offline mirror for the persona catch-rate experiment)."""
import sys, re, html, urllib.request, os

BASE = "https://synchronism-site.vercel.app"
ROUTES = sys.argv[2:]
OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)

def strip(h):
    h = re.sub(r"(?is)<script.*?</script>", " ", h)
    h = re.sub(r"(?is)<style.*?</style>", " ", h)
    h = re.sub(r"(?is)<svg.*?</svg>", " [figure] ", h)
    # block-level breaks
    h = re.sub(r"(?i)<(h[1-6])[^>]*>", lambda m: "\n\n" + "#" * int(m.group(1)[1]) + " ", h)
    h = re.sub(r"(?i)</(p|div|li|tr|h[1-6]|section|table|ul|ol|details|summary|blockquote)>", "\n", h)
    h = re.sub(r"(?i)<li[^>]*>", "\n- ", h)
    h = re.sub(r"(?i)<(td|th)[^>]*>", " | ", h)
    h = re.sub(r"(?i)<br\s*/?>", "\n", h)
    h = re.sub(r"(?s)<[^>]+>", "", h)
    h = html.unescape(h)
    h = re.sub(r"[ \t]+", " ", h)
    h = re.sub(r"\n\s*\n\s*\n+", "\n\n", h)
    return h.strip()

for r in ROUTES:
    path = "/" if r == "HOME" else "/" + r
    req = urllib.request.Request(BASE + path, headers={"User-Agent": "Mozilla/5.0 (offline-mirror)"})
    raw = urllib.request.urlopen(req, timeout=60).read().decode("utf-8", "replace")
    txt = strip(raw)
    name = "index" if r == "HOME" else r.replace("/", "_")
    with open(os.path.join(OUT, name + ".txt"), "w") as f:
        f.write(f"[Offline mirror of {BASE}{path}]\n\n" + txt + "\n")
    print(name, len(raw), len(txt), len(txt.split()))

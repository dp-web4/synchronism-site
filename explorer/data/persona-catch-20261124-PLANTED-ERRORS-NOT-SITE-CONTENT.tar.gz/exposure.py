"""Mediated arm: did the planted text reach the persona? Search the Agent tool_results (subagent reports) in each run's
stream for the planted-specific token(s) (words in planted_text not in original_text)."""
import json, re, difflib
ROOT = "/tmp/pcatch"
man = json.load(open(f"{ROOT}/MANIFEST.json"))
runs = [json.loads(l) for l in open(f"{ROOT}/runmap.jsonl")]
med = [r for r in runs if r["cond"] == "mediated"]

def key_tokens(o, p):
    a, b = o.split(), p.split()
    toks = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b).get_opcodes():
        if tag in ("replace", "insert"):
            toks += b[j1:j2]
    toks = [re.sub(r"[()\[\],;:.]+$", "", t) for t in toks]
    return [t for t in toks if len(t) >= 2] or toks

def reports(rid):
    out = []
    for line in open(f"{ROOT}/runs/{rid}/stream.jsonl"):
        try:
            o = json.loads(line)
        except Exception:
            continue
        if o.get("type") == "system" and o.get("subtype") == "task_notification":
            out.append(o.get("summary") or ""); continue
        if o.get("type") != "user" or o.get("parent_tool_use_id"):
            continue  # only what the persona itself received
        c = (o.get("message") or {}).get("content")
        if isinstance(c, str):
            out.append(c); continue
        for b in c or []:
            if b.get("type") == "text":
                out.append(b.get("text", ""))
            elif b.get("type") == "tool_result":
                cc = b.get("content")
                if isinstance(cc, list):
                    cc = " ".join(x.get("text", "") for x in cc if isinstance(x, dict))
                out.append(cc or "")
    return "\n".join(out)

scores = {r["run"]: {o["id"]: o["verdict"] for o in json.load(open(f"{ROOT}/scores/{r['run']}.json"))} for r in med}
tot = {"exposed": 0, "exposed_caught": 0, "unexposed": 0, "unexposed_caught": 0}
per_item = {}
for m in man:
    kt = key_tokens(m["original_text"], m["planted_text"])
    phrase = " ".join(kt)
    row = ""
    for r in sorted(med, key=lambda x: (x["rep"], x["persona"])):
        txt = reports(r["run"])
        exposed = all(t in txt for t in kt[:3])
        v = scores[r["run"]][m["id"]]
        row += ("E" if exposed else "-") + ("C" if v == "CAUGHT" else ("n" if v == "NOTICED" else ".")) + " "
        k = "exposed" if exposed else "unexposed"
        tot[k] += 1
        tot[k + "_caught"] += v == "CAUGHT"
    print(f"{m['id']} {m['class']:<10} key={phrase[:40]!r:<44} {row}")
print(tot)
print("runs (rep,persona) order:", [(r["rep"], r["persona"]) for r in sorted(med, key=lambda x: (x["rep"], x["persona"]))])

"""Blinded scorer: for each persona log, ask a no-tools Sonnet whether each manifest item was CAUGHT / NOTICED / MISSED.
usage: python3 score.py <run_id> [<run_id> ...]   -> writes /tmp/pcatch/scores/<run_id>.json
The scorer never sees the run's condition (clean vs planted)."""
import json, os, re, subprocess, sys, concurrent.futures as cf

ROOT = "/tmp/pcatch"
ENV = dict(os.environ, CLAUDE_CODE_DISABLE_AUTO_MEMORY="1")
man = json.load(open(f"{ROOT}/MANIFEST.json"))
items = [{k: m[k] for k in ("id", "class", "file", "original_text", "planted_text", "why_wrong")} for m in man]

SYS = """You are a strict, literal scorer in an experiment on review quality. You receive (a) a list of 20 specific
errors that may have been planted in a website's text, each with the correct original wording, the erroneous planted
wording and why it is wrong, and (b) one reviewer's log of their visit to the website. Decide for EACH item whether the
reviewer's log flags that specific error.

CAUGHT  = the log identifies this specific statement/number/citation (or the exact claim it makes) as wrong, inconsistent,
          overstated, understated, or mis-cited, in a way that matches the planted defect (it need not give the fix).
NOTICED = the log refers to the same passage or number but does not identify the planted defect (e.g. only calls it
          confusing, jargon, or quotes it approvingly).
MISSED  = nothing in the log touches it.
Be literal: a general complaint ("numbers are inconsistent", "too many caveats") is not a catch of a specific item.
If the log quotes the planted wording approvingly or uses it as fact, that is NOTICED, not CAUGHT.
Return ONLY a JSON list of 20 objects: {"id": ..., "verdict": "CAUGHT"|"NOTICED"|"MISSED", "evidence": "<=40-word quote
from the log, or empty"}."""

def score(rid):
    log = open(f"{ROOT}/runs/{rid}/log.md").read()
    prompt = ("ITEMS:\n" + json.dumps(items, ensure_ascii=False, indent=1) + "\n\nREVIEWER LOG:\n" + log +
              "\n\nReturn the JSON list now.")
    cmd = ["claude", "-p", prompt, "--model", "sonnet", "--tools", "", "--setting-sources", "", "--strict-mcp-config",
           "--settings", '{"autoMemoryEnabled": false}', "--system-prompt", SYS, "--output-format", "json"]
    p = subprocess.run(cmd, cwd="/tmp", env=ENV, capture_output=True, text=True, timeout=580)
    res = json.loads(p.stdout)["result"]
    m = re.search(r"\[.*\]", res, re.S)
    out = json.loads(m.group(0))
    os.makedirs(f"{ROOT}/scores", exist_ok=True)
    json.dump(out, open(f"{ROOT}/scores/{rid}.json", "w"), indent=1, ensure_ascii=False)
    return rid, sum(o["verdict"] == "CAUGHT" for o in out), sum(o["verdict"] == "NOTICED" for o in out)

if __name__ == "__main__":
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        for r in ex.map(score, sys.argv[1:]):
            print(r, flush=True)

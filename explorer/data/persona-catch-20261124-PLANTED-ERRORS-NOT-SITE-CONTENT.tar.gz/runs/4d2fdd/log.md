# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 3: Graduate Physics Student

### Summary
- **Pages visited**: 7 (index, key-claims, critical-density, why-synchronism, galaxy-plotter, first-encounter, wide-binaries)
- **Understanding achieved**: solid
- **Would return?**: maybe
- **Overall impression**: The core algebra is right and the site is unusually honest about what got reparametrized or failed. But I found several plain arithmetic errors (one is a 10× slip in a headline number, one wrongly says a test favoured the framework) and a lot of stale text that contradicts the current defaults.

### Journey
I skipped the beginner framing and went to the equation block on the landing page, then Key Claims and ρcrit, then the plotter, wide binaries and the two beginner pages. I recomputed every number I could from what was on the page.

**What checks out (and I checked a lot):**
- tanh(γ ln(1+x)) = [(1+x)^2γ − 1]/[(1+x)^2γ + 1]. At γ = ½ this is x/(x+2) = μ_simple(x/2). This is an exact identity, so calling the acceleration-keyed version a MOND interpolating function at every γ is correct: it gives μ→1 at high acceleration and μ ≈ γy at low acceleration, so a₀ = a₀′/γ. The reparametrization is identified correctly and honestly.
- (1−C)/C = 2/x at γ = ½, which gives ρ_DE = 2ρ_crit, a constant. The claim "is Λ" is correct, and the cosmological knee of 4.3×10⁻⁸ M☉/pc³ = ρ_Λ/2 checks out with H₀ = 67.4.
- Shape claims: the 10–90% width tends to 1.17 decades at large γ. The log-axis bend is at 0.772ρ_crit/γ, from s·tanh s = ½. C(ρ_crit) at γ = 2 is 0.882. C = ½ at 0.316ρ_crit. The maximum slope against ln ρ is at C ≈ 0.60. C is concave in ρ. All correct.
- The tanh shape is no longer sold as mean-field. The landing page correctly says there is no self-consistency loop, because C does not appear on the right-hand side. As a condensed-matter person I agree: that is the right retraction. If anything the form is a paramagnet-like two-level population, not Curie–Weiss.
- A = 4π/(β_J² G R₀²) with β_J = 1 and R₀ = 8 kpc gives 4.56×10⁻⁵ M☉ pc⁻³ (km/s)⁻². The 635× gap to 0.029 and the 317 pc product are both right.
- a₀ = cH₀/2π gives 1.04 (H₀ = 67.4) and 1.13 (H₀ = 73). The 0.66σ against the systematic and 7.9σ against the random error are right. Inverting gives H₀ = 77.6 ± 15.5. At z ≈ 1 the value is 1.86, using E(1) = 1.79. Freeman Σ₀ = 119 M☉/pc². The MOND-matching knee is a₀²/(4πGV²) = 6.3×10⁻³ at 200 km/s, and the (c/2πV)²(2/3)ρ_c0 rewrite is right.
- Plotter: BTFR 1/(Ga₀) = 62.8, (47/62.8)^¼ = 0.93, Freeman-disc peak 0.622 against spherical 0.542 at 2.2 R_d, the simple-ν formula, and the 1.44× boost at C_ρ = 0.244 with the Ω_m floor.
- Wide binaries: every density-keyed amplitude (+64%, +223%, +33%, +62%, +18.6%, +116%, +9.4%, +0.005%) reproduces. So do the no-EFE simple-ν factor of 3.70 at y = 0.1, Γ→γ = 10^(2Γ), and the 7,000 AU radius where g_⊙ = a₀.
- Key Claims: Γ = κ²(1−c) is the equal-coupling special case of the correlated-dephasing formula. Peres–Mermin has 2⁹ = 512 assignments. The φ−1 and 2/3 t-tests (p ≈ 0.016 and 0.006) are right.
- "Validated" badges: none remain. The ρ_crit page openly records that its old "5% agreement / Validated" was false, and the landing page says only 2 of 9 audited claims are confirmed to have carried the badge. The badges are honest now. The site is, if anything, harsh on itself: it counts a ~2σ, ΔBIC ≈ +2.7–11 result as a "refutation".

**What does not check out:** see the friction log. The most serious items are a 10× error in the "0.14%" survival rate, Key Claims saying a discriminating test "selected Synchronism over MOND", a wrong t-statistic, √1.4 ≠ 1.24, a σ figure that contradicts the σ quoted on two other pages, and a BBN exclusion that cannot be right. The plotter page carries at least five stale statements describing the old units-hybrid default as if it were current.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| index, methodology note | "0.14% internal-consistency survival rate (≈47 … out of ~3,300)". 47/3,308 = **1.42%**, not 0.14%. A 10× slip in a headline number. | high | Fix to 1.4% or fix the 47. |
| key-claims, "What's not on this page" (BTFR para) | "1 selected Synchronism over MOND (2 discriminated, one selected each)". This contradicts the landing page ("both selected the MOND class") and the page's own text (TEST-09 and TEST-10 both fired against the framework). It is the one place the site overclaims *for* itself. | high | Change to "2 discriminated; both selected MOND." |
| key-claims, consciousness caveat | t = (0.640−0.500)/(0.0196/√8) is **≈ 20.2**, not 7.1. The 7.1 divides by the SD, not the SE. The quoted p ≈ 1.8×10⁻⁷ matches t ≈ 20, not 7.1. | medium | Correct to t ≈ 20.2. |
| critical-density, knee-law list | "The archive's +0.5 is excluded at ~6σ". (0.5+0.16)/0.19 = **3.5σ**. The plotter and wide-binaries pages both say 3.5σ. | medium | Change to ~3.5σ. |
| wide-binaries, "What MOND predicts" | "+24% in velocity (√1.4 ≈ 1.24)". √1.4 = **1.183** (+18%). 1.24² = 1.54. The revision note just after it even mentions "the ~18%". | medium | Change to +18%. |
| wide-binaries, BBN box | "at γ = 2 that [Refracted Gravity] knee is excluded at about 3σ". At x ≈ 10.8, C = 0.9999, so G_BBN/G_lab ≈ 1.000 against a measured 0.99 (+0.06/−0.05). That is ~0.3σ, not excluded. The same page says "every knee except Refracted Gravity's at γ = 2 is excluded at 4σ or more", which implies it survives. | medium | Say "consistent (not excluded)". |
| wide-binaries, BBN box | The archive-knee prediction range "0.37–0.57" leaves out the unfloored γ = 0.489 value, C = 0.095, which is the value that produces the quoted 36σ. | low | Change to 0.095–0.57. |
| wide-binaries, Oort bullet | A predicted Σ of 900–1,800 against 68 ± 4 M☉/pc² is quoted as "≈10σ". On the quoted error bar it is >200σ. The denominator (model systematic?) is not stated. | low | State the error budget behind the 10σ. |
| wide-binaries, LLR paragraph | Ġ/G = (7.1 ± 7.6)×10⁻¹⁴/yr is credited to Williams, Turyshev & Boggs 2004. I recall that value as Hofmann & Müller 2018; WTB 2004 gave (4 ± 9)×10⁻¹³. | low | Check the citation. |
| wide-binaries, "If an anomaly is confirmed" | "counts as modest support" contradicts the same page's "gives this framework no support over MOND". | medium | Remove "modest support". |
| wide-binaries, badge | The badge is "Untested", but the body says the density branch is excluded three ways and the acceleration branch has failed via TEST-25. | low | Consider a different badge, or lead with "both branches excluded or degenerate". |
| index, scoreboard vs Draco row | The table row says Draco is at 4.5σ (corrected from 4.9σ on 11-19) and Crater II is dropped because it is disrupting. The refutation paragraph below still says "Draco and Crater II … 4.9σ and 4.2σ … corrected 2026-11-19". | medium | Sync the paragraph. |
| index / why / first-encounter: counting γ = 2 | The RAR γ = 2 pin is one of the "six refutations; it lost all six", but the plotter calls it "disfavoured at about 2σ, not refuted", with ΔBIC +2.7 by galaxy at free Υ. | medium | Mark that row as "disfavoured" in the count, or explain why a ~2σ result counts. |
| why-synchronism, galaxy detail | "14,610 galaxies (175 SPARC + **14,585** … (quality cut))". 175 + 14,585 = 14,760. The post-cut number is 14,435, as Key Claims has it. | medium | Change to 14,435. |
| why-synchronism + first-encounter §D | "the boundary between quantum and classical becomes a calculable density threshold" and "γ ≈ 1: Roughly the quantum-classical boundary". The ρ_crit page explicitly retracts the quantum↔classical labelling as "backwards physics". | medium | Remove the quantum/classical framing from both beginner pages. |
| first-encounter §E | "the number is 1/(2π), which the coherence transition fixes". Key Claims says "no calculation on file yields the 2π" and that it is posited, not derived. A beginner page is still asserting a derivation. | high | Change to "the 2π is borrowed from Milgrom's form, not derived". |
| why-synchronism, opening | "the broader frame behind it has been ruled out as well" contradicts the landing page ("the ontology underneath is untested rather than refuted"). | medium | Make the two pages agree. |
| galaxy-plotter, several places | Stale text from before the 2026-11-14 default change: "What You're Seeing" says max C(ρ) is 0.001 and the boost is uniform (the switch box shows 0.244). The legend says "Newton's shape ×1.78". "The chart draws only A = 0.029." "This plot shows the framework under its own stated law [A·V²]." "The tool never exercises the curve's shape on a real galaxy." "The toy exponential disc survives only as the density profile fed to Cρ" (SPARC Σ has been used since 11-17). DDO 154 card: "green line is also 7% low by its normalisation" (that circularity was removed on 11-10). | high | Do one sweep to scope every hybrid-only sentence or delete it. A physicist cannot tell what the violet line currently is. |
| critical-density, Freeman box | "≈4% error vs Freeman's value" alongside "Σ₀ = a₀/2πG is the same number" as the 13%-off a₀. If it is the same number, it cannot be 4% off one reference and 13% off another unless the references differ. Key Claims says sub-percent and percentage "matches" were retired in favour of "within the factor-of-~2 M/L systematic". | low | Use the Key Claims wording. |
| key-claims, V-scaling | "~116× apart at V = 300 km/s" is said to hold "for every value of A", but a ratio depends on A. I get ~9×10⁵ (A = 0.029) or ~1.5×10³ (A = 4.6×10⁻⁵). | low | State the normalisation used. |
| index, Ca row | "the tails match only at γ = 0.309". Only the high-x tail matches (1 − 2(1+x)^−2γ against 1 − x^−0.618). The low tails never match (linear against x^0.618). | low | Change to "the high-acceleration tails". |
| first-encounter §F | The quantum Zeno effect is called "a real measured effect, Misra & Sudarshan 1977". That is the theory paper. The measurement is Itano et al. 1990, which Key Claims cites. | low | Cite Itano. |
| first-encounter §B | "10×, 100×, 1000× … about 2.3, 4.6, 6.9". Inside ln(ρ/ρ_crit + 1) these are ln 11 = 2.40 and so on. Trivial, but this is the page where precision teaches. | low | Say "about" or use ln(x+1). |

### Tools Tested
- Galaxy Curve Plotter — worked as described in text (it cannot be operated in the mirror) — confusing. The current physics is represented correctly: SPARC mass models, simple-ν MOND with one a₀, and C_ρ at the archive knee in division wiring with the Ω_m floor. The numbers I checked reproduce (knee 0.19 for DDO 154, boost 1.44× at C = 0.244, UGC 128 central boost 1.74). But roughly half the explanatory text still describes the old units-hybrid default, so the page contradicts its own default curve in at least five places.
- Wide-binary DR4 reading key (table) — consistent with the γ ranges quoted in the text (1.4–1.5× maps to γ ≈ 0.4–0.64). It is properly dated before the data. Its honest conclusion, that no outcome favours the framework, is stated, but one later card contradicts it.

### Unanswered Questions
1. What normalisation gives "~116× apart at V = 300 km/s" for the ρ_crit ∝ V⁺² versus V⁻² comparison?
2. What error budget turns 900–1,800 against 68 ± 4 M☉/pc² into "≈10σ"?
3. Where does the "predicted +0.55 / measured −0.55" γ-correlation come from? The exact mirror-image values look suspicious, and no source is linked from First Encounter.
4. Which of the 4–8 refutations survive if ~2σ results (the γ = 2 RAR pin) are excluded from the count?
5. Is the 47 in "≈47 of ~3,300" right, or is it 4.7?

### Verdict
As physics there is nothing new here, and the site says so correctly. I verified the Möbius identity myself: the acceleration-keyed C is a MOND μ at every γ, the γ = ½ cosmology is exactly Λ, and the tanh is not a mean-field result. The reparametrizations are identified correctly, and no dishonest "Validated" badges remain. What undercuts trust now is not overclaiming but sloppiness. A 10× error in a headline percentage, one sentence crediting a test win the data didn't give, wrong t and σ values, and a plotter page that contradicts its own default curve are exactly what a referee would use to dismiss the careful parts. One focused arithmetic-and-staleness sweep would fix most of it.

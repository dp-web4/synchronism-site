# Synchronism Visitor Browse Log — offline

Persona pass over the offline site

---

## Pass 2: Technical Writer

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: partial
- **Would return?**: maybe
- **Overall impression**: The site is candid about what failed, and its beginner path is well signposted. Underneath, though, it is a reference archive with no consistent controlled vocabulary. One symbol has many names, badge words multiply from page to page, and acronyms are defined on some pages and not on others.

### Journey
I started on **index**. The H1 question and the one-line "0 (a crowd of strangers) to 1 (a marching band)" summary are good writing. The page then routes readers by type: beginners go to Why Synchronism?, physicists to Key Claims or Honest Assessment, and researchers to Tier 1. That is a sound pattern. The problems start lower down. The "Scientific Outcomes" section opens with an abbreviation key covering about 25 terms (ΔBIC, RAR, BTFR, ΛCDM, CHSH, fσ₈, DESI…), and many of those terms have already been used higher on the page. The key comes after the content that needs it. The "What Synchronism Covers" cards define one badge, Reparametrization. For "Speculative" and "Failed" the page sends readers to Honest Assessment, which is not part of today's set. I found about eight "Revision notes (history; not the current claim)" blocks on the landing page alone. The Beginner Path is given as 5 steps, but step 5 is described as both Honest Assessment and Research Philosophy, and the step-5 page is called "a ~18,000-word page" that readers should read "only the box at the top" of. **Critical Density and Wide Binaries are not linked by name from the index.**

**why-synchronism** (Beginner Path step 1 of 5) is the best-written page. MOND, free parameters, ansatz, Hamiltonian, tanh and compander all get inline plain-English glosses, and the physics detail sits in optional folds. Several things still don't work. SPARC is never expanded. The first thing under "What We Tested — and How It Went" is an "Edit history" note saying the section used to be titled "What Worked", which is maintenance information placed ahead of content. "Refuted by Execution", "audited-negative" and "sign-inverted" are used without definitions. The breadcrumb is a flat "Home / Why Synchronism?".

**first-encounter** (step 2) has a clear "← Prev / Next →" pair and plain-language glosses: density, tanh as a "dimmer switch", N_corr, and "fitted" as "a knob was turned". The formula uses ρ_crit before the page defines it as the "switch-over density". MOND is glossed in Section C, but its full name only appears in Section E. CRT, BEC, BCS and YBCO are never expanded. The intro says the sections appear one at a time, but the text view shows them all at once, so I couldn't check that behaviour.

**galaxy-plotter** (step 3) has the best badge design on the site. It separates the *tool type* ("Model Explainer: shows how the equation works, not a verdict") from the *claim status* ("Failed" and "Reparametrization", each with ⓘ), and it says so: "The label says what kind of tool this is; the badges say how its claims stand." The page lets itself down in other ways. SPARC is used throughout and never expanded, on a page aimed at step-3 beginners. γ, ρcrit, ΔBIC, RAR, QUMOND, NFW, EFE and MRH are not defined. BTFR is expanded only after its first use. **The page contradicts itself.** The default knee changed on 2026-11-14, yet body text still says "The rest of this step describes the units-hybrid setting" as if that were the default. The MOND curve is described as "a prediction, since 2026-11-10" in one place and under a history-only revision note in another. The breadcrumb ("Home / Interactive Tools / Galaxy Curve Plotter") matches a top-nav item, which is good. The Prev and Next links agree with the Beginner Path. The plotter is also "step 8 of 8" of the Advanced Path, so it sits in two paths at once.

**critical-density** is where the terminology problems collect. The URL slug says "critical density". The H1 says "ρcrit: the Reference Density (Saturation Knee)". The breadcrumb says "Reference Density (ρ_crit)". Other pages call it "the knee" and the "switch-over density". The page itself has a section, "One symbol, several knees", which says ρcrit "names at least six different objects across the site and archive." That admission is honest, and it is a clear documentation failure. The breadcrumb's middle level, "Core Theory", is not a top-nav item. Several H2 and H3 sections open with a formula and no lead-in sentence. Jeans, SPARC, BIC, σ, H₀ (given without units), R₀ and Rhalf are undefined. The page cites "Session687_A_From_Jeans_Arithmetic_Audit.md §1.2", which is a raw archive filename, not a page link. The status badge is "Audited-Negative — A-from-Jeans | scale-dependent, not derived", which is a third badge format, and I could not see what its ⓘ tooltip says. The page has two "Next" links, "All Parameter Derivations" and "Relation to MOND", and no "Previous".

**wide-binaries** has a breadcrumb of "Home / Cosmology / Wide Binaries", and "Cosmology" is not in the top nav either. The H1 is followed directly by the status string "Untested — Self-Eliminating-or-Tie — density branch identically null in the ratio but not in absolute dynamics (…) DR3 dispute unresolved", which no reader can parse before they know the topic. Neither "Untested" nor "Self-Eliminating-or-Tie" is defined here, and "Untested" doesn't appear in the index's badge legend. Another undefined status, "Status: still hung (2026-11-24)", appears further down. This page is the worst for acronyms: AU, MOND (never expanded here), SPARC, AQUAL, QUMOND, RUWE, IPD, ΔBIC, σ, Ωm, M/L and PREREG are all undefined, and LLR, BBN and DR3 are used before their expansions. Two errors stood out. **One H3 heading renders the HTML entity literally: "Saad &amp; Ting's reading".** The text also refers to "the red box below", which doesn't exist in the page text. The page ends with "Next: Cosmology Predictions →" and has no Previous link.

**key-claims** has the **only complete badge legend** I found: "Reparametrization = equivalent to existing physics in different notation; Speculative = conceptual proposal, no quantitative test; Failed = run against data and contradicted", along with the rule that text after a dash is a descriptor. The parallel H3 structure under each claim (What's new, Evidence, Honest caveat, The test that kills it) is good documentation design. The legend lists "Untested" as a badge, but no card on this page uses it. The H2 numbering has no space after the number ("1.Is Quantum Mechanics…"). CHSH is expanded about 18 lines after its first use. A2ACW is defined on the index but not here. EFE, BIC/ΔBIC, BTFR, SH0ES, DFS, GRW/CSL, QBism and SNARC are not defined. The page has no Prev or Next links at all, even though the index sends physicists here as their entry point.

**Across all pages:** the top nav is the same nine items everywhere, which is good. The same footer status line ("0 confirmed predictions · 6 refutations executed under the current counting rule (4–8 under rules on file…)") appears on every page, uses terms like "refutation" and "counting rule" without defining them, and links to a ledger I couldn't reach. Many lines that look like headings ("How to read this chart, in three steps", "Revision note", "Where each piece stands") are plain text, not marked-up headings, so they won't appear in an outline or a screen-reader heading list. The text mirror doesn't include link URLs, so **I could not check that any breadcrumb or nav link actually resolves**. I can only confirm what the labels say.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| Site-wide | ρcrit has at least six names (critical density, reference density, saturation knee, knee, switch-over density, Galactic reference density) and three spellings (ρcrit, ρ_crit, ρ<sub>crit</sub>). The critical-density page admits it "names at least six different objects" | high | Pick one canonical name per object, give each object its own subscript, and align the slug, H1 and breadcrumb |
| Site-wide | Badge vocabulary keeps growing: Reparametrization, Speculative, Failed, Untested, Audited-Negative, Validated (deprecated), Withdrawn, Excluded, Is MOND, Is Λ, Survives, Refuted by Execution, Self-Eliminating-or-Tie, "still hung", "Category: new ontology" | high | Publish one badge legend (Key Claims has the best start), link every badge's ⓘ to it, and retire or define the non-standard terms |
| index | The abbreviation key sits in "Scientific Outcomes", after many of its terms have already been used | high | Move the key to the top or into the glossary, and expand each acronym inline on first use |
| index | Only Reparametrization is defined in the badge line. Speculative and Failed are deferred to a page outside the beginner flow | medium | Copy the three-line legend from Key Claims |
| index | Beginner Path step 5 is named as both Honest Assessment and Research Philosophy, and is "~18,000 words" | medium | Name one step 5 and link to a short summary anchor |
| index | Critical Density and Wide Binaries aren't linked by name | low | Add them to the Galaxies card or an "Explore All" list |
| galaxy-plotter | The page contradicts itself: the default knee changed 2026-11-14, but body text still describes units-hybrid as the setting | high | Rewrite the current-state text and move history into one collapsed changelog |
| galaxy-plotter | SPARC, γ, ρcrit, RAR, EFE and ΔBIC are undefined on a Beginner Path step. BTFR is expanded only after first use | medium | Expand SPARC in the intro and gloss γ and ρcrit in one line each |
| critical-density | The breadcrumb level "Core Theory" isn't in the nav, and the H1, breadcrumb and slug name the page three different ways | medium | Align all three and make "Core Theory" a real index page |
| critical-density | Sections open with a formula and no lead-in sentence. A raw .md filename is cited as a reference | medium | Add one sentence before each formula and link the archive file or remove the reference |
| critical-density | Jeans, SPARC, BIC, σ, R₀ and Rhalf are undefined, and H₀ has no units | medium | Define them inline or link to glossary entries |
| wide-binaries | The H3 "Saad &amp; Ting's reading" shows an escaped HTML entity | medium | Fix the double escaping in the heading renderer |
| wide-binaries | "the red box below" points to content that doesn't exist | medium | Remove the reference or restore the box |
| wide-binaries | The status line under the H1 is an unreadable compound. "Self-Eliminating-or-Tie" and "still hung" are undefined | high | Give the badge first, then one plain sentence. Define the status terms in the legend |
| wide-binaries | MOND is never expanded on the page, and there are a dozen or more undefined acronyms (AU, RUWE, IPD, AQUAL, QUMOND, PREREG…) | medium | Expand on first use and link the glossary |
| wide-binaries | The breadcrumb level "Cosmology" isn't in the nav. There's no Previous link | low | Make the breadcrumb levels match the nav, or add a section landing page |
| key-claims | No Prev or Next links, though it's the physicist entry point | low | Add "Next: Honest Assessment →" |
| key-claims | Heading typo: "1.Is Quantum…" has no space. CHSH is used before it's expanded | low | Fix the numbering format and expand on first use |
| first-encounter | ρ_crit appears in the formula before it's defined. MOND's full name comes only in Section E. CRT, BEC and BCS are never expanded | medium | Define the symbol before the formula and expand acronyms at first use |
| first-encounter / why-synchronism | Notation drifts: N_corr vs Ncorr, V_flat vs Vflat | low | Pick one style and apply it everywhere |
| why-synchronism | The first item under a section heading is an "Edit history" note | low | Move edit history to the bottom or a changelog page |
| Site-wide | Dated revision notes ("Corrected…", "Until 2026-11-18 this sentence said…") are interleaved with current content on every page | high | Separate the current state from history: one "Changes" fold per page, current text only in the body |
| Site-wide | Many heading-like labels aren't marked-up headings | low | Mark them up as H3 or H4 for outlines and accessibility |
| Site-wide | The footer status line uses undefined jargon (refutation, counting rule, ledger) | low | Add a one-line plain-English gloss or a tooltip |
| Site-wide | ⓘ badge tooltips aren't in the text rendering | medium | Make sure the tooltip text is in the DOM and accessible to screen readers, not just shown on hover |

### Tools Tested
- Galaxy Curve Plotter — not operable today (text only) — the controls are labelled clearly from the text (five galaxy buttons, a Υdisk slider with default 0.50, a knee selector, two optional checkboxes) and the legend colours are documented. The slider's range and the Υdisk units are not stated. The "how to read this chart in three steps" instructions are good. The page contradicts itself about which setting is the default.
- Wide Binaries — no interactive controls; it has a static "reading key" table whose first column header is blank.
- Critical Density — no interactive controls; it refers to the galaxy plotter's default.

### Unanswered Questions
1. Do the breadcrumb links work, and what are "Core Theory" and "Cosmology"? Neither is in the nav, and I couldn't check their targets.
2. Where is the single canonical badge taxonomy? Index and Key Claims both point to Honest Assessment, which I couldn't reach.
3. What do "Self-Eliminating-or-Tie", "still hung", "Audited-Negative" and "Refuted by Execution" mean, and are they badges or descriptors?
4. Is Beginner Path step 5 Honest Assessment or Research Philosophy?
5. What do the ⓘ tooltips say?
6. Does the glossary define ρcrit as one thing or six?

### Verdict
The skeleton works. The nav is consistent, the beginner path has clear Prev/Next steps, the Key Claims legend and the plotter's split between tool type and status are good patterns, and the plain-English glosses on Why Synchronism are well done. The site's habit of logging every correction inline, though, has turned the pages into change histories that contradict themselves. The galaxy plotter disagrees with its own default. Terminology needs a controlled vocabulary: one name per symbol, one badge legend linked from every badge, and acronyms expanded on first use on every page rather than only on whichever page a reader happens to see first.

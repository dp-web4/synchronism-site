import json
ROOT = "/tmp/pcatch"
man = {m["id"]: m for m in json.load(open(f"{ROOT}/MANIFEST.json"))}
runs = {json.loads(l)["run"]: json.loads(l) for l in open(f"{ROOT}/runmap.jsonl")}
for i, m in sorted(man.items()):
    print(f"\n##### {i} {m['class']} {m['difficulty']} {m['file']}")
    print("  ORIG :", m["original_text"][:220])
    print("  PLANT:", m["planted_text"][:220])
    print("  WHY  :", m["why_wrong"][:260])
    for rid, r in runs.items():
        try:
            s = {o["id"]: o for o in json.load(open(f"{ROOT}/scores/{rid}.json"))}
        except FileNotFoundError:
            continue
        o = s[i]
        if o["verdict"] == "CAUGHT":
            print(f"   [{rid} {r['cond']} p{r['persona']} r{r['rep']}] {o['evidence'][:260]}")

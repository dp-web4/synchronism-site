# Synchronism Visitor Browse Log — offline mirror

Persona pass over the offline mirror in ./site/

---

## Pass 4: Leading-Edge Researcher

### Summary
- **Pages visited**: 7 (index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims)
- **Understanding achieved**: solid
- **Would return?**: maybe (to see how the Gaia DR4 reading key is handled, and whether the site makes the screened-gravity connection)
- **Overall impression**: The verdict of "0 novel predictions surviving" is correct, and the site's honesty is unusually rigorous. But the most useful output, a set of exclusions on a density-keyed G_eff, is not set against the literature it most belongs to (screened modified gravity). The pages also still carry several stale numbers and one sign-flipped sentence that a referee would catch straight away.

### Journey
I skipped the beginner material and went to the claims. The landing page's scoreboard and the "Where each piece stands" table do most of the work. The density law is **Excluded**. The acceleration-keyed law **Is MOND**. The cosmology **Is Λ**. The quantum side has **No number to test**. I checked the central algebra in Key Claims myself: tanh(γ ln(1+x)) = [(1+x)^{2γ} − 1]/[(1+x)^{2γ} + 1], so γ = ½ gives x/(x+2) = μ_simple(x/2), and (1−C)/C = 2/x gives ρ_DE = 2ρ_crit, a constant. The claim holds. For γ > 0 every member is a valid MOND μ, with deep-MOND slope γ (so the effective a₀ is a₀′/γ) and a high-acceleration approach to 1 that goes as x^{−2γ}. So "the acceleration-keyed version is MOND at every γ" is correct, and so is "the dark-energy sector is Λ at γ = ½". That collapse is a clean and citable observation.

I spot-checked numbers. All of these reproduce:
- cH₀/2π gives 1.04×10⁻¹⁰ at H₀ = 67.4 and 1.13×10⁻¹⁰ at 73.
- Inverting gives H₀ = 77.6 ± 15.5.
- Σ₀ = a₀/2πG ≈ 119 M☉/pc².
- C(ρ_crit) at γ = 2 is 0.88, and C = ½ at 0.316 ρ_crit.
- The MOND-tracking knee a₀²/(4πGV²) is 6.3×10⁻³ M☉/pc³ at 200 km/s, and the rewrite (c/2πV)²(2/3)ρ_c0 is correct.
- The virial ceiling 3/16π² = 0.019 is correct.
- ν_simple(0.1) = 3.70 is correct.
- E(z=1)·1.04 ≈ 1.86 is correct.
- BBN baryon density ~10¹⁸ M☉/pc³ is about right (I get ~5×10¹⁷ at T ≈ 0.1 MeV).
- The citations I know are correct: Giustina/Shalm/Hensen (including the p-values), Salart 2008, Bancal 2012, Wharton & Argaman RMP 92 021002, Collins et al. 2004, McGaugh–Lelli–Schombert PRL 117 201101, Alvey et al. 1910.10730, Desmond–Hees–Famaey 2024, Bovy & Rix 68 ± 4, Moe & Di Stefano 0.50, Casarotto PCI* = 0.31, and Palma–Suominen–Ekert 1996.

The wide-binaries page is the best page on the site. It treats MOND+EFE correctly (1.0–1.4× in g, and a no-EFE ν of 3.7 at 0.1a₀). It argues correctly that a uniform density-keyed boost is absorbed into G_lab and into masses calibrated on close binaries, so wide binaries cannot see it. It then finds the three channels that do see it: the vertical gradient (Oort/K_z), the time derivative (LLR Ġ/G), and the absolute value (G_BBN/G_lab). That BBN argument is sound and is the strongest exclusion of the density law on the site. Its treatment of the live Chae vs Saad & Ting dispute, reporting both and taking no side, is appropriately careful.

The galaxy plotter's physics is now honest: real SPARC mass models, the correct simple-ν function, and like-for-like baryons. Its prose, however, lags the code by several revisions (see the friction log). The critical-density page has the right idea ("one symbol, several knees", with no single knee serving both galaxies and cosmology), but it contradicts itself on the significance of the V^0.5 exponent.

**What's actually new?** Nothing I can find that differs from MOND + ΛCDM and has survived the tests. The only items that differ from MOND are:
- the boost ceiling: refuted;
- the environment amplitude: refuted;
- a₀(z) ∝ H(z): it differs from constant-a₀ MOND but not from ΛCDM's own simulated a₀(z), and Verlinde-type emergent gravity predicts the same scaling, so it is not unique;
- low-knee near-Newtonian density laws: these survive only where they predict nothing.

The "0 confirmed / 0 prospective" verdict is accurate, and if anything it is generous to the framework.

**Is A2ACW sound?** It is sound as a falsification bookkeeper and unsound as a discovery engine, and the site says the latter itself (specificity 0/6, J = 0 under the literal rule, post-cutoff arm never run). What actually carries the weight is the executed scripts against external data (SPARC, LLR, BBN, Oort, Cassini). The structural weakness I would stress is that "the framework" is a family: four C's, two wirings, L2 vs L3, and 12 forks pending on the lead. Variants keep being split off after a refutation (Cρ / Cf / Cg / Ca), so data can kill members but never the family. A real program would freeze one Lagrangian plus a coupling, then test it.

### Friction Log
| Location | Issue | Severity | Suggestion |
|----------|-------|----------|------------|
| Key Claims, "What's not on this page" (BTFR paragraph) | Reads "1 selected Synchronism over MOND (2 discriminated, one selected each)". The landing page says both discriminating tests (TEST-09 and TEST-10) **selected the MOND class**. As written, it claims a win the framework never had. | high | Change to "2 discriminated; both selected MOND." |
| Key Claims, claim 3, "Sharper than (b)" | Cites AQUAL as "Bekenstein & Milgrom (1983, ApJ 270, 365)". ApJ 270, 365 is Milgrom's 1983 MOND paper. AQUAL is Bekenstein & Milgrom **1984, ApJ 286, 7**, which the wide-binaries page cites correctly. | high | Fix the citation. |
| Key Claims, "What survives… (a) V-scaling inversion" | Still says the framework "asserts V+2" and calls this a "durable, parameter-free" result. Elsewhere the site now says the archive's own law is V^0.5 and that V² with A = 0.029 is a units slip. The "~116× apart at V = 300 km/s" cannot be reproduced from any knee in the critical-density table (I get ~10³–10⁶ depending on A). | high | Restate (a) against V^0.5 (3.5σ from the measured −0.16 ± 0.19), or drop it. Show the 116× arithmetic. |
| Critical-density, knee-law list, 3rd bullet | "The archive's +0.5 is excluded at ~6σ". With the measured −0.16 ± 0.19, (0.5 + 0.16)/0.19 = 3.5σ, which is what the wide-binaries page and the plotter say. | medium | Correct to ~3.5σ. |
| Critical-density, "One symbol, several knees" | "The framework asserts V+2" contradicts the same page's header, which names V^0.5 as the archive's own form. | medium | Say "the A·V² form asserts V+2; the archive's form is V^0.5". |
| Key Claims, honest caveat (claim 1) | "The site-wide count is 4 executed refutations on external data" contradicts the landing page ("Five ran on outside data"). | medium | Read the number from the ledger, as the revision note says it now does. It doesn't. |
| Index, scoreboard cell (TEST-09/10 paragraph) | Still says "Draco and Crater II exceed it at 4.9σ and 4.2σ… corrected 2026-11-19". The "Where each piece stands" table on the same page says Draco is 4.5σ (4.9 was a coefficient slip) and that Crater II was removed on 11-20 as tidally disrupting. | medium | Propagate the 11-19 and 11-20 corrections to the scoreboard cell. |
| Galaxy plotter, "What You're Seeing" + legend | Says "this galaxy's maximum C(ρ) is 0.001… boost is the same everywhere" and "the violet line is Newton's shape ×1.78". Both hold only under the hybrid setting. The default (0.028·V^0.5) gives max Cρ = 0.244 for DDO 154 and a radially varying boost, which the page's own knee box states. | medium | Rewrite both for the default knee, and mark the hybrid text as conditional. |
| Galaxy plotter, mass-model note and "Two assumptions" | "The toy exponential disc survives only as the density profile fed to Cρ" contradicts the formula box (SPARC Σ since 11-17). "The chart draws only A = 0.029" contradicts the default knee since 11-14. | medium | Remove the stale sentences. |
| Galaxy plotter, DDO 154 Vflat box | "The green line is also 7% low by its normalisation" refers to the pre-11-10 BTFR-fed MOND curve. The same box says that circularity is gone. | low | Delete the clause. |
| Index + plotter, TEST-25 framing | Says the Cassini squeeze is "shared with MOND, but MOND has an escape the compander lacks". The compander is a MOND μ, so every escape (modified inertia, M/L freedom, a different field equation) is equally open to it. The 17.95σ (M/L pinned) vs 8.7σ (marginalised) comparison is also not like for like. | medium | Either name an escape the compander structurally lacks, or reclassify TEST-25 as fully inherited and compare at matched marginalisation. |
| Whole site, density-keyed G_eff | **Missed connection.** A gravitational coupling that switches on below a critical density is the defining feature of screened scalar–tensor theories: chameleon (Khoury & Weltman 2004) and especially the symmetron (Hinterbichler & Khoury 2010), which has an explicit ρ* knee with a fifth force on at low density and off at high density, the same direction as 1/C(ρ). That literature has field equations (environment-dependent effective mass, thin-shell screening) that avoid the vacuum singularity the site attributes to the division wiring. It is also constrained by the same LLR, BBN and Solar-System data. | high | Add a prior-art box. The site's LLR, BBN and Oort exclusions should be stated as constraints on "local-density-screened G_eff without a Compton scale", and compared with the existing symmetron and chameleon bounds. |
| Wide-binaries, BBN box | **Missed handle.** The baryon density at recombination is ~ρ_b0(1+z)³ ≈ a few M☉/pc³ (my rough estimate), which sits near the galactic knees (0.16–0.42). So CMB constraints on G_eff at recombination (a few percent from Planck) would test C(ρ) near its bend rather than in saturation, a fourth independent root. | low | Worth one explorer run. Check against the smoothing-scale condition the BBN box already states. |
| Index, cosmology row ("Is Λ") + DESI DR2 fit | Doesn't say what the γ ≠ ½ branch does for w(z). DESI DR2 + CMB + SNe prefer w₀ > −1, wₐ < 0 at roughly 3–4σ. A Cardassian-type branch whose w cannot cross −1 can't follow that. | medium | State the w(z) behaviour of the γ ≠ ½ forms explicitly: "cannot cross the phantom divide, so it does no better than ΛCDM against DESI's preference". That is a sharper loss than "fits no better". |
| Wide-binaries, citations | arXiv:2610.40388 has a 5-digit sequence number that looks implausibly high for one month's submissions. Park et al. 2026, Saglia 2025 and Pasquini 2026 are still "locator pending". | low | Verify the ID, or flag it like the others. |
| Index, Bell/frame row | Bell's "Quantum field theory without observers", Phys. Rep. 137, 49 (1986). I recall the paper at that locator as "Beables for quantum field theory"; worth checking. Groot Nibbelink & Pospelov is marked "from recall". | low | Verify both. |
| Index, landing page length | The scoreboard has revision notes nested three deep. A referee can find the verdicts, but stale text survives because each correction is applied locally (see five rows above). | medium | Generate every repeated number (Draco σ, refutation counts, exponents) from one source file. |

### Tools Tested
- **Galaxy Curve Plotter** (text only): the computed physics is now sound, but the prose is out of date.
  - What's sound: SPARC MassModels with the 1.33 He factor, simple-ν ν = ½ + √(¼ + 1/y), one global a₀, and a like-for-like Υ slider. The violet curve really is Cρ wired by floored division.
  - Approximations: algebraic MOND (v_b√ν) is used rather than QUMOND for discs, and EFE is ignored. Both are standard and disclosed.
  - Problem: the captions describe three different past states of the code (hybrid knee, toy disc, BTFR-fed MOND). An expert reading the captions against the formula box finds the contradictions within a minute.
  - Verdict: scientifically accurate as an illustration that the density law has the wrong radial shape. I would not cite its captions.

### Unanswered Questions
1. Which single (Lagrangian, coupling, C) does the project lead commit to? Until that is decided, is any refutation more than a refutation of a member?
2. How does the density-keyed law differ from a symmetron with its Compton wavelength sent to zero? If it doesn't, the LLR, BBN and Oort exclusions belong in that literature's language.
3. Does any γ ≠ ½ dark-energy branch produce w(z) < −1 at any redshift? If none does, DESI's evolving-DE preference is a direct strike against it, independent of ΛCDM.
4. What does C(ρ) predict for G_eff at recombination, given the smoothing scale used in the BBN argument?
5. What, concretely, is the "escape MOND has that the compander lacks" for Cassini?
6. Has the A2ACW protocol's post-cutoff calibration arm been scheduled? Without it, the "0 of 9 audit" line carries no information, as the site admits.

### Verdict
Nothing here differs from MOND + ΛCDM and survives. The density law is excluded several independent ways (SPARC, LLR, Oort gradient, BBN), the acceleration law is MOND's μ at every γ, and the cosmology is Λ at the point the data select. So the "0 confirmed novel predictions" headline is accurate. What has real value for researchers is the negative results, packaged with scripts. Those would land much harder if framed as constraints on density-screened G_eff and set against the chameleon/symmetron literature. The site also needs to clear its stale and contradictory numbers, above all Key Claims' "1 selected Synchronism over MOND" and the misdated AQUAL citation, before any outside physicist takes the bookkeeping at face value.

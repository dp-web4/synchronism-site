"""Build mediated-arm prompt/CLAUDE.md variants from the Arm A templates (exact string replacement, asserted)."""
T = "/tmp/pcatch/template"
PAGES = "index, why-synchronism, first-encounter, galaxy-plotter, wide-binaries, critical-density, key-claims"
NEW1 = ('1. To browse the site, use the Agent tool with subagent_type "web-fetch": name the page and say what you want '
        'reported, as you would brief a web-fetch tool. You cannot open the pages yourself. Start with the landing page '
        f'(index). The site has 7 pages: {PAGES} (other pages linked from them are not available).')
for n in (1, 2, 3, 4):
    s = open(f"{T}/p{n}.txt").read()
    a = s.index("1. The site is offline today.")
    b = s.index("\n", a)
    s = s[:a] + NEW1 + s[b:]
    old2 = "2. DO NOT read local files except CLAUDE.md, the files in ./site/, and ./log.md (to append)"
    assert old2 in s
    s = s.replace(old2, "2. DO NOT read local files except CLAUDE.md and ./log.md (to append)")
    s = s.replace("The interactive tools are text only in the mirror", "The interactive tools are text only today")
    open(f"{T}/p{n}m.txt", "w").write(s)
c = open(f"{T}/CLAUDE.md").read()
old = c[c.index("- **READ THE OFFLINE MIRROR**"):c.index("\n", c.index("- **READ THE OFFLINE MIRROR**"))]
c = c.replace(old, '- **BROWSE VIA THE web-fetch AGENT**: the site is offline today; brief the `web-fetch` subagent (Agent tool) '
                   'with a page name and what to report, in place of WebFetch')
c = c.replace("**Site**: offline mirror in ./site/ (7 pages, text only; interactive tools show their controls and captions but cannot be operated)",
              "**Site**: offline today; 7 pages reachable through the `web-fetch` subagent (text only; interactive tools cannot be operated)")
c = c.replace("evaluate the tool pages from their text (the Galaxy Plotter is in the mirror)", "evaluate the tool pages from their text (the Galaxy Plotter is available)")
open(f"{T}/CLAUDE_m.md", "w").write(c)
print(open(f"{T}/p3m.txt").read()[:1500])

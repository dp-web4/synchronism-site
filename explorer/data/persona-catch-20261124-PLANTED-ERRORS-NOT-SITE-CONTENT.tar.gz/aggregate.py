"""Aggregate blinded scores by class, persona, condition; Wilson intervals."""
import json, math, collections

ROOT = "/tmp/pcatch"
man = {m["id"]: m for m in json.load(open(f"{ROOT}/MANIFEST.json"))}
runs = [json.loads(l) for l in open(f"{ROOT}/runmap.jsonl")]
over = {}
try:
    over = json.load(open(f"{ROOT}/overrides.json"))  # hand-check corrections: {"run:id": "VERDICT"}
except FileNotFoundError:
    pass

def wilson(k, n, z=1.96):
    if n == 0: return (float("nan"),) * 3
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0, c - h), min(1, c + h)

V = {}
for r in runs:
    try:
        s = json.load(open(f"{ROOT}/scores/{r['run']}.json"))
    except FileNotFoundError:
        continue
    for o in s:
        v = over.get(f"{r['run']}:{o['id']}", o["verdict"])
        V[(r["run"], o["id"])] = v
CLASSES = ["ARITH", "STALE", "CITE", "OVERCLAIM", "OVERREFUTE"]
scored = [r for r in runs if any(k[0] == r["run"] for k in V)]
print("scored runs:", [(r["run"], r["cond"], r["persona"], r["rep"]) for r in scored])

for cond in ("planted", "mediated", "clean"):
    rs = [r for r in scored if r["cond"] == cond]
    print(f"\n=== {cond}: per-pass CAUGHT by class (items x persona-runs) ===")
    for c in CLASSES:
        ids = [i for i, m in man.items() if m["class"] == c]
        k = sum(V.get((r["run"], i)) == "CAUGHT" for r in rs for i in ids)
        nt = sum(V.get((r["run"], i)) == "NOTICED" for r in rs for i in ids)
        n = len(ids) * len(rs)
        p, lo, hi = wilson(k, n)
        print(f"{c:<11} {k:>3}/{n:<3} = {p:.2f} [{lo:.2f},{hi:.2f}]  noticed {nt}")
    print("by persona:", {p: sum(V.get((r['run'], i)) == 'CAUGHT' for r in rs if r['persona'] == p for i in man)
                          for p in (1, 2, 3, 4)})

for COND in ('planted', 'mediated'):
    rs = [r for r in scored if r["cond"] == COND]
    reps = sorted({r["rep"] for r in rs})
    print(f"\n=== {COND}: LOOP level (caught by any persona within a replicate) ===")
    for c in CLASSES + ["NUMERIC(A+S)", "WORDING(OC+OR)", "ALL"]:
        sel = {"NUMERIC(A+S)": ["ARITH", "STALE"], "WORDING(OC+OR)": ["OVERCLAIM", "OVERREFUTE"], "ALL": CLASSES}.get(c, [c])
        ids = [i for i, m in man.items() if m["class"] in sel]
        k = sum(any(V.get((r["run"], i)) == "CAUGHT" for r in rs if r["rep"] == rep) for rep in reps for i in ids)
        n = len(ids) * len(reps)
        p, lo, hi = wilson(k, n)
        print(f"{c:<15} {k:>3}/{n:<3} = {p:.2f} [{lo:.2f},{hi:.2f}]")
    
    print(f"\n=== per item ({COND}): catches per rep, by persona ===")
    for i, m in sorted(man.items()):
        row = []
        for rep in reps:
            row.append("".join(str(r["persona"]) if V.get((r["run"], i)) == "CAUGHT" else
                               ("n" if V.get((r["run"], i)) == "NOTICED" else ".")
                               for r in sorted(rs, key=lambda x: x["persona"]) if r["rep"] == rep))
        print(f"{i} {m['class']:<10} {m['difficulty']:<6} {m['file']:<22} " + " | ".join(row))
    
    
rs = [r for r in scored if r["cond"] == "planted"]
print("\n=== difficulty (per pass, planted) ===")
for d in ("easy", "medium", "hard"):
    ids = [i for i, m in man.items() if m["difficulty"] == d]
    k = sum(V.get((r["run"], i)) == "CAUGHT" for r in rs for i in ids); n = len(ids) * len(rs)
    print(d, k, n, round(k / n, 2) if n else None)
